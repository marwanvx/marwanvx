import { relations, sql } from 'drizzle-orm'
import {
  type AnyPgColumn,
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from 'drizzle-orm/pg-core'

/**
 * VelixSoft dashboard schema.
 *
 * Design notes live in `docs/DASHBOARD-DESIGN.md` §4. Three shapes here are
 * deliberate and should not be "simplified" without reading that section:
 *
 * 1. `orders.kind` + `parentOrderId` — a domain change is a second order, not a
 *    mutation, because every issued build works forever and therefore *is* an
 *    additional licence.
 * 2. `builds` is separate from `orders` so one purchase can own several permanent
 *    artifacts.
 * 3. Nothing is hard-deleted. Products archive; orders and builds are history.
 */

/* -------------------------------------------------------------------------- */
/* Enums                                                                       */
/* -------------------------------------------------------------------------- */

export const userRole = pgEnum('user_role', ['customer', 'admin'])

export const productStatus = pgEnum('product_status', [
  'available',
  'coming_soon',
  'archived',
])

export const deliveryType = pgEnum('delivery_type', [
  'per_customer_build',
  'shared_download',
  'none',
])

export const orderKind = pgEnum('order_kind', ['purchase', 'additional_domain'])

/**
 * `polar` and `paddle` are reserved. v1 ships crypto only (decision 4a) — they
 * exist so adding a card provider later needs no migration.
 */
export const paymentProvider = pgEnum('payment_provider', [
  'crypto',
  'manual',
  'polar',
  'paddle',
])

export const orderStatus = pgEnum('order_status', ['pending', 'paid', 'refunded'])

export const buildStatus = pgEnum('build_status', [
  'draft',
  'pending',
  'ready',
  'failed',
])

export const producedBy = pgEnum('produced_by', ['manual', 'system'])

export const licenseStatus = pgEnum('license_status', ['active', 'revoked'])

export const platform = pgEnum('platform', ['win', 'mac'])

export const installStatus = pgEnum('install_status', [
  'requested',
  'awaiting_access',
  'access_granted',
  'in_progress',
  'completed',
  'awaiting_revoke',
  'closed',
])

export const panelType = pgEnum('panel_type', ['main_owner', 'child_or_reseller'])

export const ticketStatus = pgEnum('ticket_status', [
  'open',
  'awaiting_customer',
  'awaiting_us',
  'closed',
])

/* -------------------------------------------------------------------------- */
/* Identity                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Mirrors `auth.users`. The foreign key to Supabase's auth schema is declared in
 * `drizzle/policies/rls.sql` rather than here, because Drizzle has no clean way to
 * reference a table it does not own.
 */
export const profiles = pgTable('profiles', {
  id: uuid('id').primaryKey(),
  email: text('email').notNull(),
  name: text('name'),
  role: userRole('role').notNull().default('customer'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

/* -------------------------------------------------------------------------- */
/* Catalogue                                                                   */
/* -------------------------------------------------------------------------- */

export const products = pgTable('products', {
  id: uuid('id').primaryKey().defaultRandom(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  /** Matches `ProductType` in src/data/types.ts: theme | app | tool | data. */
  type: text('type').notNull(),
  status: productStatus('status').notNull().default('available'),

  price: numeric('price', { precision: 10, scale: 2 }).notNull(),
  currency: text('currency').notNull().default('USD'),

  deliveryType: deliveryType('delivery_type').notNull(),
  requiresLicense: boolean('requires_license').notNull().default(false),
  /** null = unlimited. Recorded but not enforced in v1 (decision 6). */
  activationLimit: integer('activation_limit'),

  tagline: text('tagline').notNull(),
  shortDescription: text('short_description').notNull(),
  longDescription: jsonb('long_description').$type<string[]>().notNull().default([]),
  features: jsonb('features').$type<string[]>().notNull().default([]),
  included: jsonb('included').$type<string[]>().notNull().default([]),
  faq: jsonb('faq')
    .$type<{ question: string; answer: string }[]>()
    .notNull()
    .default([]),
  seo: jsonb('seo')
    .$type<{ title: string; description: string; keywords: string[] }>()
    .notNull(),
  gallery: jsonb('gallery').$type<{ slug: string; pages: string[] }>().notNull(),

  /* Google Merchant Center feed values — see src/data/merchant-feed.ts. */
  merchantTitle: text('merchant_title'),
  mpn: text('mpn'),
  googleCategory: text('google_category'),
  feedProductType: text('feed_product_type'),
  /**
   * Site-absolute JPEG paths. Merchant Center rejects AVIF, which every capture in
   * public/products is — these point at the converted copies in public/feed.
   */
  feedImages: jsonb('feed_images').$type<string[]>().notNull().default([]),

  releasedAt: timestamp('released_at', { withTimezone: true }).notNull(),
  /** Drives `lastmod` in sitemap.xml. Bump it on every meaningful edit. */
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const editions = pgTable('editions', {
  id: uuid('id').primaryKey().defaultRandom(),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id, { onDelete: 'cascade' }),
  slug: text('slug').notNull(),
  name: text('name').notNull(),
  swatch: text('swatch').notNull(),
  tokens: jsonb('tokens')
    .$type<{
      dark: { brand: string; brand600: string; brand400: string }
      light: { brand: string; brand600: string; brand400: string }
    }>()
    .notNull(),
})

/* -------------------------------------------------------------------------- */
/* Commerce                                                                    */
/* -------------------------------------------------------------------------- */

export const orders = pgTable(
  'orders',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .notNull()
      .references(() => profiles.id),
    productId: uuid('product_id')
      .notNull()
      .references(() => products.id),
    editionId: uuid('edition_id').references(() => editions.id),

    kind: orderKind('kind').notNull().default('purchase'),
    /** Set on `additional_domain` orders, pointing at the original purchase. */
    parentOrderId: uuid('parent_order_id').references((): AnyPgColumn => orders.id),

    amount: numeric('amount', { precision: 10, scale: 2 }).notNull(),
    currency: text('currency').notNull().default('USD'),

    provider: paymentProvider('provider').notNull(),
    /** Provider's own id. Null only for `manual` orders. */
    providerRef: text('provider_ref'),
    status: orderStatus('status').notNull().default('pending'),
    /** Amount actually received, for detecting crypto underpayment. */
    amountReceived: numeric('amount_received', { precision: 18, scale: 8 }),
    notes: text('notes'),

    paidAt: timestamp('paid_at', { withTimezone: true }),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    /**
     * The idempotency guard. Payment providers retry webhooks for days; without
     * this a single payment becomes several orders. Partial, because `manual`
     * orders legitimately have no provider reference.
     */
    uniqueIndex('orders_provider_ref_unique')
      .on(table.provider, table.providerRef)
      .where(sql`${table.providerRef} is not null`),
  ],
)

export const builds = pgTable('builds', {
  id: uuid('id').primaryKey().defaultRandom(),
  orderId: uuid('order_id')
    .notNull()
    .references(() => orders.id),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id),
  editionId: uuid('edition_id').references(() => editions.id),

  /** Normalised hostname. Apex only — the lock also accepts its `www` variant. */
  domain: text('domain'),
  status: buildStatus('status').notNull().default('draft'),
  /**
   * Why a build could not be produced. A failed build must never consume the
   * customer's one allowed domain change — our error, not theirs.
   */
  failureReason: text('failure_reason'),

  fileKey: text('file_key'),
  fileSize: integer('file_size'),
  checksum: text('checksum'),

  producedBy: producedBy('produced_by').notNull().default('manual'),
  /** Required when an admin overrides the once-only domain rule. */
  notes: text('notes'),

  issuedAt: timestamp('issued_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const licenses = pgTable('licenses', {
  id: uuid('id').primaryKey().defaultRandom(),
  orderId: uuid('order_id')
    .notNull()
    .references(() => orders.id),
  userId: uuid('user_id')
    .notNull()
    .references(() => profiles.id),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id),
  key: text('key').notNull().unique(),
  status: licenseStatus('status').notNull().default('active'),
  activationLimit: integer('activation_limit'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const releases = pgTable('releases', {
  id: uuid('id').primaryKey().defaultRandom(),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id, { onDelete: 'cascade' }),
  version: text('version').notNull(),
  platform: platform('platform'),
  fileKey: text('file_key').notNull(),
  size: integer('size').notNull(),
  changelog: jsonb('changelog').$type<string[]>().notNull().default([]),
  publishedAt: timestamp('published_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
})

/* -------------------------------------------------------------------------- */
/* Installation service                                                        */
/* -------------------------------------------------------------------------- */

/**
 * ⚠️ `vxPassword` holds a customer's panel admin password as readable text.
 *
 * This was an explicit, informed decision (design doc §3, decision 13). A database
 * leak therefore exposes live admin access to every panel we have installed on,
 * with no expiry and no revocation path. Two mitigations are in place and must not
 * be removed: the column is readable only under the admin RLS policy, and every
 * read is written to `credential_reads`.
 */
export const installRequests = pgTable('install_requests', {
  id: uuid('id').primaryKey().defaultRandom(),
  orderId: uuid('order_id')
    .notNull()
    .references(() => orders.id),
  buildId: uuid('build_id').references(() => builds.id),
  userId: uuid('user_id')
    .notNull()
    .references(() => profiles.id),

  status: installStatus('status').notNull().default('requested'),
  panelType: panelType('panel_type').notNull(),
  panelAdminUrl: text('panel_admin_url'),
  codeEditorEnabled: boolean('code_editor_enabled').notNull().default(false),

  vxUsername: text('vx_username'),
  vxPassword: text('vx_password'),
  vxEmail: text('vx_email'),

  notes: text('notes'),
  requestedAt: timestamp('requested_at', { withTimezone: true })
    .notNull()
    .defaultNow(),
  completedAt: timestamp('completed_at', { withTimezone: true }),
  accessRevokedAt: timestamp('access_revoked_at', { withTimezone: true }),
})

/* -------------------------------------------------------------------------- */
/* Support                                                                     */
/* -------------------------------------------------------------------------- */

export const tickets = pgTable('tickets', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => profiles.id),
  orderId: uuid('order_id').references(() => orders.id),
  subject: text('subject').notNull(),
  status: ticketStatus('status').notNull().default('open'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const ticketMessages = pgTable('ticket_messages', {
  id: uuid('id').primaryKey().defaultRandom(),
  ticketId: uuid('ticket_id')
    .notNull()
    .references(() => tickets.id, { onDelete: 'cascade' }),
  authorId: uuid('author_id')
    .notNull()
    .references(() => profiles.id),
  body: text('body').notNull(),
  attachments: jsonb('attachments')
    .$type<{ name: string; fileKey: string; size: number }[]>()
    .notNull()
    .default([]),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

/* -------------------------------------------------------------------------- */
/* Audit                                                                       */
/* -------------------------------------------------------------------------- */

export const buildDownloads = pgTable('build_downloads', {
  id: uuid('id').primaryKey().defaultRandom(),
  buildId: uuid('build_id')
    .notNull()
    .references(() => builds.id),
  userId: uuid('user_id')
    .notNull()
    .references(() => profiles.id),
  ip: text('ip'),
  at: timestamp('at', { withTimezone: true }).notNull().defaultNow(),
})

export const credentialReads = pgTable('credential_reads', {
  id: uuid('id').primaryKey().defaultRandom(),
  installRequestId: uuid('install_request_id')
    .notNull()
    .references(() => installRequests.id, { onDelete: 'cascade' }),
  adminId: uuid('admin_id')
    .notNull()
    .references(() => profiles.id),
  at: timestamp('at', { withTimezone: true }).notNull().defaultNow(),
})

/* -------------------------------------------------------------------------- */
/* Relations                                                                   */
/* -------------------------------------------------------------------------- */

export const profilesRelations = relations(profiles, ({ many }) => ({
  orders: many(orders),
  licenses: many(licenses),
  tickets: many(tickets),
  installRequests: many(installRequests),
}))

export const productsRelations = relations(products, ({ many }) => ({
  editions: many(editions),
  releases: many(releases),
  orders: many(orders),
}))

export const editionsRelations = relations(editions, ({ one }) => ({
  product: one(products, { fields: [editions.productId], references: [products.id] }),
}))

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(profiles, { fields: [orders.userId], references: [profiles.id] }),
  product: one(products, { fields: [orders.productId], references: [products.id] }),
  edition: one(editions, { fields: [orders.editionId], references: [editions.id] }),
  parentOrder: one(orders, {
    fields: [orders.parentOrderId],
    references: [orders.id],
    relationName: 'additional_domains',
  }),
  additionalDomainOrders: many(orders, { relationName: 'additional_domains' }),
  builds: many(builds),
  licenses: many(licenses),
  installRequests: many(installRequests),
}))

export const buildsRelations = relations(builds, ({ one, many }) => ({
  order: one(orders, { fields: [builds.orderId], references: [orders.id] }),
  product: one(products, { fields: [builds.productId], references: [products.id] }),
  edition: one(editions, { fields: [builds.editionId], references: [editions.id] }),
  downloads: many(buildDownloads),
}))

export const licensesRelations = relations(licenses, ({ one }) => ({
  order: one(orders, { fields: [licenses.orderId], references: [orders.id] }),
  user: one(profiles, { fields: [licenses.userId], references: [profiles.id] }),
  product: one(products, { fields: [licenses.productId], references: [products.id] }),
}))

export const releasesRelations = relations(releases, ({ one }) => ({
  product: one(products, { fields: [releases.productId], references: [products.id] }),
}))

export const installRequestsRelations = relations(
  installRequests,
  ({ one, many }) => ({
    order: one(orders, { fields: [installRequests.orderId], references: [orders.id] }),
    build: one(builds, { fields: [installRequests.buildId], references: [builds.id] }),
    user: one(profiles, {
      fields: [installRequests.userId],
      references: [profiles.id],
    }),
    credentialReads: many(credentialReads),
  }),
)

export const ticketsRelations = relations(tickets, ({ one, many }) => ({
  user: one(profiles, { fields: [tickets.userId], references: [profiles.id] }),
  order: one(orders, { fields: [tickets.orderId], references: [orders.id] }),
  messages: many(ticketMessages),
}))

export const ticketMessagesRelations = relations(ticketMessages, ({ one }) => ({
  ticket: one(tickets, { fields: [ticketMessages.ticketId], references: [tickets.id] }),
  author: one(profiles, {
    fields: [ticketMessages.authorId],
    references: [profiles.id],
  }),
}))

/* -------------------------------------------------------------------------- */
/* Inferred types                                                              */
/* -------------------------------------------------------------------------- */

export type Profile = typeof profiles.$inferSelect
export type Product = typeof products.$inferSelect
export type Edition = typeof editions.$inferSelect
export type Order = typeof orders.$inferSelect
export type Build = typeof builds.$inferSelect
export type License = typeof licenses.$inferSelect
export type Release = typeof releases.$inferSelect
export type InstallRequest = typeof installRequests.$inferSelect
export type Ticket = typeof tickets.$inferSelect
export type TicketMessage = typeof ticketMessages.$inferSelect
