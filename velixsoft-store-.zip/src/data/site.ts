/** Site-wide configuration and contact endpoints. */
export const siteConfig = {
  name: 'VelixSoft',
  wordmark: 'VELIXSOFT',
  /** Canonical host. The apex redirects here, so `www` is the canonical form. */
  domain: 'www.velixsoft.net',
  url: 'https://www.velixsoft.net',
  /**
   * One-line company definition. Reused as the default meta description.
   *
   * Names no product and no platform, deliberately: this is a company-level
   * surface, so it describes what VelixSoft builds rather than what is
   * currently on the shelf. Product names and platform targets belong on
   * product pages. See `docs/BRAND.md` §1.
   */
  description:
    'VelixSoft is a software company. We build custom software to order: web applications, desktop and mobile apps, automation, and complete interface systems.',
  /**
   * Short-form positioning used in footers, social cards, and schema `slogan`.
   * Carries no licensing terms: how a product is sold is a per-product
   * decision, not the company's identity (`docs/BRAND.md` §1).
   */
  tagline: 'We build software to order.',
  founded: '2026',
  contact: {
    /** WhatsApp username, resolved as https://wa.me/<handle>. */
    whatsappHandle: 'velixsoft',
    telegramHandle: 'velixsoft1',
    /** Discord has no direct-message URL for a username — display and copy it. */
    discordUsername: 'mrw.sys',
  },
  /**
   * Feeds `sameAs` in the Organization schema (`app/layout.tsx`).
   *
   * This is a priority field, not boilerplate: `velixsoft.com` is held by a
   * third party and competes for the brand name, so `sameAs` is our primary
   * signal telling search engines and AI systems that this site is
   * authoritatively VelixSoft. Messaging deep links carry little entity
   * weight — add every owned profile (LinkedIn, GitHub, YouTube, X, Product
   * Hunt, Crunchbase, Reddit) as it is created. See `docs/BRAND.md` §0.
   */
  social: {
    whatsapp: 'https://wa.me/velixsoft',
    telegram: 'https://t.me/velixsoft1',
  },
} as const

export function whatsappLink(message: string) {
  const handle = siteConfig.contact.whatsappHandle
  return `https://wa.me/${handle}?text=${encodeURIComponent(message)}`
}

export function telegramLink(message?: string) {
  const handle = siteConfig.contact.telegramHandle
  if (!message) return `https://t.me/${handle}`
  return `https://t.me/${handle}?text=${encodeURIComponent(message)}`
}

export const mainNav = [
  { label: 'Products', href: '/products' },
  { label: 'Services', href: '/services' },
  { label: 'Guides', href: '/guides' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
] as const

/**
 * Category order follows the company messaging hierarchy: software and
 * automation first, platform-specific products last.
 */
export const categoryNav = [
  { label: 'Desktop Apps', href: '/apps', type: 'app' as const },
  { label: 'Automation & Tools', href: '/tools', type: 'tool' as const },
  { label: 'Data Products', href: '/data', type: 'data' as const },
  { label: 'Interface Themes', href: '/themes', type: 'theme' as const },
]

export const footerNav = {
  Products: [
    { label: 'All Products', href: '/products' },
    { label: 'YTLeads Pro', href: '/products/ytleads-pro' },
    { label: 'Perfect Panel Theme', href: '/products/perfect-panel-theme' },
  ],
  Categories: [
    { label: 'Desktop Apps', href: '/apps' },
    { label: 'Automation & Tools', href: '/tools' },
    { label: 'Data Products', href: '/data' },
    { label: 'Interface Themes', href: '/themes' },
  ],
  Company: [
    { label: 'About', href: '/about' },
    { label: 'Services', href: '/services' },
    { label: 'Guides', href: '/guides' },
    { label: 'Contact', href: '/contact' },
    { label: 'FAQ', href: '/faq' },
  ],
  Legal: [
    { label: 'Terms', href: '/terms' },
    { label: 'Privacy', href: '/privacy' },
    { label: 'Refund Policy', href: '/refund-policy' },
  ],
}
