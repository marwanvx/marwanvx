import type { Guide } from './types'

/**
 * `readingTime` is a measured value, not a decoration. The three guides
 * previously claimed 5, 6, and 8 minutes against bodies of roughly 325, 162,
 * and 162 words — an overstatement of up to ten times, which a reader notices
 * within seconds of arriving. Figures below are the word count at ~230 words
 * per minute, rounded up. Recount when you change a body.
 */
export const guides: Guide[] = [
  {
    slug: 'how-to-install-perfect-panel-theme',
    title: 'How to Install Your VelixSoft Perfect Panel Theme',
    excerpt:
      'Step-by-step installation guide for Main Panel Owners and Child-Panel/Reseller owners to enable the code editor and upload custom theme files.',
    category: 'Perfect Panel',
    readingTime: '2 min read',
    publishedAt: '2026-07-26',
    updatedAt: '2026-07-27',
    relatedProducts: ['perfect-panel-theme'],
    seo: {
      title: 'How to Install Your VelixSoft Perfect Panel Theme',
      description:
        'Official step-by-step guide to installing your VelixSoft custom theme on Perfect Panel for main panel owners and child panel renters.',
      keywords: ['install Perfect Panel theme', 'Perfect Panel code editor', 'VelixSoft theme setup', 'SMM panel theme guide'],
    },
    body: [
      {
        kind: 'p',
        text: 'Installing your custom VelixSoft theme on Perfect Panel is fast and straightforward. Depending on whether you own a main panel or rent a child panel, follow the step-by-step method below to enable the Code Editor and upload your theme template files.',
        links: [{ match: 'custom VelixSoft theme on Perfect Panel', href: '/products/perfect-panel-theme' }],
      },
      {
        kind: 'h2',
        text: 'Method 1: Main Panel Owners',
      },
      {
        kind: 'p',
        text: 'If you own the main Perfect Panel account, you can enable the Code Editor directly from your Perfect Panel account dashboard:',
      },
      {
        kind: 'ol',
        items: [
          'Log into your Perfect Panel account dashboard at https://my.perfectpanel.com/panels.',
          'Find your active panel in the list, click the 3 dots menu icon next to your panel, and select "Enable Code Editor".',
          'Log into your panel admin control panel at your domain (your-domain.com/admin).',
          'Navigate to Appearance → Themes (/admin/appearance/themes).',
          'Create a new theme copy and name it "velixsoft-theme".',
          'Click Edit on the new theme. Replace each template file (.twig) with the corresponding file from your VelixSoft theme package, and click Save for each file.',
        ],
      },
      {
        kind: 'callout',
        text: 'Important: Make sure to save each file after pasting its new code content before moving to the next template file.',
      },
      {
        kind: 'h2',
        text: 'Method 2: Child-Panels & Rented Reseller Panels',
      },
      {
        kind: 'p',
        text: 'If you operate a child panel or rent your panel through a provider or reseller, you can enable the Code Editor by requesting it from your provider:',
      },
      {
        kind: 'ol',
        items: [
          'Open a support ticket with your main panel provider / reseller.',
          'Request them to enable the "Code Editor" feature for your panel.',
          'Once your provider enables Code Editor, log into your panel admin at your-domain.com/admin.',
          'Go to Appearance → Themes (/admin/appearance/themes).',
          'Create a new theme copy named "velixsoft-theme".',
          'Click Edit, replace the default template files matching by file name with the files from your VelixSoft theme package, and click Save for each file.',
        ],
      },
      {
        kind: 'callout',
        text: 'That is the whole installation. Your VelixSoft theme is now live on your panel. If a template does not render as expected, send us the file name and we will look at it with you. Installation support is included with every purchase, so contact us rather than working around a broken template.',
        links: [{ match: 'contact us', href: '/contact' }],
      },
    ],
  },
  {
    slug: 'choosing-color-scheme-smm-panel',
    title: 'Choosing a color scheme for your SMM panel',
    excerpt:
      'How to pick a panel color direction that supports trust, readability, and brand recognition without overwhelming the interface.',
    category: 'Design',
    readingTime: '1 min read',
    publishedAt: '2026-07-26',
    updatedAt: '2026-07-26',
    relatedProducts: ['perfect-panel-theme'],
    seo: {
      title: 'Choosing an SMM Panel Color Scheme',
      description:
        'Choose an SMM panel color scheme that improves trust, readability, and recognition across dark and light dashboard modes.',
      keywords: ['SMM panel color scheme', 'SMM panel dashboard design', 'Perfect Panel edition'],
    },
    body: [
      { kind: 'p', text: 'Color gives your SMM panel an identity, but the dashboard still has a demanding job to do. Customers scan prices, compare services, read order statuses, and move money. A successful palette creates recognition without competing with that information.' },
      { kind: 'h2', text: 'Start with the feeling, not the hex value' },
      { kind: 'p', text: 'Ember feels direct and energetic. Ocean reads familiar and dependable. Emerald suggests growth and positive movement. Midnight feels technical and focused. The right direction depends on how you want customers to describe your business after a few seconds. The six editions of the Velix Perfect Panel Theme exist for exactly this reason, and each one is shown in full before you choose.', links: [{ match: 'six editions of the Velix Perfect Panel Theme', href: '/products/perfect-panel-theme' }] },
      { kind: 'h2', text: 'Test color in real dashboard states' },
      { kind: 'ul', items: ['Primary order buttons', 'Active navigation and tabs', 'Status badges and alerts', 'Links inside dense tables', 'Focus rings on keyboard navigation', 'Light and dark mode surfaces'] },
      { kind: 'p', text: 'Do not judge a color from a logo alone. Place it next to balance information, service rows, warnings, and form controls. A well-built SMM panel theme keeps its signature color recognizable while reserving semantic colors for success, warning, and error states. Color is only part of it: what makes an SMM panel look trustworthy covers the rest.', links: [{ match: 'what makes an SMM panel look trustworthy', href: '/guides/what-makes-smm-panel-look-trustworthy' }] },
    ],
  },
  {
    slug: 'what-makes-smm-panel-look-trustworthy',
    title: 'What makes an SMM panel look trustworthy?',
    excerpt:
      'The interface details that signal quality before a new customer places their first order.',
    category: 'Strategy',
    readingTime: '1 min read',
    publishedAt: '2026-07-26',
    updatedAt: '2026-07-26',
    relatedProducts: ['perfect-panel-theme', 'ytleads-pro'],
    seo: {
      title: 'What Makes an SMM Panel Look Trustworthy?',
      description:
        'Learn the dashboard design, content, and usability details that make an SMM panel feel reliable before a customer places an order.',
      keywords: ['trustworthy SMM panel', 'custom SMM panel design', 'SMM panel UX'],
    },
    body: [
      { kind: 'p', text: 'Trust is formed before a customer reads your service list. Alignment, spacing, loading behavior, and the clarity of your payment instructions all become evidence. A panel that feels assembled from mismatched parts asks customers to take a risk.' },
      { kind: 'h2', text: 'Consistency is the first signal' },
      { kind: 'p', text: 'Buttons should behave the same across pages. Status labels should use predictable language. Empty states should explain what happens next. When a customer moves from New Order to Add Funds, the product should still feel like the same system. That consistency is easier to reach when every panel page is styled as one system rather than page by page.', links: [{ match: 'every panel page is styled as one system', href: '/products/perfect-panel-theme' }] },
      { kind: 'h2', text: 'Operational screens matter most' },
      { kind: 'ul', items: ['Readable order history on mobile', 'Clear payment instructions and balance hierarchy', 'Helpful errors that preserve entered data', 'Visible support and ticket access', 'Responsive service tables', 'Documented API access'] },
      { kind: 'callout', text: 'A polished homepage creates interest. A polished order workflow creates repeat customers.' },
      { kind: 'p', text: 'A premium Perfect Panel template can establish the visual foundation quickly, but trust also depends on current service descriptions, accurate statuses, and responsive support. Design makes those strengths visible. If you are still deciding on a direction, start with choosing a color scheme for your SMM panel, then install it.', links: [{ match: 'choosing a color scheme for your SMM panel', href: '/guides/choosing-color-scheme-smm-panel' }, { match: 'install it', href: '/guides/how-to-install-perfect-panel-theme' }] },
    ],
  },
]

export const getGuide = (slug: string) =>
  guides.find((guide) => guide.slug === slug)
