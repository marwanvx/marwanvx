/**
 * VelixSoft product data model.
 *
 * Products are a discriminated union on `type`. Shared fields exist on every
 * product; type-specific fields are optional at the union level so the UI can
 * render them conditionally. Editions are optional and product-specific — never
 * assume a product has editions.
 */

export type ProductType = 'theme' | 'app' | 'tool' | 'data'
export type ProductStatus = 'available' | 'coming-soon'

export type EditionId =
  | 'ember'
  | 'ocean'
  | 'aurora'
  | 'cyan'
  | 'emerald'
  | 'midnight'

export interface Edition {
  id: EditionId
  name: string
  /** Hex used only for the swatch chip preview; live theming uses CSS vars. */
  swatch: string
  /** Runtime brand tokens applied to the document for this edition. */
  tokens: {
    dark: { brand: string; brand600: string; brand400: string }
    light: { brand: string; brand600: string; brand400: string }
  }
}

export interface ProductFaq {
  question: string
  answer: string
}

export interface ChangelogEntry {
  version: string
  date: string
  changes: string[]
}

/** Fields shared by every product regardless of type. */
export interface BaseProduct {
  slug: string
  name: string
  tagline: string
  type: ProductType
  status: ProductStatus
  price: number
  currency: string
  shortDescription: string
  longDescription: string[]
  features: string[]
  /** Included deliverables surfaced in the purchase panel. */
  included: string[]
  gallery: {
    /** Product slug used to resolve `/products/[slug]/...` assets. */
    slug: string
    /** Pages available for this product's gallery. */
    pages: GalleryPage[]
  }
  faq: ProductFaq[]
  releasedAt: string
  updatedAt: string
  seo: {
    title: string
    description: string
    keywords: string[]
  }
}

export type GalleryPage =
  | 'home-hero'
  | 'home-full'
  | 'dashboard'
  | 'discover'
  | 'history'
  | 'settings'
  | 'help'
  | 'mobile-home-full'
  | 'mobile-dashboard-full'

export interface ThemeProduct extends BaseProduct {
  type: 'theme'
  editions?: Edition[]
  platform: string
  compatibility: { label: string; value: string }[]
  styledPages: string[]
  installSteps: { title: string; description: string }[]
  changelog: ChangelogEntry[]
}

export interface AppProduct extends BaseProduct {
  type: 'app'
  platforms: string[]
  version: string
  systemRequirements: { label: string; value: string }[]
  downloadSize: string
  changelog: ChangelogEntry[]
}

export interface ToolProduct extends BaseProduct {
  type: 'tool'
  runtime: string
  integrations: string[]
  usageLimits: string
}

export interface DataProduct extends BaseProduct {
  type: 'data'
  recordCount: number
  formats: string[]
  sampleRows: Record<string, string>[]
  updateFrequency: string
  deliveryMethod: string
}

export type Product =
  | ThemeProduct
  | AppProduct
  | ToolProduct
  | DataProduct

/* ---------- Content models (guides, services, testimonials) ---------- */

export interface Guide {
  slug: string
  title: string
  excerpt: string
  category: string
  readingTime: string
  publishedAt: string
  updatedAt: string
  /** Slugs of products this guide references, for internal linking. */
  relatedProducts: string[]
  body: GuideBlock[]
  seo: { title: string; description: string; keywords: string[] }
}

/**
 * An inline link inside a paragraph. `match` must appear verbatim in the
 * block's `text`; the renderer splits on it and that same phrase becomes the
 * anchor text, so the link reads as part of the sentence rather than as a
 * bolted-on "click here". Anchor text is one of the few things a linking page
 * controls about how the target is understood, so the phrase should describe
 * the destination on its own.
 */
export interface InlineLink {
  match: string
  href: string
}

export type GuideBlock =
  | { kind: 'p'; text: string; links?: InlineLink[] }
  | { kind: 'h2'; text: string }
  | { kind: 'ul'; items: string[] }
  | { kind: 'ol'; items: string[] }
  | { kind: 'callout'; text: string; links?: InlineLink[] }

export interface Service {
  id: string
  name: string
  description: string
  deliverables: string[]
  /** Omitted until real numbers exist. Rendered only when set. */
  startingPrice?: string
  icon: string
}

export interface Testimonial {
  isPlaceholder?: boolean
  quote: string
  author: string
  /** Generic job title only. Never name a customer's panel, business, or site. */
  role: string
  avatar: string
  rating: number
}
