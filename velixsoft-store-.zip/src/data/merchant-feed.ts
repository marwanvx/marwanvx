import { products } from './products'
import { siteConfig } from './site'
import type { Product } from './types'

/**
 * Google Merchant Center product feed data.
 *
 * Everything that can be derived from `products.ts` is derived — title,
 * description, price, highlights, and detail rows all read from the catalogue,
 * so a product edit cannot leave the feed describing something we no longer
 * sell. Only the values Merchant Center needs and the site does not (its
 * taxonomy, our SKUs, feed-safe images) are declared here.
 *
 * Rendered by `app/product-feed.xml/route.ts` as RSS 2.0 with the
 * `http://base.google.com/ns/1.0` namespace, which is what Merchant Center's
 * scheduled fetch expects.
 */

/**
 * Feed images must be JPEG, PNG, WebP, GIF, BMP, or TIFF. **AVIF is not an
 * accepted Merchant Center format**, and every screenshot in `public/products`
 * is AVIF — pointing `image_link` at one gets the item disapproved for an
 * invalid image, not merely warned about. So the feed carries its own JPEG
 * copies under `public/feed`, converted from the same source captures:
 *
 *     ffmpeg -i public/products/<slug>/<name>.avif -q:v 3 public/feed/<slug>/<name>.jpg
 *
 * Filenames are kept identical apart from the extension so each JPEG's origin
 * is unambiguous. Regenerate them in the same commit that replaces a capture.
 *
 * The first entry becomes `image_link`; the rest become `additional_image_link`
 * (Merchant Center accepts up to 10). Full-page scrolls are excluded for the
 * same reason `galleryImagePaths` excludes them: Shopping crops to roughly
 * square, and a 1:31 capture crops to noise. The theme is pinned to the default
 * Ocean edition so the feed does not imply an edition the buyer did not choose.
 */
const FEED_IMAGES: Record<string, string[]> = {
  'perfect-panel-theme': [
    '/feed/perfect-panel-theme/ocean-dark-desktop-home-hero.jpg',
    '/feed/perfect-panel-theme/ocean-light-desktop-home-hero.jpg',
    '/feed/perfect-panel-theme/ocean-dark-desktop-dashboard.jpg',
    '/feed/perfect-panel-theme/ocean-light-desktop-dashboard.jpg',
  ],
  'ytleads-pro': [
    '/feed/ytleads-pro/dark-desktop-dashboard.jpg',
    '/feed/ytleads-pro/light-desktop-dashboard.jpg',
    '/feed/ytleads-pro/dark-desktop-discover.jpg',
    '/feed/ytleads-pro/dark-desktop-home-hero.jpg',
    '/feed/ytleads-pro/light-desktop-home-hero.jpg',
  ],
}

/**
 * Per-product feed values that have no equivalent in the catalogue.
 *
 * `title` is written rather than reused from `product.name`, because a feed
 * title is matched against shopping queries: "Velix Perfect Panel Theme" alone
 * never meets a buyer searching for an SMM panel theme. It stays factual —
 * Merchant Center rejects promotional text, block capitals, and prices in the
 * title — and must stay under 150 characters.
 *
 * `mpn` is our own part number. We publish no GTIN (these are our software, not
 * retail goods with a barcode), so `brand` + `mpn` is the identifier pair
 * Merchant Center falls back to. Submitting neither would mean setting
 * `identifier_exists` to `no`, which weakens matching for no gain.
 *
 * `googleCategory` uses Google's product taxonomy, as the full text path rather
 * than a numeric id so the value stays readable when it needs revisiting.
 * `productType` is our own taxonomy and mirrors `categoryNav` in `site.ts`.
 */
const FEED_METADATA: Record<
  string,
  { title: string; mpn: string; googleCategory: string; productType: string }
> = {
  'perfect-panel-theme': {
    title: 'Velix Perfect Panel Theme - SMM Panel Theme with 6 Color Editions',
    mpn: 'VLX-PPT-THEME',
    googleCategory: 'Software > Computer Software > Multimedia & Design Software',
    productType: 'Software > Interface Themes',
  },
  'ytleads-pro': {
    title: 'YTLeads Pro - YouTube Lead Generation App for Windows and macOS',
    mpn: 'VLX-YTLEADS-PRO',
    googleCategory: 'Software > Computer Software > Business & Productivity Software',
    productType: 'Software > Desktop Apps',
  },
}

/**
 * Countries the feed declares shipping for.
 *
 * These are downloads, so the cost is genuinely zero — but Merchant Center
 * still requires a shipping value for every country an item is served in, and
 * an item with no shipping information for its target country is disapproved.
 * Item-level shipping only covers the countries listed here, so add a country
 * to this list when you add it as a Merchant Center target, or configure
 * free shipping at account level and drop the `shipping` block entirely.
 */
const FEED_SHIPPING_COUNTRIES = ['US'] as const

/** Merchant Center caps `product_highlight` at 10 entries of 150 characters. */
const MAX_HIGHLIGHTS = 10
const MAX_HIGHLIGHT_LENGTH = 150
const MAX_DESCRIPTION_LENGTH = 5000

export interface FeedProductDetail {
  section: string
  name: string
  value: string
}

export interface FeedItem {
  id: string
  title: string
  description: string
  link: string
  imageLink: string
  additionalImageLinks: string[]
  availability: 'in_stock'
  price: string
  brand: string
  mpn: string
  condition: 'new'
  googleCategory: string
  productType: string
  highlights: string[]
  details: FeedProductDetail[]
  shippingCountries: readonly string[]
  customLabel0: string
}

const absolute = (path: string) => `${siteConfig.url}${path}`

/**
 * Feed description, built from the product's long copy.
 *
 * `shortDescription` is deliberately not used: it quotes the price ("...for
 * $149"), and Merchant Center treats a price inside a description as
 * promotional text. `longDescription` is plain factual prose about what the
 * product is, which is exactly what the attribute is for.
 */
function feedDescription(product: Product): string {
  const text = product.longDescription.join('\n\n')
  if (text.length <= MAX_DESCRIPTION_LENGTH) return text
  return `${text.slice(0, MAX_DESCRIPTION_LENGTH - 1).trimEnd()}…`
}

/** Product-specific spec rows, whichever shape this product type carries them in. */
function feedDetails(product: Product): FeedProductDetail[] {
  const rows =
    product.type === 'theme'
      ? product.compatibility
      : product.type === 'app'
        ? product.systemRequirements
        : []

  return rows.map((row) => ({
    section: product.type === 'app' ? 'System requirements' : 'Compatibility',
    name: row.label,
    value: row.value,
  }))
}

export function toFeedItem(product: Product): FeedItem | null {
  const metadata = FEED_METADATA[product.slug]
  const images = FEED_IMAGES[product.slug]

  // A product with no feed metadata or no accepted-format image cannot be
  // submitted; omitting it beats submitting an item that will be disapproved.
  if (!metadata || !images?.length) return null

  const [imageLink, ...additionalImageLinks] = images

  return {
    id: product.slug,
    title: metadata.title,
    description: feedDescription(product),
    link: absolute(`/products/${product.slug}`),
    imageLink: absolute(imageLink),
    additionalImageLinks: additionalImageLinks.map(absolute),
    availability: 'in_stock',
    price: `${product.price.toFixed(2)} ${product.currency}`,
    brand: siteConfig.name,
    mpn: metadata.mpn,
    condition: 'new',
    googleCategory: metadata.googleCategory,
    productType: metadata.productType,
    highlights: product.features
      .filter((feature) => feature.length <= MAX_HIGHLIGHT_LENGTH)
      .slice(0, MAX_HIGHLIGHTS),
    details: feedDetails(product),
    shippingCountries: FEED_SHIPPING_COUNTRIES,
    customLabel0: metadata.productType,
  }
}

/**
 * Items eligible for the feed.
 *
 * `coming-soon` products are excluded rather than sent as `preorder`: a preorder
 * item needs a firm `availability_date`, and we do not publish release dates
 * before a build is ready. Add such a product here once it ships.
 */
export function feedItems(): FeedItem[] {
  return products
    .filter((product) => product.status === 'available')
    .map(toFeedItem)
    .filter((item): item is FeedItem => item !== null)
}
