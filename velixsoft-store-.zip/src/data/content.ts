import type { ProductFaq, ProductType, Service } from './types'

/**
 * Company-level FAQ. Answers are written to be self-contained so they can be
 * quoted without surrounding context (search snippets and AI answer engines).
 */
export const companyFaq: ProductFaq[] = [
  {
    question: 'What does VelixSoft build?',
    answer:
      'VelixSoft is a software company. We build software to order: web applications, desktop and mobile apps, automation, developer tools, and complete interface systems. Most of our work is built for a specific client, against their requirements. We also ship our own products, and two are available today: YTLeads Pro and the Velix Perfect Panel Theme.',
  },
  {
    question: 'Is VelixSoft only for SMM panels?',
    answer:
      'No. Perfect Panel is where the company started, and the theme is one product in one category. YTLeads Pro is general-purpose lead research used well beyond that market. New releases are planned in desktop software, automation, and data products, and none of them depend on the SMM panel market.',
  },
  {
    question: 'Do VelixSoft products require a subscription?',
    answer:
      'No. Every product is a one-time license for a specific release. Compatibility fixes and refinements to the release you bought are included at no extra cost. You are never billed monthly, we do not meter usage, and the desktop apps launch without an account.',
  },
  {
    question: 'Where is my data stored?',
    answer:
      'On your own machine. YTLeads Pro keeps its contact database, search history, and settings in local storage on your computer, with no cloud sync and no telemetry pipeline. The Perfect Panel Theme runs entirely inside your own panel installation and sends nothing to us.',
  },
  {
    question: 'How do I buy a VelixSoft product?',
    answer:
      'Message us on WhatsApp or Telegram. We confirm compatibility and scope before any payment, then deliver the build, source files where applicable, and documentation. Installation help is included with every purchase, and support comes directly from the people who built the product.',
  },
  {
    question: 'What is VelixSoft releasing next?',
    answer:
      'Additional desktop software is in engineering, and the automation, developer tools, and data product categories are being scoped. We announce releases when they are ready to install rather than as pre-orders. Tell us which workflow costs you the most time and it will inform what we build.',
  },
]

/**
 * Ordered so the custom work leads and product support comes last (`docs/BRAND.md`
 * §1). `startingPrice` is deliberately unset: there is no honest number yet, and
 * repeating "Scoped per project" on every card reads as evasion rather than
 * flexibility. The brief form at /services#brief carries scoping instead.
 */
export const services: Service[] = [
  {
    id: 'custom-software',
    name: 'Custom Software',
    description:
      'A web application, a desktop tool, or a mobile app, built to your requirements when nothing off the shelf covers the job.',
    deliverables: [
      'Written scope before work starts',
      'Design and implementation',
      'Source code and documentation',
      'Deployment and handover',
    ],
    icon: 'terminal',
  },
  {
    id: 'interface-systems',
    name: 'Interface & Design Systems',
    description:
      'A complete design system for a product or platform you already run: information hierarchy, every state, and a documented component set.',
    deliverables: [
      'Interface and brand direction',
      'Every screen, not only the main ones',
      'Dark and light designed separately',
      'Source files and handoff',
    ],
    icon: 'palette',
  },
  {
    id: 'perfect-panel-theme',
    name: 'Custom Perfect Panel Themes',
    description:
      'A Perfect Panel theme built for your panel specifically, rather than an edition of ours. Your brand, your service catalogue, the same standard as the Velix Perfect Panel Theme.',
    deliverables: [
      'Every core panel page styled',
      'Your brand colors and identity',
      'Dark and light designed separately',
      'Installed and verified in your panel',
    ],
    icon: 'layout-dashboard',
  },
  {
    id: 'automation',
    name: 'Automation & Internal Tools',
    description:
      'A focused tool that removes one repetitive piece of work completely, instead of another platform to learn and maintain.',
    deliverables: [
      'Defined inputs and outputs',
      'Runs on your machine or your server',
      'Documentation for whoever inherits it',
      'Revisions once you have used it',
    ],
    icon: 'zap',
  },
  {
    id: 'deployment',
    name: 'Deployment & Customization',
    description:
      'Installing, configuring, and adapting a VelixSoft product inside your environment, including changes to specific screens.',
    deliverables: [
      'Compatibility review',
      'Guided or done-for-you install',
      'Brand and layout adaptation',
      'Post-launch verification',
    ],
    icon: 'sliders',
  },
]

export const whyVelixsoft = [
  {
    title: 'Products, not templates',
    description:
      'Every release is designed as one system, with documented behaviour, defined states, and a version number. We do not ship recolored asset packs.',
    icon: 'layers',
  },
  {
    title: 'Engineered for the target',
    description:
      'Software is built against the platform it runs on. Native desktop where it belongs, platform-specific templating where that is the right answer.',
    icon: 'layout-dashboard',
  },
  {
    title: 'Interface craft as a default',
    description:
      'Typography, spacing, contrast, and focus states are part of the specification. Dark and light are designed separately, never inverted.',
    icon: 'sun-moon',
  },
  {
    title: 'Your data stays yours',
    description:
      'Desktop products run on your machine. There is no account to create and nothing reports back to us, so nothing sits between you and your own work.',
    icon: 'shield-check',
  },
  {
    title: 'Maintained after release',
    description:
      'Every release carries a version number and documented behaviour. Compatibility fixes for the release you are running are part of the work rather than an upgrade cycle.',
    icon: 'refresh-cw',
  },
  {
    title: 'Talk to the people who build it',
    description:
      'Support comes from the engineers who wrote the product, so nobody routes you through a ticket queue or an account manager relaying messages.',
    icon: 'message-circle',
  },
]

/** Contents of the Perfect Panel Theme package. Product-scoped, not company-scoped. */
export const includedFeatures = [
  { title: 'Six editions', description: 'Ember, Ocean, Aurora, Cyan, Emerald, and Midnight.', icon: 'palette' },
  { title: 'Dark + light', description: 'Both modes designed to equal quality.', icon: 'sun-moon' },
  { title: 'Every page styled', description: 'From New Order to API and Tickets.', icon: 'layers' },
  { title: 'Mobile responsive', description: 'Clear ordering on any screen size.', icon: 'smartphone' },
  { title: 'Installation support', description: 'Guided or done-for-you setup.', icon: 'wrench' },
  { title: 'Free updates', description: 'Compatibility fixes for your release.', icon: 'refresh-cw' },
  { title: 'Source files', description: 'Organized, editable source included.', icon: 'file-code' },
  { title: 'Documentation', description: 'Practical setup and usage docs.', icon: 'book-open' },
]

export const howItWorks = [
  { title: 'Pick a product', description: 'Compare what each product does and confirm it fits your setup.', icon: 'mouse-pointer-click' },
  { title: 'Talk to us', description: 'Message us on WhatsApp or Telegram. We confirm compatibility and scope before you pay.', icon: 'message-square' },
  { title: 'Get your license', description: 'You receive the build, source or installer, and documentation, plus help getting it running.', icon: 'package-check' },
  { title: 'Ship it', description: 'Go live, then keep receiving compatibility updates for the release you bought.', icon: 'rocket' },
]

/**
 * Customer quotes are intentionally absent. The previous three were not from
 * verified customers, and publishing invented endorsements under real-looking
 * names and photographs is both dishonest and, for a company selling to a small
 * community that talks to itself, the fastest way to lose it.
 *
 * The `Testimonial` type in `./types` is kept for when real quotes exist. To
 * restore the section: repopulate here, re-add `<Testimonials />` in
 * `home-page.tsx`, and follow `docs/BRAND.md` §6 (no business names, ever).
 */
/**
 * The engineering standard, not the scale and not the billing. A two-product
 * company advertising "2 products shipped" undersells itself, and a company
 * that leads with "$0/mo" is describing a store rather than a software company
 * (`docs/BRAND.md` §1). Every value here is an engineering property a buyer can
 * check, and each covers a different dimension: where data lives, how the
 * software is built, whether it is maintained, and who answers when it breaks.
 *
 * Values must stay under ~10 characters or they overflow the hero grid; put
 * extra words in the label instead. See `docs/BRAND.md` §6.
 */
export const trustStats = [
  { value: 'Local', label: 'Your data' },
  { value: 'Native', label: 'Desktop builds' },
  { value: 'Versioned', label: 'Every release' },
  { value: 'Direct', label: 'Support' },
]

export const categoryContent: Record<
  ProductType,
  {
    slug: string
    eyebrow: string
    h1: string
    intro: string
    body: string[]
    emptyTitle: string
    emptyBody: string
    seo: { title: string; description: string; keywords: string[] }
  }
> = {
  app: {
    slug: 'apps',
    eyebrow: 'Desktop Apps',
    h1: 'Desktop applications built to run locally',
    intro:
      'Native desktop software for work that should not depend on a browser tab. Installed on your machine, with your data staying on disk.',
    body: [
      'A desktop application can do things a web app cannot. It keeps working when the connection drops, it reads and writes local files without an upload step, and it holds a database that belongs to you rather than to a vendor. For repetitive, high-volume work, that difference compounds.',
      'YTLeads Pro is the first VelixSoft desktop release. It runs on Windows and macOS, turns keyword searches into exportable contact lists across ten contact types, and stores every result locally. It launches without an account, and nothing syncs to a server.',
    ],
    emptyTitle: 'More desktop software is in development',
    emptyBody:
      'YTLeads Pro is available now. Further desktop releases are in engineering; tell us what workflow is costing you the most time.',
    seo: {
      title: 'Desktop Applications',
      description:
        'Native desktop software from VelixSoft for Windows and macOS. Runs locally, stores your data on your own machine, and launches without an account. Starting with YTLeads Pro.',
      keywords: [
        'desktop application',
        'Windows and macOS software',
        'local-first desktop app',
        'YTLeads Pro lead generator',
        'YouTube contact scraper',
      ],
    },
  },
  tool: {
    slug: 'tools',
    eyebrow: 'Automation & Tools',
    h1: 'Automation and developer tools',
    intro:
      'Small, sharp tools that remove a specific piece of manual work. Each one does a single job completely rather than a dozen jobs partially.',
    body: [
      'Most operational time is lost to work that is too small to justify a platform and too frequent to keep doing by hand: reformatting exports, validating records, reconciling pricing, checking that a config is actually correct. A focused tool pays for itself the first week.',
      'We are building this category to the same standard as our desktop software: defined inputs and outputs, no account required to try, and behaviour you can reason about. Releases are announced as they ship.',
    ],
    emptyTitle: 'This category is in development',
    emptyBody:
      'The first automation tools are being scoped now. If there is a repetitive task in your workflow worth automating, tell us what it is.',
    seo: {
      title: 'Automation & Developer Tools',
      description:
        'Focused automation and developer tools from VelixSoft. Each one solves a single repetitive workflow completely, with defined inputs and predictable behaviour.',
      keywords: ['automation tools', 'developer tools', 'workflow automation software', 'web tools'],
    },
  },
  data: {
    slug: 'data',
    eyebrow: 'Data Products',
    h1: 'Structured data products',
    intro:
      'Cleaned, documented data sets with stated record counts, formats, and update schedules. Data you can build a decision on.',
    body: [
      'Assembling reliable data is slow, and maintaining it is slower. A data product removes that work: the collection, deduplication, validation, and refresh are already done, and the methodology is written down so you know what you are looking at.',
      'Every VelixSoft data product ships with a documented schema, a stated record count, sample rows you can inspect before buying, and a defined update cadence. No opaque exports.',
    ],
    emptyTitle: 'This category is in development',
    emptyBody:
      'Our first data products are in preparation. Reach out if there is a specific data set that would change how you make decisions.',
    seo: {
      title: 'Data Products',
      description:
        'Structured, documented data products from VelixSoft with stated schemas, record counts, sample rows, and defined update schedules.',
      keywords: ['data products', 'structured data sets', 'curated data', 'market data'],
    },
  },
  theme: {
    slug: 'themes',
    eyebrow: 'Interface Themes',
    h1: 'Perfect Panel themes designed as complete systems',
    intro:
      'Premium Perfect Panel themes that turn a default install into a product customers trust. Each SMM panel theme ships with separately designed dark and light modes, responsive layouts, source files, and installation support.',
    body: [
      'A Perfect Panel theme is the fastest way to give an SMM panel a professional identity. Instead of the default look every panel ships with, a designed theme brings consistent typography, legible data tables, and considered order states across the entire dashboard.',
      'We build themes the way we build software: as one system with defined states, not a homepage skin. Every core page, from New Order to API and Tickets, is styled to the same standard, so the experience holds together from first visit through daily account management. Each release ships with organized source files and installation support.',
    ],
    emptyTitle: 'More editions are in design',
    emptyBody:
      'The Perfect Panel Theme is available now in six editions. Additional interface themes are in design.',
    seo: {
      title: 'Perfect Panel Themes',
      description:
        'Browse premium Perfect Panel themes with dark and light modes, responsive dashboard design, source files, and installation support.',
      keywords: ['Perfect Panel theme', 'SMM panel theme', 'Perfect Panel template', 'SMM panel dashboard design'],
    },
  },
}
