export const legalContent = {
  terms: {
    title: 'Terms of Service',
    description: 'The rules and conditions governing product licenses, custom design work, acceptable use, and liability limits for VelixSoft.',
    sections: [
      {
        title: 'Digital product license',
        body: [
          'When you purchase a digital product from VelixSoft, you get a non-exclusive, non-transferable license to install and use it for the agreed website, SMM panel, or project.',
          'You may not resell, sublicense, share, or redistribute source files, code, design assets, or themes, whether modified or unmodified, as a competing product or standalone download.',
        ],
      },
      {
        title: 'Intellectual property ownership',
        body: [
          'VelixSoft retains full ownership and intellectual property rights for all themes, source code, scripts, designs, and assets. Your purchase grants a license to use the work, not an assignment of ownership.',
        ],
      },
      {
        title: 'Acceptable use and restrictions',
        body: [
          'You agree not to reverse-engineer, decompile, crack, or bypass licensing mechanisms in any VelixSoft software or theme.',
          'Our products must not be used in connection with illegal services, fraudulent activities, or malicious software. We reserve the right to revoke support or access if a product is used maliciously.',
        ],
      },
      {
        title: 'Delivery and installation',
        body: [
          'Digital products are delivered through the contact channel confirmed during purchase, such as Telegram, WhatsApp, or email.',
          'Installation support covers reasonable help deploying the product to a compatible default environment. It does not cover troubleshooting unsupported server setups, third-party code modifications, or custom panel forks.',
        ],
      },
      {
        title: 'Compatibility and buyer responsibilities',
        body: [
          'You must confirm your platform software, PHP version, and panel compatibility before purchasing.',
          'Always create a full backup of your existing files, database, and configuration prior to installation. VelixSoft is not responsible for data loss or downtime caused by missing backups or unapproved modifications.',
        ],
      },
      {
        title: 'Limitation of liability and disclaimer',
        body: [
          'All products and services are provided "as is" without warranty of any kind, express or implied.',
          'VelixSoft is not liable for indirect, incidental, special, or consequential damages, including lost revenue, lost data, or operational interruptions resulting from the use or inability to use our products.',
        ],
      },
      {
        title: 'Support and updates',
        body: [
          'Support covers the delivered product and documented installation instructions for the major version purchased.',
          'Free updates apply to the purchased major version unless stated otherwise on the specific product page. We reserve the right to update these terms at any time.',
        ],
      },
    ],
  },
  privacy: {
    title: 'Privacy Policy',
    description: 'How VelixSoft collects, uses, and protects personal information across direct communication channels and website interactions.',
    sections: [
      {
        title: 'Information we collect',
        body: [
          'We collect information you choose to share when contacting us via email, WhatsApp, Telegram, or Discord. This includes your name, contact handle, platform version, project requirements, and purchase details.',
        ],
      },
      {
        title: 'How we use your information',
        body: [
          'Your details are used strictly to answer inquiries, verify platform compatibility, deliver purchased files, provide technical support, and maintain sales records.',
          'We do not sell, rent, trade, or share your personal information with third parties for marketing purposes.',
        ],
      },
      {
        title: 'Cookies and analytics',
        body: [
          'Our site uses only essential technical mechanisms necessary for page rendering and performance. We do not use intrusive cross-site tracking cookies or third-party advertising trackers.',
        ],
      },
      {
        title: 'Third-party communication platforms',
        body: [
          'When you reach out through external channels like WhatsApp, Telegram, or Discord, your communications are also governed by the privacy policies of those respective platforms.',
        ],
      },
      {
        title: 'Data retention and security',
        body: [
          'We keep inquiry and order details only as long as needed for ongoing support, accounting, and legal compliance. Access to client data is strictly restricted to essential team members.',
        ],
      },
      {
        title: 'Your rights and choices',
        body: [
          'You may request access to, updates for, or deletion of your contact records at any time by messaging us. Transaction details required for tax or accounting laws will be retained as legally required.',
        ],
      },
    ],
  },
  refund: {
    title: 'Refund Policy',
    description: 'Clear rules on refund eligibility, digital asset returns, and custom service cancellation terms.',
    sections: [
      {
        title: 'Digital product purchases',
        body: [
          'Because digital downloads, source files, and design assets cannot be returned once access or files are delivered, sales are generally final.',
          'Please verify your platform version, requirements, and features before making a purchase.',
        ],
      },
      {
        title: 'Eligible refund scenarios',
        body: [
          'We will issue a refund, store credit, or fix if the delivered product is materially different from its listed specifications, cannot be delivered, or has a critical defect that we fail to resolve within a reasonable timeframe.',
        ],
      },
      {
        title: 'Custom design and service work',
        body: [
          'Custom work is scoped and agreed upon before payment. Deposits reserve studio time and become non-refundable once design or code execution begins.',
          'Milestones, delivery schedules, and specific cancellation terms will be governed by your project agreement.',
        ],
      },
      {
        title: 'How to submit a request',
        body: [
          'To request a review, contact us through your original purchase channel with your order details, a description of the issue, and relevant screenshots or error logs.',
          'Nothing in this policy limits rights guaranteed under mandatory consumer protection laws.',
        ],
      },
    ],
  },
} as const

