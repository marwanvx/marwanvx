import type { AppProduct, Edition, EditionId, Product, ThemeProduct } from './types'

/**
 * The edition a first-time visitor sees, before any `velix-edition` value is
 * stored. This is the single source of truth: the pre-hydration script in
 * `app/layout.tsx` interpolates it, and `EditionProvider` imports it. Both must
 * agree, because the script paints first and the provider repaints on hydration
 * — if they disagree the brand colour visibly flips mid-load.
 *
 * Ocean matches the icon set and every off-site brand asset. See `docs/BRAND.md` §9.
 */
export const DEFAULT_EDITION_ID = 'ocean' satisfies EditionId

/**
 * Central launch values. Replace price/contact placeholders here and in
 * `site.ts` before launch. Prices are intentionally honest, not fabricated.
 */
export const EDITIONS: Edition[] = [
  {
    id: 'ember',
    name: 'Ember',
    swatch: '#d10000',
    tokens: {
      dark: { brand: '#e11d1d', brand600: '#d10000', brand400: '#f05252' },
      light: { brand: '#d10000', brand600: '#ad0000', brand400: '#e63232' },
    },
  },
  {
    id: 'ocean',
    name: 'Ocean',
    swatch: '#2563eb',
    tokens: {
      dark: { brand: '#3b82f6', brand600: '#2563eb', brand400: '#60a5fa' },
      light: { brand: '#2563eb', brand600: '#1d4ed8', brand400: '#3b82f6' },
    },
  },
  {
    id: 'aurora',
    name: 'Aurora',
    swatch: '#7c3aed',
    tokens: {
      dark: { brand: '#8b5cf6', brand600: '#7c3aed', brand400: '#a78bfa' },
      light: { brand: '#7c3aed', brand600: '#6d28d9', brand400: '#8b5cf6' },
    },
  },
  {
    id: 'cyan',
    name: 'Cyan',
    swatch: '#06b6d4',
    tokens: {
      dark: { brand: '#22d3ee', brand600: '#06b6d4', brand400: '#67e8f9' },
      light: { brand: '#0891b2', brand600: '#0e7490', brand400: '#06b6d4' },
    },
  },
  {
    id: 'emerald',
    name: 'Emerald',
    swatch: '#10b981',
    tokens: {
      dark: { brand: '#34d399', brand600: '#10b981', brand400: '#6ee7b7' },
      light: { brand: '#059669', brand600: '#047857', brand400: '#10b981' },
    },
  },
  {
    id: 'midnight',
    name: 'Midnight',
    swatch: '#4f46e5',
    tokens: {
      dark: { brand: '#6366f1', brand600: '#4f46e5', brand400: '#818cf8' },
      light: { brand: '#4f46e5', brand600: '#4338ca', brand400: '#6366f1' },
    },
  },
]

const perfectPanelTheme: ThemeProduct = {
  slug: 'perfect-panel-theme',
  name: 'Velix Perfect Panel Theme',
  tagline: 'A complete interface system for Perfect Panel.',
  type: 'theme',
  status: 'available',
  price: 149,
  currency: 'USD',
  shortDescription:
    'A complete SMM panel theme for Perfect Panel, built by VelixSoft. Choose your color edition (Ember, Ocean, Aurora, Cyan, Emerald, or Midnight) for $149.',
  longDescription: [
    'An SMM panel is not a checkout screen. It is the interface customers use to judge your reliability, place recurring orders, and trust you with their balance. Most panels ship with the same default styling, which makes careful operators look interchangeable with careless ones. The Velix Perfect Panel Theme replaces that default with a designed interface, without changing the workflows your customers already know. It is a complete SMM panel theme: 30 Perfect Panel template files, styled as one system.',
    'Every significant Perfect Panel surface is designed as one system: typography, spacing, forms, data tables, order states, navigation, tickets, payments, API documentation, and mobile controls. This is not a homepage skin. It is a consistent SMM panel dashboard design that holds together from the first visit through daily account management.',
    'Six editions ship with the product: Ember, Ocean, Aurora, Cyan, Emerald, and Midnight. You choose one at purchase. Each edition is a complete color direction built specifically for Perfect Panel, and dark and light modes are designed separately rather than inverted, with readable contrast, clear hierarchy, and deliberate elevation in both.',
    'The package includes organized source files, practical documentation, and direct installation help. After purchase we deliver the theme files and assist with setup. Perfect Panel supports custom theme uploads natively, so the theme installs into your panel admin without patching the platform.',
  ],
  features: [
    'Six complete color editions available',
    'Purpose-built dark and light modes',
    'Every core Perfect Panel page styled',
    'Responsive desktop and mobile layouts',
    'Accessible contrast and focus states',
    'Organized editable source files',
    'Installation documentation',
    'Direct setup support and free updates',
  ],
  included: [
    'Your selected color edition',
    'Dark and light mode',
    'Responsive theme files',
    'Source files and documentation',
    'Installation assistance',
    'Future compatibility updates',
  ],
  gallery: {
    slug: 'perfect-panel-theme',
    pages: [
      'home-hero',
      'home-full',
      'dashboard',
      'mobile-home-full',
      'mobile-dashboard-full',
    ],
  },
  faq: [
    {
      question: 'How does this theme integrate with Perfect Panel?',
      answer:
        'Perfect Panel allows panel owners to upload custom HTML/CSS/Twig themes. Our theme is built specifically for Perfect Panel, and setup assistance is included so it installs correctly into your admin dashboard.',
    },
    {
      question: 'How is it delivered and installed?',
      answer:
        'After purchase confirmation, you receive the theme package, source files, and documentation. We can guide your team through installation or install it for you after receiving the required limited access.',
    },
    {
      question: 'How do editions work?',
      answer:
        'You choose your preferred color edition (Ember, Ocean, Aurora, Cyan, Emerald, or Midnight) when purchasing. Your purchase includes your selected edition ready to install on your Perfect Panel.',
    },
    {
      question: 'Do you offer customization?',
      answer:
        'Yes. We can adapt an edition to your brand, refine individual screens, or create a fully custom SMM panel design. Custom work is scoped separately.',
    },
    {
      question: 'What is the refund policy?',
      answer:
        'Because the package is a digital product, refunds are limited once files have been delivered. If a verified compatibility issue cannot be resolved, contact us and we will review it fairly.',
    },
    {
      question: 'Do I get future updates?',
      answer:
        'Compatibility fixes and improvements to your purchased release are included. Major future products or fully redesigned editions may be sold separately.',
    },
  ],
  releasedAt: '2026-07-26',
  updatedAt: '2026-07-26',
  seo: {
    title: 'Perfect Panel Theme with 6 Color Editions',
    description:
      'A premium Perfect Panel theme by VelixSoft: six color editions, separately designed dark and light modes, responsive dashboard layouts, source files, and installation support.',
    keywords: [
      'Perfect Panel theme',
      'SMM panel theme',
      'Perfect Panel template',
      'SMM panel dashboard design',
      'custom SMM panel design',
    ],
  },
  editions: EDITIONS,
  platform: 'Perfect Panel',
  compatibility: [
    { label: 'Platform', value: 'Perfect Panel' },
    { label: 'Modes', value: 'Dark + Light' },
    { label: 'Responsive', value: 'Desktop, tablet, and mobile' },
    { label: 'Browsers', value: 'Current Chrome, Safari, Edge, and Firefox' },
    { label: 'Delivery', value: 'Theme files + source + documentation' },
    { label: 'Support', value: 'Installation assistance included' },
  ],
  styledPages: [
    '2fa.twig',
    'account.twig',
    'addfunds.twig',
    'affiliates.twig',
    'api.twig',
    'blog.twig',
    'blogpost.twig',
    'child_panel.twig',
    'child_panel_order.twig',
    'confirmemail.twig',
    'drip_feed.twig',
    'faq.twig',
    'layout.twig',
    'massorder.twig',
    'neworder.twig',
    'newpage.twig',
    'notifications.twig',
    'orders.twig',
    'refill.twig',
    'refunds.twig',
    'resetpassword.twig',
    'services.twig',
    'setnewpassword.twig',
    'signin.twig',
    'signup.twig',
    'subscriptions.twig',
    'terms.twig',
    'tickets.twig',
    'updates.twig',
    'viewticket.twig',
  ],
  installSteps: [
    {
      title: 'Prepare your panel',
      description:
        'Provide your Perfect Panel admin access or custom theme requirement preferences.',
    },
    {
      title: 'Choose your edition',
      description:
        'Select Ember, Ocean, Aurora, Cyan, Emerald, or Midnight as your launch direction.',
    },
    {
      title: 'Install the package',
      description:
        'Follow the included guide or ask us to help install the theme files safely.',
    },
    {
      title: 'Review and launch',
      description:
        'Check your content, payment methods, and mobile experience before publishing.',
    },
  ],
  changelog: [
    {
      version: '1.0.0',
      date: '2026-07-26',
      changes: [
        'Initial release with six editions',
        'Complete dark and light mode system',
        'Responsive styling for core Perfect Panel pages',
      ],
    },
  ],
}

const desktopApp: AppProduct = {
  slug: 'ytleads-pro',
  name: 'YTLeads Pro',
  tagline: 'A keyword goes in. An exportable contact list comes out.',
  type: 'app',
  status: 'available',
  price: 69,
  currency: 'USD',
  shortDescription:
    'A native desktop app for Windows and macOS that finds YouTube channels by keyword and extracts their public emails, WhatsApp, Telegram, and social handles into one exportable list.',
  longDescription: [
    'Prospect research on YouTube is a mechanical task: search a keyword, open channel after channel, read the About tab, copy whatever contact details are published, paste into a spreadsheet, repeat. It is precisely the kind of work software should be doing. YTLeads Pro is a desktop application built to do it: a YouTube lead generator that runs on your own machine, combining an email finder, a WhatsApp and Telegram contact scraper, and a social handle extractor in one tool.',
    'The workflow has three stages. Discover: enter the keywords your prospects would rank for, and the app queries YouTube directly, streaming back matching channels and videos while a discovery memory hides links you have already processed. Dashboard: send those links to the scraper, start the run, and watch contacts populate a live table across ten types (email, phone, WhatsApp, Telegram, Instagram, Facebook, X, LinkedIn, Discord, and Snapchat), color-coded and filterable as they arrive. History: every contact found is written to a local database that stays searchable and re-exportable.',
    'YTLeads Pro is a native desktop application, not a browser wrapper around a hosted service. It runs multi-threaded scraping locally, holds a small memory footprint during long runs, and needs no account to launch. Your keywords, your results, and your database stay on your machine, and the license is a one-time purchase rather than a monthly seat.',
  ],
  features: [
    'Keyword search built in: type what your customers search to find matching channels and videos',
    'Scrapes 10 contact types: public emails, phones, WhatsApp, Telegram, Instagram, Facebook, X, LinkedIn, Discord, and Snapchat',
    'One-click "Send to Dashboard": from keyword list to live scraping in seconds',
    'Live results table with color-coded contact types and instant search/filtering',
    'One-click outreach: right-click any contact to launch a WhatsApp chat or compose an email instantly',
    'Export to CSV or Excel with one dedicated sheet per contact type',
    'Discovery memory: automatically hides previously scraped links for fresh leads on every search',
    'Local contact database: search, filter, and re-export past scraping sessions anytime',
    'Status tracking: mark leads as imported as you push them into your outreach tools',
    'Optional YouTube cookies mode to bypass rate limits on massive lead generation runs',
    'Clean dark and light visual themes with complete data privacy',
  ],
  included: [
    'YTLeads Pro desktop application (Windows, macOS)',
    'Lifetime product license',
    'Built-in user guide and documentation',
    'Future compatibility and performance updates',
  ],
  gallery: {
    slug: 'ytleads-pro',
    pages: ['dashboard', 'discover', 'history', 'settings', 'help'],
  },
  faq: [
    {
      question: 'How does YTLeads Pro find contact information?',
      answer:
        'YTLeads Pro searches YouTube for channels and videos matching your keywords, then parses public email addresses, WhatsApp numbers, Telegram handles, and social links that creators have published on their channels.',
    },
    {
      question: 'Is my search data or lead list uploaded to any cloud server?',
      answer:
        'No. YTLeads Pro operates with complete privacy. Your keywords, scraped contacts, database, and settings stay private on your machine without cloud dependencies or seat fees.',
    },
    {
      question: 'What formats can I export my leads to?',
      answer:
        'You can export your leads to CSV or Excel files. Excel exports organize contacts into separate sheets by type (Emails, WhatsApp, Socials, etc.) for easy import into your CRM.',
    },
    {
      question: 'Which operating systems are supported?',
      answer:
        'YTLeads Pro runs smoothly on Windows 10/11 and macOS (Intel & Apple Silicon) with minimal system resources.',
    },
    {
      question: 'Do I get future updates?',
      answer:
        'Yes. All bug fixes, performance improvements, and compatibility updates for version 2.x are included with your purchase.',
    },
  ],
  releasedAt: '2026-05-14',
  updatedAt: '2026-07-26',
  seo: {
    title: 'YTLeads Pro for YouTube Lead Generation',
    description:
      'A native Windows and macOS desktop app by VelixSoft. Search YouTube by keyword and extract public emails, WhatsApp, Telegram, and social contacts to CSV or Excel. One-time license.',
    keywords: [
      'YTLeads Pro',
      'YouTube lead generator',
      'SMM lead scraper',
      'email finder desktop app',
      'WhatsApp lead finder',
      'Telegram channel scraper',
      'influencer contact finder',
      'B2B lead generation tool',
    ],
  },
  platforms: ['Windows 10/11', 'macOS (Intel & Apple Silicon)'],
  version: '2.0.0',
  systemRequirements: [
    { label: 'Platforms', value: 'Windows 10/11 or macOS 11+' },
    { label: 'Memory', value: '4 GB RAM minimum (8 GB recommended)' },
    { label: 'Storage', value: '150 MB available disk space' },
    { label: 'Network', value: 'Active internet connection' },
  ],
  downloadSize: '48 MB',
  changelog: [
    {
      version: '2.0.0',
      date: '2026-07-26',
      changes: [
        'Initial commercial release of YTLeads Pro',
        'Multi-threaded scraping engine with a bounded memory footprint on long runs',
        'Support for 10 public contact types',
        'Built-in discovery memory and multi-sheet Excel/CSV exporter',
      ],
    },
  ],
}

/**
 * Catalogue order is newest flagship first. The Perfect Panel Theme is the
 * current flagship release and leads the catalogue; `featured` styling follows
 * index 0. Company-level *messaging* still leads with software and automation
 * (see `docs/BRAND.md` §2) — that hierarchy governs how we describe VelixSoft,
 * not which product gets top billing.
 */
export const products: Product[] = [perfectPanelTheme, desktopApp]

export const getProduct = (slug: string) =>
  products.find((product) => product.slug === slug)

export const getProductsByType = (type: Product['type']) =>
  products.filter((product) => product.type === type)

export const getRelatedProducts = (product: Product) =>
  products.filter((candidate) => candidate.slug !== product.slug).slice(0, 3)

/** Named product exports for page compositions that target one product. */
export const perfectPanelProduct = perfectPanelTheme
export const ytLeadsProduct = desktopApp

/** @deprecated Use `perfectPanelProduct`. Kept so existing imports keep resolving. */
export const flagshipProduct = perfectPanelTheme

export function isThemeProduct(product: Product): product is ThemeProduct {
  return product.type === 'theme'
}

export function isAppProduct(product: Product): product is AppProduct {
  return product.type === 'app'
}

export function formatPrice(product: Product) {
  if (product.status === 'coming-soon' || product.price === 0) return 'Coming soon'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: product.currency,
    maximumFractionDigits: 0,
  }).format(product.price)
}

/** Resolve gallery paths from the documented filename pattern. */
export function galleryImagePath(input: {
  productSlug: string
  edition: string
  mode: 'dark' | 'light'
  device: 'desktop' | 'mobile'
  page: string
}) {
  const { productSlug, edition, mode, device, page } = input
  if (productSlug === 'ytleads-pro') {
    return `/products/ytleads-pro/${mode}-desktop-${page}.avif`
  }
  const segment = page.startsWith(`${device}-`) ? page : `${device}-${page}`
  return `/products/${productSlug}/${edition}-${mode}-${segment}.avif`
}

/**
 * Widest aspect ratio (height ÷ width) still worth submitting to image search.
 *
 * Image results are cropped to roughly square thumbnails, so a full-page
 * capture does not shrink, it gets sliced. `mobile-home-full` is 390x12106,
 * a ratio of 1:31; as a thumbnail that is either an illegible band or a crop of
 * three percent of the page picked at random. Submitting it would put a result
 * in front of buyers that looks worse than showing nothing.
 *
 * 2 keeps the 1440x900 page captures and drops the three full-page scrolls. It
 * is expressed as a ratio rather than a list of page names so a new capture is
 * judged on its actual shape instead of needing to be remembered here.
 */
const MAX_INDEXABLE_ASPECT_RATIO = 2

/**
 * Gallery screenshots worth submitting to image search, as site-absolute paths.
 *
 * The gallery swaps `src` in client state when the edition, mode, or device
 * changes, so only one combination is ever present in the server-rendered HTML.
 * Search engines discover images from markup they crawl, which left 88 of 92
 * screenshot files undiscoverable — including five of the six editions and
 * every light mode. This list feeds the image entries in `app/sitemap.ts`.
 *
 * Paths are derived from `galleryImagePath` rather than hand-written, because a
 * sitemap pointing at a 404 is worse than no sitemap at all. If the filename
 * pattern changes, both move together.
 *
 * Note this is deliberately narrower than what the gallery displays: the
 * full-page scrolls are valuable *on the page*, where a visitor can read them
 * top to bottom, and useless as a search thumbnail. The two jobs are different,
 * so the two lists are different.
 */
export function galleryImagePaths(product: Product): string[] {
  const editionIds =
    isThemeProduct(product) && product.editions?.length
      ? product.editions.map((edition) => edition.id)
      : ['app']
  const modes: Array<'dark' | 'light'> = ['dark', 'light']

  const indexablePages = product.gallery.pages.filter((page) => {
    const { width, height } = galleryImageSize(page)
    return height / width <= MAX_INDEXABLE_ASPECT_RATIO
  })

  return editionIds.flatMap((edition) =>
    modes.flatMap((mode) =>
      indexablePages.map((page) =>
        galleryImagePath({
          productSlug: product.slug,
          edition,
          mode,
          device: page.startsWith('mobile-') ? 'mobile' : 'desktop',
          page,
        }),
      ),
    ),
  )
}

/**
 * Images for the `Product` schema node, as site-absolute paths.
 *
 * `image` is a required property on `Product`. Omitting it made the node
 * ineligible for any product rich result, which is what Search Console reported
 * as a critical issue on 2026-08-02.
 *
 * Pinned to `DEFAULT_EDITION_ID` rather than the visitor's selected edition, so
 * the structured data does not change under a client interaction. What a
 * crawler reads should not depend on which swatch someone clicked.
 *
 * Google asks for several images per product. These are the desktop captures
 * that survive the aspect-ratio filter, both modes, which is four for the theme
 * and covers the two most representative screens for the app.
 */
export function schemaImagePaths(product: Product): string[] {
  const hasEditions = isThemeProduct(product) && Boolean(product.editions?.length)
  const edition = hasEditions ? DEFAULT_EDITION_ID : 'app'

  const pages = product.gallery.pages.filter((page) => {
    if (page.startsWith('mobile-')) return false
    const { width, height } = galleryImageSize(page)
    return height / width <= MAX_INDEXABLE_ASPECT_RATIO
  })

  return (['dark', 'light'] as const)
    .flatMap((mode) =>
      pages.map((page) =>
        galleryImagePath({ productSlug: product.slug, edition, mode, device: 'desktop', page }),
      ),
    )
    .slice(0, 6)
}

/** Intrinsic pixel size of each gallery screenshot, for correct aspect-ratio reservation. */
export function galleryImageSize(page: string): { width: number; height: number } {
  switch (page) {
    case 'home-full':
      return { width: 1440, height: 7272 }
    case 'mobile-home-full':
      return { width: 390, height: 12106 }
    case 'mobile-dashboard-full':
      return { width: 390, height: 2131 }
    default:
      return { width: 1440, height: 900 }
  }
}

/**
 * Alt text for a gallery screenshot.
 *
 * It names the product first, deliberately. The previous form read "Ocean
 * edition home hero on desktop in dark mode", which described the frame but
 * never said what was in it — nothing tied the image to Perfect Panel. For a
 * product whose buyers shop visually, Google Images is a real entry point, and
 * an image that never states its own subject cannot be matched to the query
 * that would find it. Naming the product is what alt text is for; it is not
 * keyword stuffing, and it must stay a plain description of the screenshot.
 *
 * `edition` is omitted for products that have no editions. Passing the product
 * name in its place produced "YTLeads Pro edition dashboard", which was wrong.
 */
export function galleryAlt(input: {
  productName: string
  edition?: string
  mode: string
  page: string
  device: string
}) {
  const page = input.page.replaceAll('-', ' ')
  const subject = input.edition
    ? `${input.productName}, ${input.edition} edition`
    : input.productName
  return `${subject}, ${page} on ${input.device} in ${input.mode} mode`
}

export function getProductThumbnail(product: Product, editionId: EditionId = DEFAULT_EDITION_ID): string {
  if (product.slug === 'ytleads-pro') {
    return '/products/ytleads-pro/dark-desktop-dashboard.avif'
  }
  return `/products/perfect-panel-theme/${editionId}-dark-desktop-home-hero.avif`
}

/**
 * Alt text for `getProductThumbnail`. It lives here so the description and the
 * path it describes are changed together — a card that says "dashboard" while
 * rendering the home hero is worse than no alt text at all.
 */
export function getProductThumbnailAlt(product: Product, editionId: EditionId = DEFAULT_EDITION_ID): string {
  if (product.slug === 'ytleads-pro') {
    return galleryAlt({ productName: product.name, mode: 'dark', page: 'dashboard', device: 'desktop' })
  }
  const edition = EDITIONS.find((candidate) => candidate.id === editionId)?.name
  return galleryAlt({ productName: product.name, edition, mode: 'dark', page: 'home page', device: 'desktop' })
}
