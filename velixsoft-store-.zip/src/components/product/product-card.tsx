'use client'

import Image from 'next/image'
import Link from 'next/link'
import { ArrowUpRight, Clock3, Layers3, MonitorSmartphone } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { formatPrice, getProductThumbnail, getProductThumbnailAlt } from '@/src/data/products'
import type { Product } from '@/src/data/types'
import { cn } from '@/lib/utils'
import { useEdition } from './edition-provider'

export function ProductCard({ product, featured = false }: { product: Product; featured?: boolean }) {
  const { edition } = useEdition()
  const thumbnail = getProductThumbnail(product, edition.id)

  return (
    <Card className={cn('group relative overflow-hidden rounded-3xl border-border bg-card/65 backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 flex flex-col justify-between', featured && 'brand-glow md:col-span-2 lg:col-span-2')}>
      <div>
        <div className="relative aspect-[16/9] w-full overflow-hidden border-b border-border bg-muted">
          <Image
            src={thumbnail}
            alt={getProductThumbnailAlt(product, edition.id)}
            fill
            sizes={featured ? '(max-width: 1024px) 100vw, 800px' : '(max-width: 1024px) 100vw, 450px'}
            className="object-cover object-top transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-black/30" />
          <div className="absolute left-4 top-4 flex items-center gap-2">
            <Badge className={cn('rounded-full capitalize shadow-md', product.status === 'available' ? 'bg-brand text-brand-foreground' : 'bg-muted text-muted-foreground')}>{product.status === 'available' ? 'Available' : 'Coming soon'}</Badge>
            <Badge variant="outline" className="rounded-full bg-background/80 backdrop-blur-md capitalize">{product.type}</Badge>
          </div>
          <span className="absolute right-4 top-4 rounded-full bg-background/80 px-3 py-1 text-sm font-semibold text-foreground backdrop-blur-md shadow-md">{formatPrice(product)}</span>
        </div>

        <CardHeader className="gap-3 p-6 sm:p-8">
          <CardTitle className={cn('tracking-[-0.035em]', featured ? 'text-3xl sm:text-4xl' : 'text-2xl')}>{product.name}</CardTitle>
          <CardDescription className="max-w-2xl text-base leading-7 text-muted-foreground">{product.shortDescription}</CardDescription>
        </CardHeader>

        <CardContent className="px-6 pb-6 sm:px-8">
          <div className={cn('grid gap-3', featured ? 'sm:grid-cols-3' : 'grid-cols-1')}>
            <Meta icon={<Layers3 />} text={`${product.features.length} core features`} />
            <Meta icon={<MonitorSmartphone />} text={product.type === 'theme' ? 'Responsive design' : 'Windows + macOS'} />
            <Meta icon={<Clock3 />} text={product.status === 'available' ? 'Available now' : 'In development'} />
          </div>
        </CardContent>
      </div>

      <CardFooter className="border-t border-border p-6 sm:px-8">
        <Button className="min-h-11 w-full rounded-full bg-brand px-5 text-brand-foreground hover:bg-brand-600" render={<Link href={`/products/${product.slug}`} />}>{product.status === 'available' ? 'View product' : 'See what’s coming'} <ArrowUpRight data-icon="inline-end" /></Button>
      </CardFooter>
    </Card>
  )
}

function Meta({ icon, text }: { icon: React.ReactNode; text: string }) {
  return <div className="flex min-h-11 items-center gap-2.5 rounded-xl bg-muted/60 px-3 text-sm text-muted-foreground [&_svg]:size-4 [&_svg]:text-brand">{icon}<span>{text}</span></div>
}
