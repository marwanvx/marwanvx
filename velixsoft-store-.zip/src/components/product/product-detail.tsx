'use client'

import Link from 'next/link'
import { ArrowLeft, ArrowUpRight, Bell, Check, Send } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Container, JsonLd, SectionHeading } from '@/src/components/ui/primitives'
import { ProductGallery } from './product-gallery'
import { EditionSwitcher } from './edition-switcher'
import { useEdition } from './edition-provider'
import { ProductCard } from './product-card'
import { FaqSection } from '@/src/components/sections/faq-section'
import { ContactCta } from '@/src/components/sections/contact-cta'
import { formatPrice, getRelatedProducts, isAppProduct, isThemeProduct, schemaImagePaths } from '@/src/data/products'
import { categoryNav, siteConfig, telegramLink, whatsappLink } from '@/src/data/site'
import type { Product } from '@/src/data/types'

import { WhatsAppIcon, TelegramIcon } from '@/src/components/ui/brand-icons'

export function ProductDetail({ product }: { product: Product }) {
  const { edition } = useEdition()
  const category = categoryNav.find((item) => item.type === product.type)!
  const isTheme = isThemeProduct(product)
  const buyMessage = isTheme
    ? `Hi, I'm interested in buying ${product.name} (${edition.name} edition) for $${product.price}`
    : `Hi, I'm interested in buying ${product.name} for $${product.price}`

  const offer = product.status === 'available'
    ? { '@type': 'Offer', price: product.price, priceCurrency: product.currency, availability: 'https://schema.org/InStock', url: `${siteConfig.url}/products/${product.slug}` }
    : { '@type': 'Offer', availability: 'https://schema.org/PreOrder', url: `${siteConfig.url}/products/${product.slug}` }

  const productSchema = {
    '@context': 'https://schema.org', '@type': 'Product', name: product.name, description: product.shortDescription,
    image: schemaImagePaths(product).map((path) => `${siteConfig.url}${path}`),
    category: product.type,
    brand: { '@type': 'Brand', name: 'VelixSoft' },
    manufacturer: { '@id': `${siteConfig.url}/#organization` },
    releaseDate: product.releasedAt,
    offers: offer,
  }

  /** Desktop applications also declare SoftwareApplication for software-specific results. */
  const softwareSchema = isAppProduct(product)
    ? {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        name: product.name,
        description: product.shortDescription,
        applicationCategory: 'BusinessApplication',
        operatingSystem: product.platforms.join(', '),
        softwareVersion: product.version,
        fileSize: product.downloadSize,
        datePublished: product.releasedAt,
        publisher: { '@id': `${siteConfig.url}/#organization` },
        offers: offer,
      }
    : null
  const breadcrumbSchema = { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Products', item: `${siteConfig.url}/products` }, { '@type': 'ListItem', position: 2, name: category.label, item: `${siteConfig.url}${category.href}` }, { '@type': 'ListItem', position: 3, name: product.name, item: `${siteConfig.url}/products/${product.slug}` }] }
  const faqSchema = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: product.faq.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) }
  const related = getRelatedProducts(product)

  return (
    <>
      <JsonLd data={softwareSchema ? [productSchema, softwareSchema, breadcrumbSchema, faqSchema] : [productSchema, breadcrumbSchema, faqSchema]} />
      <section className="pb-20 pt-14 sm:pt-20">
        <Container>
          <nav aria-label="Breadcrumb" className="mb-8 flex items-center gap-2 text-sm text-muted-foreground"><Link href="/products" className="hover:text-foreground">Products</Link><span>/</span><Link href={category.href} className="hover:text-foreground">{category.label}</Link><span>/</span><span className="text-foreground">{product.name}</span></nav>
          <div className="grid items-start gap-10 lg:grid-cols-[1.2fr_.8fr] lg:gap-14">
            <ProductGallery product={product} priority />
            {product.gallery.pages.length === 0 && <div className="glass flex aspect-[4/3] items-center justify-center rounded-3xl"><div className="flex max-w-sm flex-col items-center gap-4 p-8 text-center"><span className="flex size-16 items-center justify-center rounded-2xl bg-brand-soft text-3xl font-bold text-brand">P</span><p className="text-sm leading-6 text-muted-foreground">Product visuals and screenshots will be published soon.</p></div></div>}
            <aside className="glass-elevated rounded-3xl p-6 lg:sticky lg:top-28 sm:p-8">
              <div className="flex flex-col gap-6">
                <div className="flex items-center gap-2"><Badge className="rounded-full bg-brand text-brand-foreground capitalize">{product.status === 'available' ? 'Available now' : 'Coming soon'}</Badge><Badge variant="outline" className="rounded-full capitalize">{product.type}</Badge></div>
                <div className="flex flex-col gap-3"><h1 className="text-balance text-4xl font-semibold tracking-[-0.05em]">{product.name}</h1><p className="text-sm text-muted-foreground">A product by <Link href="/about" className="font-medium text-brand hover:underline">VelixSoft</Link></p><p className="text-lg leading-7 text-muted-foreground">{product.shortDescription}</p></div>
                <p className="text-3xl font-semibold">{formatPrice(product)}</p>
                <div className="flex flex-col gap-3 border-y border-border py-5"><p className="text-sm font-semibold">What you get</p><ul className="flex flex-col gap-2.5">{product.included.map((item) => <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground"><Check className="mt-0.5 size-4 shrink-0 text-brand" />{item}</li>)}</ul></div>
                {product.status === 'available' ? <div className="flex flex-col gap-3"><Button className="min-h-12 w-full rounded-full bg-brand text-brand-foreground hover:bg-brand-600 gap-2 font-medium" render={<a href={whatsappLink(buyMessage)} target="_blank" rel="noreferrer" />}><WhatsAppIcon className="size-4 shrink-0" /><span>Buy a license</span></Button><Button variant="outline" className="min-h-12 w-full rounded-full gap-2 font-medium" render={<a href={telegramLink(buyMessage)} target="_blank" rel="noreferrer" />}><TelegramIcon className="size-4 shrink-0" /><span>Ask on Telegram</span></Button><p className="text-center text-xs text-muted-foreground">One-time license. Installation help included.</p></div> : <div className="flex flex-col gap-3"><Button className="min-h-12 w-full rounded-full bg-brand text-brand-foreground hover:bg-brand-600" render={<Link href={`/contact?product=${product.slug}`} />}>Notify me at launch <Bell data-icon="inline-end" /></Button><p className="text-center text-xs text-muted-foreground">No payment required. We share release details when the build is ready.</p></div>}
              </div>
            </aside>
          </div>
        </Container>
      </section>

      <section className="py-20 sm:py-28"><Container><div className="grid gap-12 lg:grid-cols-[.7fr_1.3fr]"><SectionHeading eyebrow="About the product" title={product.tagline} /><div className="flex flex-col gap-6">{product.longDescription.map((paragraph) => <p key={paragraph.slice(0, 40)} className="text-base leading-8 text-muted-foreground sm:text-lg">{paragraph}</p>)}</div></div></Container></section>

      {isThemeProduct(product) && <ThemeDetails product={product} />}
      {isAppProduct(product) && <AppDetails product={product} />}
      {product.type === 'tool' && <ToolDetails product={product} />}
      {product.type === 'data' && <DataDetails product={product} />}

      {'changelog' in product && product.changelog.length > 0 && <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Release notes" title="What changed, and when." /><div className="mt-10 flex flex-col gap-4">{product.changelog.map((entry) => <article key={`${entry.version}-${entry.date}`} className="glass grid gap-4 rounded-2xl p-5 sm:grid-cols-[9rem_1fr]"><div><p className="font-mono text-sm font-semibold text-brand">v{entry.version}</p><time dateTime={entry.date} className="mt-1 block text-xs text-muted-foreground">{entry.date}</time></div><ul className="flex flex-col gap-2">{entry.changes.map((change) => <li key={change} className="flex gap-2 text-sm leading-6 text-muted-foreground"><Check className="mt-1 size-4 shrink-0 text-brand" />{change}</li>)}</ul></article>)}</div></Container></section>}

      {product.faq.length > 0 && <FaqSection faqs={product.faq} title={`About ${product.name}`} />}

      {related.length > 0 && <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Keep exploring" title="More from VelixSoft" /><div className="mt-10 grid gap-5 lg:grid-cols-3">{related.map((item) => <ProductCard key={item.slug} product={item} />)}</div></Container></section>}
      <ContactCta title={product.status === 'available' ? `Get ${product.name}.` : `Be first to know about ${product.name}.`} />
    </>
  )
}

function ThemeDetails({ product }: { product: Extract<Product, { type: 'theme' }> }) {
  return <>
    <section className="py-20 sm:py-28"><Container><div className="grid gap-10 lg:grid-cols-2"><div><SectionHeading eyebrow="Compatibility" title="Built for Perfect Panel." description="Confirm your platform version before delivery and we handle the version-specific details." /><dl className="mt-8 overflow-hidden rounded-2xl border border-border">{product.compatibility.map((row) => <div key={row.label} className="grid grid-cols-[.7fr_1.3fr] border-b border-border bg-card/50 p-4 last:border-0"><dt className="text-sm text-muted-foreground">{row.label}</dt><dd className="text-sm font-medium">{row.value}</dd></div>)}</dl></div><div><SectionHeading eyebrow="Installation" title="A controlled, four-step launch." /><ol className="mt-8 flex flex-col gap-3">{product.installSteps.map((step, index) => <li key={step.title} className="glass flex gap-4 rounded-2xl p-5"><span className="font-mono text-sm text-brand">0{index + 1}</span><div className="flex flex-col gap-1"><h3 className="font-semibold">{step.title}</h3><p className="text-sm leading-6 text-muted-foreground">{step.description}</p></div></li>)}</ol></div></div></Container></section>
    <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Styled pages" title="The whole panel, not just the landing page." /><div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">{product.styledPages.map((page) => <div key={page} className="flex min-h-20 items-center gap-2 rounded-2xl border border-border bg-card/55 p-4 text-sm font-medium"><Check className="size-4 text-brand" />{page}</div>)}</div></Container></section>
  </>
}

function AppDetails({ product }: { product: Extract<Product, { type: 'app' }> }) {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Technical details" title="Native, local, and documented." /><div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"><Info title="Platforms" value={product.platforms.join(', ')} /><Info title="Version" value={product.version} /><Info title="Download size" value={product.downloadSize} />{product.systemRequirements.map((item) => <Info key={item.label} title={item.label} value={item.value} />)}</div></Container></section>
}

function ToolDetails({ product }: { product: Extract<Product, { type: 'tool' }> }) {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Tool Details" title="One job, done completely." /><div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"><Info title="Type" value="Web Tool" /><Info title="Status" value={product.status === 'available' ? 'Available' : 'Coming soon'} /></div></Container></section>
}

function DataDetails({ product }: { product: Extract<Product, { type: 'data' }> }) {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Data Details" title="Documented data for operational decisions." /><div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"><Info title="Format" value="CSV / JSON" /><Info title="Status" value={product.status === 'available' ? 'Available' : 'Coming soon'} /></div></Container></section>
}

function Info({ title, value }: { title: string; value: string }) { return <Card className="rounded-2xl bg-card/55"><CardHeader><CardDescription>{title}</CardDescription><CardTitle className="text-lg">{value}</CardTitle></CardHeader></Card> }
