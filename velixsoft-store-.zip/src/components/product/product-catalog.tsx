'use client'

import * as React from 'react'
import { Button } from '@/components/ui/button'
import { Container, EmptyCategory } from '@/src/components/ui/primitives'
import { ProductCard } from '@/src/components/product/product-card'
import type { Product, ProductType } from '@/src/data/types'
import { cn } from '@/lib/utils'

type FilterCategory = 'all' | ProductType

const categories: { label: string; value: FilterCategory }[] = [
  { label: 'All', value: 'all' },
  { label: 'Desktop Apps', value: 'app' },
  { label: 'Automation & Tools', value: 'tool' },
  { label: 'Data Products', value: 'data' },
  { label: 'Interface Themes', value: 'theme' },
]

export function ProductCatalog({ products }: { products: Product[] }) {
  const [activeCategory, setActiveCategory] = React.useState<FilterCategory>('all')

  const filteredProducts = React.useMemo(() => {
    if (activeCategory === 'all') return products
    return products.filter((product) => product.type === activeCategory)
  }, [activeCategory, products])

  return (
    <section className="pb-24">
      <Container>
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Product categories">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.value
              const count = cat.value === 'all'
                ? products.length
                : products.filter((p) => p.type === cat.value).length
              return (
                <button
                  type="button"
                  key={cat.value}
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(cat.value)}
                  className={cn(
                    'flex min-h-11 items-center gap-2 rounded-full border px-4 text-sm font-medium transition-all duration-200 cursor-pointer',
                    isActive
                      ? 'border-brand bg-brand text-brand-foreground shadow-md'
                      : 'border-border bg-background/50 text-muted-foreground hover:border-brand/40 hover:text-foreground'
                  )}
                >
                  <span>{cat.label}</span>
                  <span className={cn('rounded-full px-2 py-0.5 text-xs', isActive ? 'bg-brand-foreground/20 text-brand-foreground' : 'bg-muted text-muted-foreground')}>
                    {count}
                  </span>
                </button>
              )
            })}
          </div>

          <p className="text-xs text-muted-foreground">
            Showing {filteredProducts.length} of {products.length} products
          </p>
        </div>

        {filteredProducts.length > 0 ? (
          <div className="grid gap-5 lg:grid-cols-3">
            {filteredProducts.map((product, index) => (
              <ProductCard key={product.slug} product={product} featured={activeCategory === 'all' && index === 0} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center gap-6 py-12">
            <EmptyCategory
              title="Nothing published in this category yet"
              body="This category is in active development. Tell us which workflow costs you the most time and it will inform what we build next."
            />
            <Button
              variant="outline"
              onClick={() => setActiveCategory('all')}
              className="rounded-full"
            >
              View all products
            </Button>
          </div>
        )}
      </Container>
    </section>
  )
}
