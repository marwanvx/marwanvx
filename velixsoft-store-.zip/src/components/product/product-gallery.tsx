'use client'

import * as React from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, Expand, Laptop, Moon, Smartphone, Sun } from 'lucide-react'
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { galleryAlt, galleryImagePath, galleryImageSize } from '@/src/data/products'
import type { GalleryPage, Product } from '@/src/data/types'
import { EditionSwitcher } from './edition-switcher'
import { useEdition } from './edition-provider'

type Mode = 'dark' | 'light'
type Device = 'desktop' | 'mobile'

const labels: Record<GalleryPage, string> = {
  'home-hero': 'Home Hero',
  'home-full': 'Home Page',
  dashboard: 'Dashboard',
  discover: 'Discover',
  history: 'History',
  settings: 'Settings',
  help: 'Help',
  'mobile-home-full': 'Home Page',
  'mobile-dashboard-full': 'Dashboard',
}

function validPages(device: Device, pages: GalleryPage[]) {
  return pages.filter((page) => device === 'desktop' ? !page.startsWith('mobile-') : page.startsWith('mobile-'))
}

export function ProductGallery({ product, priority = false, minimal = false }: { product: Product; priority?: boolean; minimal?: boolean }) {
  const { edition } = useEdition()
  const [mode, setMode] = React.useState<Mode>('dark')
  const [device, setDevice] = React.useState<Device>('desktop')
  const [page, setPage] = React.useState<GalleryPage>('dashboard')
  const [lightbox, setLightbox] = React.useState(false)
  const pages = validPages(device, product.gallery.pages)
  const safePage = pages.includes(page) ? page : pages[0]

  React.useEffect(() => {
    if (!pages.includes(page) && pages[0]) setPage(pages[0])
  }, [device, page, pages])

  if (!product.gallery.pages.length || !pages.length || !safePage) return null

  const hasEditions = 'editions' in product && Array.isArray(product.editions) && product.editions.length > 0
  const activeEditionId = hasEditions ? edition.id : 'app'
  const activeEditionName = hasEditions ? edition.name : undefined

  const path = galleryImagePath({ productSlug: product.slug, edition: activeEditionId, mode, device, page: safePage })
  const alt = galleryAlt({ productName: product.name, edition: activeEditionName, mode, device, page: safePage })
  const size = galleryImageSize(safePage)
  const index = pages.indexOf(safePage)

  function navigate(delta: number) {
    setPage(pages[(index + delta + pages.length) % pages.length])
  }

  return (
    <div className="flex flex-col gap-5">
      {!minimal && (
        <div className="glass flex flex-col gap-4 rounded-2xl p-4">
          {hasEditions && product.editions && <EditionSwitcher editions={product.editions} />}
          <div className="flex flex-wrap items-center gap-3 border-t border-border pt-4">
            <ControlGroup label="Display mode">
              <Toggle active={mode === 'dark'} onClick={() => setMode('dark')} icon={<Moon />} label="Dark" />
              <Toggle active={mode === 'light'} onClick={() => setMode('light')} icon={<Sun />} label="Light" />
            </ControlGroup>
            {product.type === 'theme' && (
              <ControlGroup label="Device">
                <Toggle active={device === 'desktop'} onClick={() => setDevice('desktop')} icon={<Laptop />} label="Desktop" />
                <Toggle active={device === 'mobile'} onClick={() => setDevice('mobile')} icon={<Smartphone />} label="Mobile" />
              </ControlGroup>
            )}
          </div>
          <div role="tablist" aria-label="Select screenshot page" className="flex flex-wrap gap-2 border-t border-border pt-4">
            {pages.map((item) => <button type="button" role="tab" aria-selected={safePage === item} key={item} onClick={() => setPage(item)} className={cn('min-h-11 rounded-full border px-4 text-sm font-medium transition-colors', safePage === item ? 'border-brand bg-brand text-brand-foreground' : 'border-border bg-background/50 text-muted-foreground hover:text-foreground')}>{labels[item]}</button>)}
          </div>
        </div>
      )}

      <ScreenshotFrame device={device} path={path} alt={alt} size={size} priority={priority} onExpand={() => setLightbox(true)} allowScroll={!minimal} />

      <LightboxDialog open={lightbox} onOpenChange={setLightbox} path={path} alt={alt} size={size} navigate={navigate} />
    </div>
  )
}

function ControlGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex items-center gap-1 rounded-full border border-border bg-background/50 p-1" role="group" aria-label={label}>{children}</div>
}

function Toggle({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return <button type="button" aria-pressed={active} onClick={onClick} className={cn('flex min-h-11 items-center gap-2 rounded-full px-3 text-sm font-medium transition-colors [&_svg]:size-4', active ? 'bg-brand text-brand-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}>{icon}<span>{label}</span></button>
}

function ScreenshotFrame({ device, path, alt, size, priority, onExpand, allowScroll = false }: { device: Device; path: string; alt: string; size: { width: number; height: number }; priority: boolean; onExpand: () => void; allowScroll?: boolean }) {
  const phone = device === 'mobile'
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    setLoading(true)
  }, [path])

  /**
   * Only the full-page captures are taller than they are wide, and only those
   * can outgrow the frame. A standard 1440x900 screenshot always fits, so
   * giving it `overflow-y-auto` produces a native scrollbar on hover with
   * nothing to scroll: the sticky expand button contributes ~44px of flow
   * height and sub-pixel rounding on `h-auto w-full` supplies the rest.
   * Deciding from the intrinsic aspect ratio keeps this correct at any width.
   */
  const needsScroll = allowScroll && size.height > size.width

  return (
    <div className={cn('relative mx-auto overflow-hidden border border-border bg-card shadow-2xl transition-all duration-300', phone ? 'w-full max-w-[22rem] rounded-[2.5rem] p-2.5' : 'w-full rounded-2xl')}>
      {phone ? <div className="mx-auto mb-2 h-5 w-24 rounded-full bg-foreground/15" /> : <div className="flex h-10 items-center gap-2 border-b border-border bg-muted/50 px-4"><span className="size-2.5 rounded-full bg-brand/70" /><span className="size-2.5 rounded-full bg-muted-foreground/40" /><span className="size-2.5 rounded-full bg-muted-foreground/30" /><div className="ml-3 h-5 flex-1 rounded-md bg-background/60" /></div>}
      <button type="button" onClick={onExpand} aria-label={`Open full-size: ${alt}`} className={cn('group relative block w-full bg-muted/50 min-h-[320px]', needsScroll ? 'max-h-[44rem] overflow-y-auto' : 'overflow-hidden', phone ? 'rounded-[1.8rem]' : 'rounded-b-xl')}>
        
        {/* Smart Loader Overlay */}
        <div
          className={cn(
            'absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-card/80 backdrop-blur-md transition-all duration-300',
            loading ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          )}
        >
          <div className="relative flex size-12 items-center justify-center">
            <div className="absolute inset-0 rounded-full border-2 border-brand/20 border-t-brand animate-spin" />
            <div className="size-3 rounded-full bg-brand animate-pulse" />
          </div>
          <span className="text-xs font-semibold tracking-wider uppercase text-muted-foreground">Loading image...</span>
        </div>

        <Image
          src={path}
          alt={alt}
          width={size.width}
          height={size.height}
          priority={priority}
          onLoad={() => setLoading(false)}
          sizes={phone ? '(max-width: 640px) 90vw, 352px' : '(max-width: 1024px) 100vw, 900px'}
          className={cn('h-auto w-full transition-all duration-300', loading ? 'opacity-40 blur-[2px]' : 'opacity-100 blur-0')}
        />
        {/* Sticky only when the frame scrolls, so it stays pinned while reading
            a long capture. Otherwise absolute, so it contributes no flow height
            and cannot push a fitting image into overflow. */}
        <span
          className={cn(
            'flex size-11 items-center justify-center rounded-full bg-background/90 text-foreground shadow-lg backdrop-blur transition-transform group-hover:scale-105',
            needsScroll ? 'sticky bottom-3 ml-auto mr-3' : 'absolute bottom-3 right-3',
          )}
          aria-hidden="true"
        >
          <Expand className="size-4" />
        </span>
      </button>
    </div>
  )
}

/** Widest the image can render inside the dialog: max-w-6xl minus p-3 gutters. */
const LIGHTBOX_MAX_WIDTH = 1128

function LightboxDialog({ open, onOpenChange, path, alt, size, navigate }: { open: boolean; onOpenChange: (open: boolean) => void; path: string; alt: string; size: { width: number; height: number }; navigate: (delta: number) => void }) {
  const [modalLoading, setModalLoading] = React.useState(true)
  const scrollRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    setModalLoading(true)
    scrollRef.current?.scrollTo({ top: 0 })
  }, [path])

  /**
   * Full-page captures are far taller than the viewport. Fitting them to the
   * dialog height shrinks them to an unreadable sliver, so they render at full
   * width and the frame scrolls instead. Regular screenshots still fit.
   */
  const tall = size.height > size.width

  /** Never upscale: a 390px-wide mobile capture stays 390px, not stretched to 1128px. */
  const renderedWidth = Math.min(size.width, LIGHTBOX_MAX_WIDTH)

  React.useEffect(() => {
    if (!open) return
    function onKey(event: KeyboardEvent) {
      if (event.key === 'ArrowLeft') navigate(-1)
      if (event.key === 'ArrowRight') navigate(1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, navigate])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[94vh] max-w-[95vw] overflow-hidden border-border bg-popover p-3 sm:max-w-6xl">
        <DialogTitle className="sr-only">{alt}</DialogTitle>
        <DialogDescription className="sr-only">Full-size product screenshot. Use arrow keys or controls to browse. Press Escape to close.</DialogDescription>
        <div className="relative">
          <div
            ref={scrollRef}
            className={cn(
              'max-h-[88vh] min-h-[360px] rounded-xl bg-background',
              tall ? 'overflow-y-auto' : 'flex items-center justify-center overflow-hidden',
            )}
          >
            <Image
              src={path}
              alt={alt}
              width={size.width}
              height={size.height}
              onLoad={() => setModalLoading(false)}
              style={tall ? { maxWidth: renderedWidth } : undefined}
              className={cn(
                'transition-all duration-300',
                tall ? 'mx-auto h-auto w-full' : 'h-auto max-h-[88vh] w-auto max-w-full',
                modalLoading ? 'opacity-40 blur-[2px]' : 'opacity-100 blur-0',
              )}
              sizes={tall ? `${renderedWidth}px` : '95vw'}
            />
          </div>

          {/* Loader and controls sit outside the scroll area so they stay put
              while a tall capture scrolls underneath. */}
          <div
            className={cn(
              'pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 rounded-xl bg-card/85 backdrop-blur-md transition-all duration-300',
              modalLoading ? 'opacity-100' : 'opacity-0',
            )}
          >
            <div className="relative flex size-12 items-center justify-center">
              <div className="absolute inset-0 rounded-full border-2 border-brand/20 border-t-brand animate-spin" />
              <div className="size-3 rounded-full bg-brand animate-pulse" />
            </div>
            <span className="text-xs font-semibold tracking-wider uppercase text-muted-foreground">Loading image...</span>
          </div>

          <Button size="icon-lg" variant="secondary" aria-label="Previous screenshot" onClick={() => navigate(-1)} className="absolute left-3 top-1/2 z-30 min-h-11 min-w-11 -translate-y-1/2 rounded-full shadow-lg"><ChevronLeft /></Button>
          <Button size="icon-lg" variant="secondary" aria-label="Next screenshot" onClick={() => navigate(1)} className="absolute right-3 top-1/2 z-30 min-h-11 min-w-11 -translate-y-1/2 rounded-full shadow-lg"><ChevronRight /></Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
