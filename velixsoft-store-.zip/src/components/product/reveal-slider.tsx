'use client'

import * as React from 'react'
import Image from 'next/image'
import { ArrowLeftRight, Moon, Sun } from 'lucide-react'
import { galleryAlt, galleryImagePath } from '@/src/data/products'
import type { ThemeProduct } from '@/src/data/types'
import { useEdition } from './edition-provider'

export function RevealSlider({ product }: { product: ThemeProduct }) {
  const { edition } = useEdition()
  const [position, setPosition] = React.useState(50)
  const ref = React.useRef<HTMLDivElement>(null)

  if (!product.editions?.length) return null

  const darkPath = galleryImagePath({ productSlug: product.slug, edition: edition.id, mode: 'dark', device: 'desktop', page: 'dashboard' })
  const lightPath = galleryImagePath({ productSlug: product.slug, edition: edition.id, mode: 'light', device: 'desktop', page: 'dashboard' })

  function update(clientX: number) {
    const rect = ref.current?.getBoundingClientRect()
    if (!rect) return
    setPosition(Math.max(2, Math.min(98, ((clientX - rect.left) / rect.width) * 100)))
  }

  function onPointerDown(event: React.PointerEvent) {
    event.currentTarget.setPointerCapture(event.pointerId)
    update(event.clientX)
  }

  return (
    <div
      ref={ref}
      className="relative aspect-[16/10] w-full touch-none overflow-hidden rounded-2xl border border-border bg-card shadow-2xl sm:rounded-3xl"
      onPointerDown={onPointerDown}
      onPointerMove={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) update(event.clientX) }}
    >
      <Image src={lightPath} alt={galleryAlt({ productName: product.name, edition: edition.name, mode: 'light', page: 'dashboard', device: 'desktop' })} fill sizes="(max-width: 1280px) 100vw, 1200px" className="object-cover object-top" />
      <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }} aria-hidden="true">
        <Image src={darkPath} alt="" fill sizes="(max-width: 1280px) 100vw, 1200px" className="object-cover object-top" />
      </div>
      <div className="absolute left-4 top-4 flex min-h-10 items-center gap-2 rounded-full bg-foreground px-3 text-sm font-semibold text-background shadow-lg"><Moon className="size-4" /> Dark</div>
      <div className="absolute right-4 top-4 flex min-h-10 items-center gap-2 rounded-full bg-foreground px-3 text-sm font-semibold text-background shadow-lg"><Sun className="size-4" /> Light</div>
      <div className="absolute inset-y-0 w-px bg-foreground shadow-[0_0_0_1px_rgba(0,0,0,.25)]" style={{ left: `${position}%` }} />
      <button
        type="button"
        role="slider"
        aria-label="Compare dark and light modes"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(position)}
        onKeyDown={(event) => {
          if (event.key === 'ArrowLeft') setPosition((value) => Math.max(0, value - 5))
          if (event.key === 'ArrowRight') setPosition((value) => Math.min(100, value + 5))
          if (event.key === 'Home') setPosition(0)
          if (event.key === 'End') setPosition(100)
        }}
        className="absolute top-1/2 flex size-12 -translate-x-1/2 -translate-y-1/2 cursor-ew-resize items-center justify-center rounded-full border-4 border-background bg-brand text-brand-foreground shadow-xl sm:size-14"
        style={{ left: `${position}%` }}
      >
        <ArrowLeftRight className="size-5" />
      </button>
    </div>
  )
}
