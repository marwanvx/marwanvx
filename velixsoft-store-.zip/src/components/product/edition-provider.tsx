'use client'

import * as React from 'react'
import { DEFAULT_EDITION_ID, EDITIONS } from '@/src/data/products'
import type { Edition, EditionId } from '@/src/data/types'

/**
 * Resolved once. Every fallback below routes through this rather than
 * `EDITIONS[0]`, which silently means "whichever edition happens to be first in
 * the array" and drifts the moment that array is reordered.
 */
const DEFAULT_EDITION: Edition = EDITIONS.find((item) => item.id === DEFAULT_EDITION_ID) ?? EDITIONS[0]

type EditionContextValue = {
  edition: Edition
  setEdition: (edition: EditionId) => void
  applyEdition: (edition: EditionId) => void
}

const EditionContext = React.createContext<EditionContextValue | null>(null)

function writeTokens(edition: Edition) {
  const isDark = document.documentElement.classList.contains('dark')
  const tokens = isDark ? edition.tokens.dark : edition.tokens.light
  const root = document.documentElement.style
  root.setProperty('--brand', tokens.brand)
  root.setProperty('--brand-600', tokens.brand600)
  root.setProperty('--brand-400', tokens.brand400)
  root.setProperty('--brand-soft', `${tokens.brand}22`)
  document.documentElement.dataset.edition = edition.id
}

export function EditionProvider({ children }: { children: React.ReactNode }) {
  const [editionId, setEditionId] = React.useState<EditionId>(DEFAULT_EDITION_ID)

  React.useEffect(() => {
    const stored = localStorage.getItem('velix-edition') as EditionId | null
    const valid = EDITIONS.some((item) => item.id === stored)
    const next = valid && stored ? stored : DEFAULT_EDITION_ID
    setEditionId(next)
    const edition = EDITIONS.find((item) => item.id === next) ?? DEFAULT_EDITION
    writeTokens(edition)
  }, [])

  const applyEdition = React.useCallback((id: EditionId) => {
    const next = EDITIONS.find((item) => item.id === id)
    if (!next) return
    setEditionId(id)
    localStorage.setItem('velix-edition', id)
    writeTokens(next)
  }, [])

  const edition = EDITIONS.find((item) => item.id === editionId) ?? DEFAULT_EDITION

  return (
    <EditionContext.Provider value={{ edition, setEdition: applyEdition, applyEdition }}>
      {children}
    </EditionContext.Provider>
  )
}

export function useEdition() {
  const context = React.useContext(EditionContext)
  if (!context) throw new Error('useEdition must be used inside EditionProvider')
  return context
}

export function syncCurrentEdition() {
  const id = (localStorage.getItem('velix-edition') ?? DEFAULT_EDITION_ID) as EditionId
  const edition = EDITIONS.find((item) => item.id === id) ?? DEFAULT_EDITION
  writeTokens(edition)
}
