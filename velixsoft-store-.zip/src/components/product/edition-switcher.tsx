'use client'

import { Check } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useEdition } from './edition-provider'
import type { Edition } from '@/src/data/types'

export function EditionSwitcher({
  editions,
  compact = false,
  className,
}: {
  editions?: Edition[]
  compact?: boolean
  className?: string
}) {
  const { edition, setEdition } = useEdition()
  if (!editions?.length) return null

  return (
    <fieldset className={cn('flex flex-col gap-3', className)}>
      <div className="flex flex-wrap items-center gap-2" role="radiogroup" aria-label="Choose a color edition">
        {editions.map((item) => {
          const active = item.id === edition.id
          return (
            <button
              key={item.id}
              type="button"
              role="radio"
              aria-checked={active}
              aria-label={`${item.name} edition${active ? ', selected' : ''}`}
              title={item.name}
              onClick={() => setEdition(item.id)}
              className={cn(
                'group flex min-h-11 items-center gap-2 rounded-full border px-2.5 text-sm font-medium transition-all duration-200',
                active
                  ? 'border-brand bg-brand-soft text-foreground shadow-sm'
                  : 'border-border bg-background/70 text-muted-foreground hover:border-brand/50 hover:text-foreground',
              )}
            >
              <span
                className="flex size-7 items-center justify-center rounded-full border border-foreground/10"
                style={{ backgroundColor: item.swatch }}
                aria-hidden="true"
              >
                {active && <Check className="size-3.5 text-white" strokeWidth={3} />}
              </span>
              {!compact && <span className="hidden sm:inline">{item.name}</span>}
            </button>
          )
        })}
      </div>
    </fieldset>
  )
}
