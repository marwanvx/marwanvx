'use client'

import * as React from 'react'
import { ChevronDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { TelegramIcon, WhatsAppIcon } from '@/src/components/ui/brand-icons'
import { telegramLink, whatsappLink } from '@/src/data/site'

/**
 * Composes a structured brief into a WhatsApp or Telegram message. There is no
 * backend, and deliberately so: no API route to spam, no personal data at rest,
 * and it matches how work actually closes here. Nothing leaves the browser
 * until the visitor presses a button, which is why the preview is shown.
 *
 * `wa.me` links stop opening reliably somewhere past ~2000 characters, so the
 * description is capped well under that and the rest of the message is fixed
 * length. See `docs/BRAND.md` §5.
 */

const DESCRIPTION_LIMIT = 600

const PROJECT_TYPES = [
  'Web application',
  'Desktop application',
  'Mobile application',
  'Automation or internal tool',
  'Interface or design system',
  'Custom Perfect Panel theme',
  'Not sure yet',
] as const

const STARTING_POINTS = [
  'Starting from scratch',
  'I have a design, need it built',
  'Extending software that already exists',
  'Not sure yet',
] as const

const TIMELINES = ['As soon as possible', 'Within 1 to 3 months', 'Exploring for now'] as const

const BUDGETS = [
  'Under $1,000',
  '$1,000 to $3,000',
  '$3,000 to $8,000',
  'Over $8,000',
  'Not sure yet',
] as const

/** Maps `?service=` and `?type=` arrivals onto a project type. */
/**
 * Maps `?service=` (service ids from `src/data/content.ts`) and a shorter
 * `?type=` onto a project type. Keep the service ids in step when they change:
 * a stale key here silently stops preselecting rather than failing loudly.
 */
const TYPE_FROM_PARAM: Record<string, (typeof PROJECT_TYPES)[number]> = {
  'custom-software': 'Web application',
  'interface-systems': 'Interface or design system',
  'perfect-panel-theme': 'Custom Perfect Panel theme',
  automation: 'Automation or internal tool',
  deployment: 'Not sure yet',
  web: 'Web application',
  desktop: 'Desktop application',
  mobile: 'Mobile application',
  'perfect-panel': 'Custom Perfect Panel theme',
}

const fieldClass =
  'min-h-12 w-full rounded-xl border border-border bg-background/60 px-4 text-sm text-foreground transition-colors focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/25'

function Field({ label, htmlFor, children }: { label: string; htmlFor: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
    </div>
  )
}

function Select({
  id,
  value,
  onChange,
  options,
}: {
  id: string
  value: string
  onChange: (value: string) => void
  options: readonly string[]
}) {
  return (
    <div className="relative">
      <select
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className={`${fieldClass} appearance-none pr-11`}
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
      <ChevronDown
        className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
        aria-hidden="true"
      />
    </div>
  )
}

/**
 * Switches element rather than toggling `disabled`, because `disabled` is a
 * form-control concept: an `<a>` does not support the `:disabled` pseudo-class,
 * so `disabled:pointer-events-none` and `disabled:opacity-50` never apply and
 * the link stays clickable. Rendering a real disabled `<button>` until the
 * brief is usable is unambiguous for both pointers and assistive technology.
 */
function SendButton({
  ready,
  href,
  variant,
  className,
  children,
}: {
  ready: boolean
  href: string
  variant?: 'outline'
  className?: string
  children: React.ReactNode
}) {
  const shared = `min-h-12 w-full rounded-full gap-2 font-medium ${className ?? ''}`
  if (!ready) {
    return (
      <Button type="button" disabled variant={variant} className={shared}>
        {children}
      </Button>
    )
  }
  return (
    <Button variant={variant} className={shared} render={<a href={href} target="_blank" rel="noreferrer" />}>
      {children}
    </Button>
  )
}

export function ProjectBriefForm() {
  const [type, setType] = React.useState<string>(PROJECT_TYPES[0])
  const [goal, setGoal] = React.useState('')
  const [start, setStart] = React.useState<string>(STARTING_POINTS[0])
  const [timeline, setTimeline] = React.useState<string>(TIMELINES[0])
  const [budget, setBudget] = React.useState<string>(BUDGETS[BUDGETS.length - 1])

  /**
   * Read `?service=` after mount rather than with `useSearchParams`, which
   * opts the whole subtree out of server rendering. The form must exist in the
   * static HTML: AI crawlers do not run JavaScript, and this page is the main
   * conversion surface (`docs/BRAND.md` §8). Preselecting a dropdown is a
   * refinement, so it can wait one tick.
   */
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const mapped = TYPE_FROM_PARAM[params.get('service') ?? params.get('type') ?? '']
    if (mapped) setType(mapped)
  }, [])

  const trimmedGoal = goal.trim()
  const ready = trimmedGoal.length > 0

  const message = [
    'New project brief',
    '',
    `Type: ${type}`,
    `Goal: ${trimmedGoal || '(describe what it should do)'}`,
    `Starting point: ${start}`,
    `Timeline: ${timeline}`,
    `Budget: ${budget}`,
  ].join('\n')

  return (
    <div className="grid gap-10 lg:grid-cols-[1.05fr_.95fr] lg:items-start">
      <div className="glass-elevated flex flex-col gap-6 rounded-3xl p-6 sm:p-8">
        <Field label="What are you building?" htmlFor="brief-type">
          <Select id="brief-type" value={type} onChange={setType} options={PROJECT_TYPES} />
        </Field>

        <Field label="What should it do?" htmlFor="brief-goal">
          <textarea
            id="brief-goal"
            value={goal}
            maxLength={DESCRIPTION_LIMIT}
            onChange={(event) => setGoal(event.target.value)}
            rows={5}
            placeholder="A few sentences is plenty. What the software needs to do, who uses it, and anything it has to work with."
            className={`${fieldClass} resize-y py-3 leading-6 placeholder:text-muted-foreground/70`}
          />
          <p className="text-right text-xs tabular-nums text-muted-foreground">
            {goal.length} / {DESCRIPTION_LIMIT}
          </p>
        </Field>

        <Field label="Where are you starting?" htmlFor="brief-start">
          <Select id="brief-start" value={start} onChange={setStart} options={STARTING_POINTS} />
        </Field>

        <div className="grid gap-6 sm:grid-cols-2">
          <Field label="Timeline" htmlFor="brief-timeline">
            <Select id="brief-timeline" value={timeline} onChange={setTimeline} options={TIMELINES} />
          </Field>
          <Field label="Budget" htmlFor="brief-budget">
            <Select id="brief-budget" value={budget} onChange={setBudget} options={BUDGETS} />
          </Field>
        </div>
      </div>

      <div className="flex flex-col gap-6 lg:sticky lg:top-28">
        <div className="glass flex flex-col gap-3 rounded-3xl p-6 sm:p-8">
          <p className="text-sm font-semibold">This is what gets sent</p>
          <p className="text-sm leading-6 text-muted-foreground">
            Nothing is stored and nothing is submitted anywhere. Choosing a channel opens it with the message below already written, and you can edit it before sending.
          </p>
          <pre className="mt-1 overflow-x-auto whitespace-pre-wrap break-words rounded-2xl bg-muted/50 p-4 font-mono text-xs leading-6 text-muted-foreground">
            {message}
          </pre>
        </div>

        <div className="flex flex-col gap-3">
          <SendButton ready={ready} href={whatsappLink(message)} className="bg-brand text-brand-foreground hover:bg-brand-600">
            <WhatsAppIcon className="size-4 shrink-0" />
            <span>Send on WhatsApp</span>
          </SendButton>
          <SendButton ready={ready} href={telegramLink(message)} variant="outline">
            <TelegramIcon className="size-4 shrink-0" />
            <span>Send on Telegram</span>
          </SendButton>
          <p aria-live="polite" className="text-center text-xs text-muted-foreground">
            {ready ? 'We reply with scope and a price, not a discovery call.' : 'Describe what it should do to continue.'}
          </p>
        </div>
      </div>
    </div>
  )
}
