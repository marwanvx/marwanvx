import Link from 'next/link'
import { Logo } from '@/src/components/ui/logo'
import { DiscordIcon, TelegramIcon, WhatsAppIcon } from '@/src/components/ui/brand-icons'
import { footerNav, siteConfig } from '@/src/data/site'

export function Footer() {
  return (
    <footer className="border-t border-border bg-card/30">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-[1.35fr_2fr]">
          <div className="flex max-w-md flex-col items-start gap-5">
            <Logo />
            {/* Single-sourced: this used to be a hardcoded third copy of the
                company description that had drifted from the other two, adding
                platform names and licensing terms. See `docs/BRAND.md` §1. */}
            <p className="text-sm leading-6 text-muted-foreground">{siteConfig.description}</p>
            <div className="flex items-center gap-2">
              <a href={siteConfig.social.whatsapp} target="_blank" rel="noreferrer" aria-label="Contact VelixSoft on WhatsApp" className="flex size-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-brand hover:text-brand"><WhatsAppIcon className="size-4" /></a>
              <a href={siteConfig.social.telegram} target="_blank" rel="noreferrer" aria-label="Contact VelixSoft on Telegram" className="flex size-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-brand hover:text-brand"><TelegramIcon className="size-4" /></a>
              <Link href="/contact" aria-label={`VelixSoft on Discord: ${siteConfig.contact.discordUsername}`} className="flex size-11 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-brand hover:text-brand"><DiscordIcon className="size-4" /></Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {Object.entries(footerNav).map(([heading, links]) => (
              <div key={heading} className="flex flex-col gap-4">
                <h2 className="text-sm font-semibold text-foreground">{heading}</h2>
                <ul className="flex flex-col gap-3">
                  {links.map((link) => <li key={link.href}><Link href={link.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">{link.label}</Link></li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-14 flex flex-col gap-4 border-t border-border pt-6 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} VelixSoft. All rights reserved.</p>
          <p>{siteConfig.tagline}</p>
        </div>
      </div>
    </footer>
  )
}
