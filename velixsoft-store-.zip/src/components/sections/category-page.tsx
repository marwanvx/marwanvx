import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Container, EmptyCategory, JsonLd, PageHero, SectionHeading } from '@/src/components/ui/primitives'
import { ProductCard } from '@/src/components/product/product-card'
import { ContactCta } from './contact-cta'
import { categoryContent } from '@/src/data/content'
import { getProductsByType } from '@/src/data/products'
import { siteConfig } from '@/src/data/site'
import type { ProductType } from '@/src/data/types'

export function CategoryPage({ type }: { type: ProductType }) {
  const content = categoryContent[type]
  const products = getProductsByType(type)
  const available = products.filter((item) => item.status === 'available')
  const schema = { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Products', item: `${siteConfig.url}/products` }, { '@type': 'ListItem', position: 2, name: content.eyebrow, item: `${siteConfig.url}/${content.slug}` }] }
  return <>
    <JsonLd data={schema} />
    <PageHero eyebrow={content.eyebrow} title={content.h1} description={content.intro}><Button variant="outline" className="min-h-11 rounded-full" render={<Link href="/products" />}>Browse the catalogue <ArrowRight data-icon="inline-end" /></Button></PageHero>
    <section className="pb-20"><Container>{products.length ? <div className="grid gap-5 lg:grid-cols-3">{products.map((product, index) => <ProductCard key={product.slug} product={product} featured={index === 0 && available.length > 0} />)}</div> : <EmptyCategory title={content.emptyTitle} body={content.emptyBody} />}{products.length > 0 && available.length === 0 && <div className="mt-8"><EmptyCategory title={content.emptyTitle} body={content.emptyBody} /></div>}</Container></section>
    <section className="py-20 sm:py-28"><Container><div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr]"><SectionHeading eyebrow="Why it matters" title={`Designed for the work behind ${content.eyebrow.toLowerCase()}.`} /><div className="flex flex-col gap-6">{content.body.map((paragraph) => <p key={paragraph.slice(0, 30)} className="text-lg leading-8 text-muted-foreground">{paragraph}</p>)}</div></div></Container></section>
    <ContactCta />
  </>
}
