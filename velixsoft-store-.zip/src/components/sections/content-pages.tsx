import Link from 'next/link'
import { ArrowUpRight, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Container, PageHero, SectionHeading } from '@/src/components/ui/primitives'
import { Icon } from '@/src/components/ui/icon'
import { DiscordIcon, TelegramIcon, WhatsAppIcon } from '@/src/components/ui/brand-icons'
import { CopyField } from '@/src/components/ui/copy-field'
import { ContactCta } from './contact-cta'
import { ProjectBriefForm } from './project-brief-form'
import { FaqSection } from './faq-section'
import { companyFaq } from '@/src/data/content'
import { perfectPanelProduct, ytLeadsProduct } from '@/src/data/products'
import { siteConfig, telegramLink, whatsappLink } from '@/src/data/site'

export function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Start a project"
        title="Tell us what you need built."
        description="Most of what we build is made to order. Describe the problem below and you get a written scope, deliverables, and a price before any work begins."
      />

      <section id="brief" className="scroll-mt-28 pb-24">
        <Container>
          <ProjectBriefForm />
        </Container>
      </section>

      <section className="pb-28">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]">
            <SectionHeading eyebrow="How pricing works" title="Scope first. Price second." />
            <div className="flex flex-col gap-5 text-lg leading-8 text-muted-foreground">
              <p>
                Cost depends on how much has to be built, what you already have, which systems it needs to talk to, and whether you need design, implementation, or both. Quoting a fixed number before understanding those things would be guesswork sold as certainty.
              </p>
              <p>
                So the brief above asks the questions that actually move the estimate. You get a written scope, a deliverables list, and a price. If it is not what you expected, nothing has been committed on either side.
              </p>
            </div>
          </div>
        </Container>
      </section>
    </>
  )
}

export function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About VelixSoft"
        title="We build the software that does not exist yet."
        description="VelixSoft is a software company. We build software to order: web applications, desktop and mobile apps, automation, and complete interface systems, and we support everything we ship."
      />
      <section className="pb-24">
        <Container>
          <div className="grid gap-12 lg:grid-cols-2">
            <div className="flex flex-col gap-5">
              <h2 className="text-3xl font-semibold tracking-[-0.035em]">What we do</h2>
              <p className="text-lg leading-8 text-muted-foreground">
                Most of what we build is made to order. A client arrives with a requirement that no off-the-shelf product covers, and we design and build the thing that covers it: a web application, a desktop tool, a mobile app, an automation, or a complete interface system for a platform they already run.
              </p>
              <p className="text-lg leading-8 text-muted-foreground">
                We also ship our own products, and they are the clearest evidence of how we work. Every release has a version number, documented behaviour, defined states, and people behind it who answer questions. We do not ship recolored asset packs and we do not resell other people&rsquo;s work.
              </p>
            </div>
            <div className="glass grid gap-4 rounded-3xl p-6 sm:grid-cols-2 sm:p-8">
              {['Products, not templates', 'Local-first by default', 'Versioned releases', 'Support from the builders'].map((item) => (
                <div key={item} className="flex min-h-28 flex-col justify-end rounded-2xl bg-muted/50 p-4">
                  <Check className="mb-3 size-5 text-brand" />
                  <h3 className="font-semibold">{item}</h3>
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]">
            <SectionHeading eyebrow="Where we started" title="Perfect Panel was the proving ground." />
            <div className="flex flex-col gap-5 text-lg leading-8 text-muted-foreground">
              <p>
                The work that started VelixSoft was an interface system for Perfect Panel, a platform used to run social media marketing panels. It was a deliberate starting point: a market with real operators, real revenue, and software whose default presentation actively undersold the businesses running on it.
              </p>
              <p>
                That release taught us how we wanted to work. Design every state rather than the happy path. Treat dark and light as two designs, not one plus an inversion. Ship source files and documentation, then help the customer install it. The Velix Perfect Panel Theme still sells, still gets compatibility updates, and remains the reference for the standard we hold new work to.
              </p>
              <p>
                It is one product in one category, and it was never meant to be the whole company.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[.8fr_1.2fr]">
            <SectionHeading eyebrow="Where we are going" title="Software, automation, and the tools around them." />
            <div className="flex flex-col gap-5 text-lg leading-8 text-muted-foreground">
              <p>
                YTLeads Pro was our first packaged product and the first native desktop application: a Windows and macOS app that turns keyword research on YouTube into an exportable contact database held locally, with no account and no cloud dependency. It is the direction the catalogue is moving in.
              </p>
              <p>
                Three categories are in active development: more desktop software, focused automation and developer tools, and structured data products with documented schemas and update schedules. We announce releases when they are ready to install, not as pre-orders, and we would rather ship one product that does its job completely than four that nearly do.
              </p>
              <p>
                If a repetitive part of your work looks like it should be software, <Link href="/contact" className="font-medium text-brand hover:underline">tell us about it</Link>. It is how the last two products started.
              </p>
            </div>
          </div>
        </Container>
      </section>

      <ContactCta title="Talk to the people who build it." description="Ask about a product, the roadmap, or a project you want built. You will be talking to whoever wrote the code." />
    </>
  )
}

export function ContactPage() {
  const message = "Hi, I'd like to talk about a VelixSoft product."
  const options = [
    { title: 'WhatsApp', description: 'Best for product questions, licensing, and purchase confirmation.', href: whatsappLink(message), icon: WhatsAppIcon, action: 'Open WhatsApp' },
    { title: 'Telegram', description: 'Best for project conversations and file delivery.', href: telegramLink(message), icon: TelegramIcon, action: 'Open Telegram' },
  ]
  return (
    <>
      <PageHero eyebrow="Contact" title="Talk directly with VelixSoft." description="Ask about a product, licensing, compatibility, installation, or a project you want built. Pick the channel you already use." />
      <section className="pb-28">
        <Container>
          <div className="grid gap-5 lg:grid-cols-3">
            {options.map((item) => (
              <Card key={item.title} className="rounded-3xl bg-card/60">
                <CardHeader className="gap-5 p-6">
                  <span className="flex size-12 items-center justify-center rounded-2xl bg-brand-soft text-brand"><item.icon className="size-5" /></span>
                  <div className="flex flex-col gap-2">
                    <CardTitle>{item.title}</CardTitle>
                    <CardDescription className="leading-6">{item.description}</CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="px-6 pb-6">
                  <Button className="min-h-11 w-full rounded-full bg-brand text-brand-foreground hover:bg-brand-600" render={<a href={item.href} target="_blank" rel="noreferrer" />}>{item.action}<ArrowUpRight data-icon="inline-end" /></Button>
                </CardContent>
              </Card>
            ))}
            <Card className="rounded-3xl bg-card/60">
              <CardHeader className="gap-5 p-6">
                <span className="flex size-12 items-center justify-center rounded-2xl bg-brand-soft text-brand"><DiscordIcon className="size-5" /></span>
                <div className="flex flex-col gap-2">
                  <CardTitle>Discord</CardTitle>
                  <CardDescription className="leading-6">Best for ongoing support and community questions. Add the username below.</CardDescription>
                </div>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <CopyField value={siteConfig.contact.discordUsername} label="Discord username" />
              </CardContent>
            </Card>
          </div>
        </Container>
      </section>
    </>
  )
}

export function FaqPage() {
  return (
    <>
      <PageHero eyebrow="FAQ" title="Clear answers before you buy." description="What VelixSoft builds, how licensing and delivery work, and the product-specific details for each release." />
      <FaqSection faqs={companyFaq} title="About VelixSoft" description="The company, the catalogue, and how buying works." schema />
      <FaqSection faqs={ytLeadsProduct.faq} title="About YTLeads Pro" description="Platforms, privacy, exports, and updates for our desktop application." />
      <FaqSection faqs={perfectPanelProduct.faq} title="About the Perfect Panel Theme" description="Integration, delivery, editions, customization, and refunds." />
      <ContactCta />
    </>
  )
}

export function LegalPage({ title, description, updated, sections }: { title: string; description: string; updated: string; sections: readonly { readonly title: string; readonly body: readonly string[] }[] }) {
  return <><PageHero eyebrow="Legal" title={title} description={description} /><article className="pb-28"><Container className="max-w-4xl"><p className="mb-10 text-sm text-muted-foreground">Last updated: {updated}</p><div className="flex flex-col gap-10">{sections.map((section) => <section key={section.title} className="flex flex-col gap-4"><h2 className="text-2xl font-semibold">{section.title}</h2>{section.body.map((paragraph) => <p key={paragraph.slice(0, 40)} className="leading-7 text-muted-foreground">{paragraph}</p>)}</section>)}</div></Container></article></>
}
