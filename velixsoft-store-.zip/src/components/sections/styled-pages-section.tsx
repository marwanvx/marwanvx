'use client'

import * as React from 'react'
import { ArrowRight, Check, Search, Sparkles } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Container, SectionHeading } from '@/src/components/ui/primitives'
import { cn } from '@/lib/utils'

export interface PageItem {
  name: string
  description: string
  tag?: string
}

export interface PageCategory {
  category: string
  description: string
  pages: PageItem[]
}

export const allStyledPages: PageCategory[] = [
  {
    category: 'Orders & Workflows',
    description: 'Main customer order entry points and recurring order schedules.',
    pages: [
      { name: 'neworder', description: 'Single service order creation with live price calculation', tag: 'Core' },
      { name: 'massorder', description: 'Multi-line bulk order submission with format validation', tag: 'Core' },
      { name: 'orders', description: 'Paginated order table with status badges and search filters', tag: 'Core' },
      { name: 'drip_feed', description: 'Automated recurring order schedules and tracking' },
      { name: 'subscriptions', description: 'Auto-like and auto-view subscription monitoring' },
      { name: 'refill', description: 'One-click refill requests and order acceleration' },
      { name: 'refunds', description: 'Refund requests and balance reversal tracking' },
    ],
  },
  {
    category: 'Services & Developer API',
    description: 'Catalog inspection, price logs, and developer documentation.',
    pages: [
      { name: 'services', description: 'Searchable category filter list with speed & minimums', tag: 'Core' },
      { name: 'api', description: 'Interactive endpoint docs with code samples (cURL, Python, JS)', tag: 'Core' },
      { name: 'updates', description: 'Service updates, price changes, and new additions log' },
    ],
  },
  {
    category: 'Financials & Billing',
    description: 'Deposit gateways, balance management, and affiliate payouts.',
    pages: [
      { name: 'addfunds', description: 'Multi-payment method checkout interface & gateway list', tag: 'Core' },
      { name: 'affiliates', description: 'Referral links, commission rates, and payout log' },
    ],
  },
  {
    category: 'Support & Tickets',
    description: 'Customer ticket support and real-time alerts.',
    pages: [
      { name: 'tickets', description: 'Open, answered, and closed ticket threads table', tag: 'Core' },
      { name: 'viewticket', description: 'Conversation thread view with file attachments' },
      { name: 'notifications', description: 'System announcements, order alerts, and broadcast messages' },
    ],
  },
  {
    category: 'Account & Reseller Leasing',
    description: 'Profile settings, security, and child panel rentals.',
    pages: [
      { name: 'account', description: 'Profile info, timezone, language, and currency defaults', tag: 'Core' },
      { name: '2fa', description: 'Two-Factor Security setup with authenticator app QR code', tag: 'Core' },
      { name: 'child_panel', description: 'Child panel leasing, domain mapping, and renewal setup' },
      { name: 'child_panel_order', description: 'Order placement for renting child panels' },
    ],
  },
  {
    category: 'Authentication & Access',
    description: 'Sign in, registration, and email verification workflows.',
    pages: [
      { name: 'signin', description: 'Sign-in screen designed for both dark and light modes', tag: 'Core' },
      { name: 'signup', description: 'Account registration with terms confirmation' },
      { name: 'resetpassword', description: 'Password reset request workflow' },
      { name: 'setnewpassword', description: 'New password entry and validation' },
      { name: 'confirmemail', description: 'Email verification confirmation screen' },
    ],
  },
  {
    category: 'Content, Blog & Layout',
    description: 'Public articles, legal policies, and master layout system.',
    pages: [
      { name: 'faq', description: 'Expandable question sections and help articles' },
      { name: 'terms', description: 'Terms of service, refund policy, and usage rules' },
      { name: 'blog', description: 'Blog index listing for panel news and guides' },
      { name: 'blogpost', description: 'Individual article view with rich text typography' },
      { name: 'newpage', description: 'Custom page template for custom marketing content' },
      { name: 'layout', description: 'Base master layout wrapper with header, sidebar, and footer' },
    ],
  },
]

const totalPagesCount = allStyledPages.reduce((acc, cat) => acc + cat.pages.length, 0)

const featuredPages = [
  'neworder',
  'services',
  'orders',
  'addfunds',
  'api',
  'tickets',
  'account',
  'signin',
  '2fa',
]

export function StyledPagesSection() {
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [searchQuery, setSearchQuery] = React.useState('')

  const filteredCategories = React.useMemo(() => {
    if (!searchQuery.trim()) return allStyledPages
    const q = searchQuery.toLowerCase()
    return allStyledPages
      .map((cat) => ({
        ...cat,
        pages: cat.pages.filter(
          (p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
        ),
      }))
      .filter((cat) => cat.pages.length > 0)
  }, [searchQuery])

  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="flex flex-col gap-12">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <SectionHeading
              eyebrow="Coverage"
              title="30 pages, designed as one system."
              description="The dashboard customers use after login gets the same treatment as the page that convinced them to sign up. Every page, modal, and data table is styled."
            />
            <div className="flex shrink-0 items-center gap-3">
              <Badge variant="outline" className="rounded-full border-brand/30 bg-brand-soft px-3.5 py-1.5 text-sm font-semibold text-brand">
                <Sparkles className="mr-1.5 size-3.5" /> {totalPagesCount} Pages Included
              </Badge>
            </div>
          </div>

          {/* Featured Bento Grid */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {featuredPages.map((pageName, index) => {
              return (
                <div key={pageName} className="glass group flex min-h-28 flex-col justify-between rounded-2xl p-5 transition-colors hover:border-brand/35">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-brand">{String(index + 1).padStart(2, '0')}</span>
                    <Badge variant="outline" className="rounded-full text-[10px] uppercase text-muted-foreground">Styled Page</Badge>
                  </div>
                  <span className="text-base font-semibold text-foreground group-hover:text-brand transition-colors">{pageName}</span>
                </div>
              )
            })}
          </div>

          {/* View All Button */}
          <div className="flex flex-col items-center justify-center gap-3 pt-2">
            <Button
              onClick={() => setDialogOpen(true)}
              className="min-h-12 rounded-full bg-brand px-8 text-base font-semibold text-brand-foreground shadow-lg hover:bg-brand-600 gap-2.5"
            >
              <span>See all {totalPagesCount} styled pages</span>
              <ArrowRight data-icon="inline-end" />
            </Button>
            <p className="text-xs text-muted-foreground">
              Includes orders, billing, API docs, support, security, reseller, and error states
            </p>
          </div>
        </div>
      </Container>

      {/* 30+ Pages Modal */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[90vh] max-w-4xl overflow-hidden border-border bg-popover p-0 shadow-2xl sm:max-w-4xl">
          <DialogHeader className="border-b border-border p-6 sm:p-8 pb-5">
            <div className="flex items-center gap-2 mb-2">
              <Badge className="rounded-full bg-brand text-brand-foreground px-3 py-1 text-xs">
                {totalPagesCount} Pages System
              </Badge>
              <Badge variant="outline" className="rounded-full text-xs">Full Catalogue</Badge>
            </div>
            <DialogTitle className="text-2xl font-bold tracking-tight sm:text-3xl">
              Complete {totalPagesCount}-Page Interactive Index
            </DialogTitle>
            <DialogDescription className="text-base leading-relaxed text-muted-foreground">
              Every page listed below ships with the Velix Perfect Panel Theme. No add-ons, no upsells.
            </DialogDescription>

            {/* Search Input */}
            <div className="relative mt-4">
              <Search className="absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search page name or feature (e.g., API, 2FA, Refund)..."
                className="w-full rounded-xl border border-border bg-background/80 py-2.5 pl-10 pr-4 text-sm text-foreground outline-none focus:border-brand focus:ring-1 focus:ring-brand"
              />
            </div>
          </DialogHeader>

          {/* Scrollable Body */}
          <div className="max-h-[60vh] overflow-y-auto p-6 sm:p-8 flex flex-col gap-8">
            {filteredCategories.length > 0 ? (
              filteredCategories.map((cat) => (
                <div key={cat.category} className="flex flex-col gap-3">
                  <div className="flex items-center justify-between border-b border-border pb-2">
                    <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                      <span>{cat.category}</span>
                      <span className="text-xs text-brand font-mono font-medium">({cat.pages.length})</span>
                    </h3>
                    <span className="text-xs text-muted-foreground hidden sm:inline">{cat.description}</span>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    {cat.pages.map((p) => (
                      <div key={p.name} className="flex flex-col gap-1 rounded-xl border border-border/70 bg-muted/30 p-3.5 transition-colors hover:border-brand/40">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-semibold text-sm text-foreground flex items-center gap-1.5">
                            <Check className="size-3.5 text-brand shrink-0" />
                            {p.name}
                          </span>
                          {p.tag && (
                            <Badge variant="outline" className="rounded-full text-[10px] border-brand/40 text-brand px-2 py-0">
                              {p.tag}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs leading-5 text-muted-foreground pl-5">{p.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-12 text-center text-muted-foreground">
                No pages match &ldquo;{searchQuery}&rdquo;. Try another term.
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  )
}
