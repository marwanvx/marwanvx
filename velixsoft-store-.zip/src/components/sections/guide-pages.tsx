import type { ReactElement, ReactNode } from 'react'
import Link from 'next/link'
import { ArrowRight, BookOpen, Clock } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Container, PageHero } from '@/src/components/ui/primitives'
import { guides } from '@/src/data/guides'
import type { Guide, InlineLink } from '@/src/data/types'
import { getProduct } from '@/src/data/products'

/**
 * Split a block of prose on its declared link phrases and wrap each match in a
 * real anchor. Longest match first, so a phrase that contains another phrase
 * cannot be broken apart by it.
 *
 * A `match` that is not present in the text renders the text unchanged rather
 * than throwing: a typo in the content data should not blank a published page.
 */
type InlineNode = string | ReactElement

function withInlineLinks(text: string, links?: InlineLink[]): ReactNode {
  if (!links?.length) return text

  const ordered = [...links].sort((a, b) => b.match.length - a.match.length)
  let nodes: InlineNode[] = [text]

  for (const { match, href } of ordered) {
    nodes = nodes.flatMap<InlineNode>((node, nodeIndex) => {
      if (typeof node !== 'string' || !node.includes(match)) return [node]
      return node.split(match).flatMap<InlineNode>((part, partIndex) =>
        partIndex === 0
          ? [part]
          : [
              <Link
                key={`${href}-${nodeIndex}-${partIndex}`}
                href={href}
                className="font-medium text-brand underline underline-offset-4 hover:text-brand-600"
              >
                {match}
              </Link>,
              part,
            ],
      )
    })
  }

  return nodes
}

export function GuidesPage() {
  return (
    <>
      <PageHero
        eyebrow="Guides & Documentation"
        title="How our software works, written down."
        description="Installation walkthroughs, design documentation, and the reasoning behind decisions in VelixSoft products."
      />
      <section className="pb-28">
        <Container>
          <div className="grid gap-6 lg:grid-cols-3">
            {guides.map((guide) => (
              <Link
                key={guide.slug}
                href={`/guides/${guide.slug}`}
                className="glass group flex flex-col justify-between rounded-3xl p-7 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-brand"
              >
                <div className="flex flex-col">
                  <div className="mb-6 flex items-center justify-between">
                    <Badge variant="secondary" className="rounded-full px-3 py-1 font-medium">
                      {guide.category}
                    </Badge>
                    <span className="flex size-9 items-center justify-center rounded-xl bg-brand-soft text-brand transition-transform group-hover:scale-110">
                      <BookOpen className="size-4" />
                    </span>
                  </div>

                  <h2 className="text-balance text-2xl font-bold tracking-tight text-foreground transition-colors group-hover:text-brand">
                    {guide.title}
                  </h2>

                  <p className="mt-3.5 leading-relaxed text-muted-foreground">
                    {guide.excerpt}
                  </p>
                </div>

                <div className="mt-8 flex items-center justify-between border-t border-border/60 pt-5 text-sm text-muted-foreground">
                  <span className="flex items-center gap-2 font-medium">
                    <Clock className="size-4 text-brand" />
                    {guide.readingTime}
                  </span>

                  <span className="flex items-center gap-1.5 font-semibold text-brand transition-all group-hover:translate-x-1">
                    <span>Read guide</span>
                    <ArrowRight className="size-4" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </Container>
      </section>
    </>
  )
}

export function GuidePage({ guide }: { guide: Guide }) {
  const related = guide.relatedProducts.map(getProduct).filter(Boolean)
  return (
    <>
      <PageHero
        eyebrow={`${guide.category} guide`}
        title={guide.title}
        description={guide.excerpt}
      />
      <article className="pb-28">
        <Container className="max-w-4xl">
          <div className="mb-8 flex items-center justify-between border-b border-border/60 pb-5 text-sm text-muted-foreground">
            <Link
              href="/guides"
              className="inline-flex items-center gap-2 font-medium text-brand hover:underline"
            >
              ← Back to all guides
            </Link>
            <div className="flex items-center gap-3">
              <Clock className="size-4" />
              <span>{guide.readingTime}</span>
              <span aria-hidden="true">·</span>
              <time dateTime={guide.updatedAt}>
                Updated {new Date(guide.updatedAt).toLocaleDateString('en-US', { dateStyle: 'long' })}
              </time>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            {guide.body.map((block, index) => {
              if (block.kind === 'h2') {
                return (
                  <h2 key={index} className="mt-7 text-balance text-3xl font-semibold tracking-tight">
                    {block.text}
                  </h2>
                )
              }
              if (block.kind === 'p') {
                return (
                  <p key={index} className="text-lg leading-8 text-muted-foreground">
                    {withInlineLinks(block.text, block.links)}
                  </p>
                )
              }
              if (block.kind === 'callout') {
                return (
                  <aside key={index} className="rounded-2xl border border-brand/25 bg-brand-soft p-6 leading-7 text-foreground">
                    {withInlineLinks(block.text, block.links)}
                  </aside>
                )
              }
              const Tag = block.kind === 'ol' ? 'ol' : 'ul'
              return (
                <Tag
                  key={index}
                  className={`flex flex-col gap-3 pl-6 text-lg leading-8 text-muted-foreground ${
                    block.kind === 'ol' ? 'list-decimal' : 'list-disc'
                  }`}
                >
                  {block.items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </Tag>
              )
            })}
          </div>

          {related.length > 0 && (
            <aside className="mt-16 rounded-3xl border border-border bg-card p-8 shadow-sm">
              <p className="text-sm font-semibold uppercase tracking-widest text-brand">Related product</p>
              <h2 className="mt-3 text-2xl font-semibold">{related[0]!.name}</h2>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                See the product discussed in this guide, including editions, gallery evidence, compatibility, and installation support.
              </p>
              <Button
                className="mt-6 rounded-full bg-brand text-brand-foreground hover:bg-brand-600 min-h-11 px-6"
                render={<Link href={`/products/${related[0]!.slug}`} />}
              >
                View product <ArrowRight data-icon="inline-end" />
              </Button>
            </aside>
          )}
        </Container>
      </article>
    </>
  )
}

