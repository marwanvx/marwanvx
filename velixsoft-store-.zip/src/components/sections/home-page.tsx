import Link from 'next/link'
import { ArrowRight, ArrowUpRight, Check, ChevronRight, Cpu } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Container, JsonLd, SectionHeading } from '@/src/components/ui/primitives'
import { Icon } from '@/src/components/ui/icon'
import { ProductGallery } from '@/src/components/product/product-gallery'
import { RevealSlider } from '@/src/components/product/reveal-slider'
import { ProductCard } from '@/src/components/product/product-card'
import { FaqSection } from './faq-section'
import { ContactCta } from './contact-cta'
import { perfectPanelProduct, products, ytLeadsProduct } from '@/src/data/products'
import { companyFaq, howItWorks, includedFeatures, services, trustStats, whyVelixsoft } from '@/src/data/content'
import { StyledPagesSection } from './styled-pages-section'
import { whatsappLink } from '@/src/data/site'
import { WhatsAppIcon } from '@/src/components/ui/brand-icons'

export function HomePage() {
  const faqSchema = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: companyFaq.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) }
  return (
    <>
      <JsonLd data={faqSchema} />
      <Hero />
      <Catalogue />
      <Why />
      <PerfectPanelSpotlight />
      <DesktopSpotlight />
      <Services />
      <Process />
      <FaqSection faqs={companyFaq} title="Questions, answered." description="What we build, how licensing works, and where your data lives." />
      <ContactCta />
    </>
  )
}

/**
 * Text-only, centred. The hero copy is company-level, so it carries no product
 * screenshot — a single product image beside it contradicts the message, and
 * two turn the hero into a catalogue. Products are shown in their own sections
 * directly below. See `docs/BRAND.md` §9.
 */
function Hero() {
  return (
    <section className="relative overflow-hidden pb-20 pt-16 sm:pb-24 sm:pt-20 lg:pb-28 lg:pt-24">
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-[34rem] w-[68rem] max-w-[150vw] -translate-x-1/2 -translate-y-1/3 rounded-full bg-brand-soft blur-3xl"
        aria-hidden="true"
      />
      <Container className="relative">
        <div className="mx-auto flex max-w-4xl flex-col items-center gap-8 text-center">
          <Badge variant="outline" className="rounded-full border-brand/30 bg-brand-soft px-3 py-1.5 text-brand">
            <Cpu className="mr-1 size-3.5" /> Software company
          </Badge>

          <div className="flex flex-col gap-6">
            <h1 className="text-balance text-5xl font-semibold leading-[.96] tracking-[-0.06em] sm:text-6xl lg:text-7xl">
              Off-the-shelf gets you<br />
              <span className="text-muted-foreground">most of the way</span>
            </h1>
            <p className="mx-auto max-w-2xl text-pretty text-lg leading-8 text-muted-foreground">
              We build the rest. VelixSoft designs and builds software to order: web applications, desktop and mobile apps, automation, and complete interface systems. Two of our own products ship today, and they show the standard we build to.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button className="min-h-12 rounded-full bg-brand px-6 text-brand-foreground shadow-lg hover:bg-brand-600" render={<Link href="/products" />}>Browse products <ArrowRight data-icon="inline-end" /></Button>
            <Button variant="outline" className="min-h-12 rounded-full bg-background/60 px-6" render={<Link href="/about" />}>How we work <ArrowUpRight data-icon="inline-end" /></Button>
          </div>

          {/* Value renders above the label via col-reverse so the two share a
              baseline. `nowrap` is kept as a guard even though the centred
              layout gives each column ~190px — see `docs/BRAND.md` §6. */}
          <dl className="mt-6 grid w-full max-w-3xl grid-cols-2 gap-x-6 gap-y-8 border-t border-border pt-8 sm:grid-cols-4">
            {trustStats.map((stat) => (
              <div key={stat.label} className="flex flex-col-reverse items-center gap-1.5">
                <dt className="whitespace-nowrap text-[11px] font-medium uppercase tracking-[.12em] text-muted-foreground">{stat.label}</dt>
                <dd className="whitespace-nowrap text-2xl font-semibold tracking-[-0.03em] text-foreground">{stat.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </Container>
    </section>
  )
}

function Catalogue() {
  return <section className="py-20 sm:py-28"><Container><div className="flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between"><SectionHeading eyebrow="The catalogue" title="What we ship today." description="Two products are available now, across interface systems and desktop software. Automation, developer tools, and data products are in progress." /><Button variant="outline" className="min-h-11 w-fit rounded-full" render={<Link href="/products" />}>Browse all <ArrowRight data-icon="inline-end" /></Button></div><div className="mt-12 grid gap-5 lg:grid-cols-3">{products.map((product, index) => <ProductCard key={product.slug} product={product} featured={index === 0} />)}</div></Container></section>
}

function Why() {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="How we build" title="The standard every release is held to." description="The difference is rarely one feature. It is a hundred small decisions made the same way across a whole product." /><div className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">{whyVelixsoft.map((item) => <div key={item.title} className="flex gap-4"><span className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-brand/25 bg-brand-soft text-brand"><Icon name={item.icon} className="size-5" /></span><div className="flex flex-col gap-2"><h3 className="font-semibold">{item.title}</h3><p className="text-sm leading-6 text-muted-foreground">{item.description}</p></div></div>)}</div></Container></section>
}

function DesktopSpotlight() {
  const product = ytLeadsProduct
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <div className="mb-12 flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading eyebrow="Also from VelixSoft · Desktop software" title="YTLeads Pro" description={`${product.tagline} A native application for Windows and macOS that keeps your research on your own machine.`} />
          <div className="flex shrink-0 items-center gap-4"><span className="text-3xl font-semibold">$69</span><Button className="min-h-11 rounded-full bg-brand text-brand-foreground hover:bg-brand-600 gap-2 font-medium" render={<Link href={`/products/${product.slug}`} />}><span>See the app</span><ArrowUpRight className="size-4 shrink-0" /></Button></div>
        </div>
        <div className="grid gap-10 lg:grid-cols-[1.15fr_.85fr] lg:items-start">
          <ProductGallery product={product} />
          <ul className="flex flex-col gap-3">
            {product.features.slice(0, 6).map((feature) => (
              <li key={feature} className="glass flex gap-3 rounded-2xl p-4 text-sm leading-6 text-muted-foreground"><Check className="mt-0.5 size-4 shrink-0 text-brand" />{feature}</li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  )
}

function PerfectPanelSpotlight() {
  return (
    <>
      <section className="py-20 sm:py-28">
        <Container>
          <div className="mb-12 flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <SectionHeading eyebrow="Latest release · Flagship" title="Velix Perfect Panel Theme" description="Our newest product and current flagship: a complete interface system for the Perfect Panel platform, in six editions. Switch editions below and this entire page adopts the same color direction." />
            <div className="flex shrink-0 items-center gap-4"><span className="text-3xl font-semibold">$149</span><Button className="min-h-11 rounded-full bg-brand text-brand-foreground hover:bg-brand-600 gap-2 font-medium" render={<a href={whatsappLink("Hi, I'm interested in the Velix Perfect Panel Theme.")} target="_blank" rel="noreferrer" />}><WhatsAppIcon className="size-4 shrink-0" /><span>Buy a license</span></Button></div>
          </div>
          <ProductGallery product={perfectPanelProduct} />
        </Container>
      </section>
      <section className="py-20 sm:py-28"><Container><div className="mb-10"><SectionHeading eyebrow="Dark and light" title="Not inverted. Designed twice." description="Drag across the same dashboard to compare modes. Every surface, line, and label is tuned for its own environment." /></div><RevealSlider product={perfectPanelProduct} /></Container></section>
      <StyledPagesSection />
      <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="In the package" title="Source files, docs, and installation help." description="A complete product, with practical support before and after the files arrive." /><div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{includedFeatures.map((item) => <Card key={item.title} className="rounded-2xl bg-card/60 transition-colors hover:border-brand/35"><CardHeader className="gap-5 p-5"><span className="flex size-11 items-center justify-center rounded-xl bg-brand-soft text-brand"><Icon name={item.icon} className="size-5" /></span><div className="flex flex-col gap-2"><CardTitle className="text-base">{item.title}</CardTitle><CardDescription className="leading-6">{item.description}</CardDescription></div></CardHeader></Card>)}</div></Container></section>
    </>
  )
}

function Services() {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="Services" title="Most of what we build is made to order." description="Four shapes an engagement usually takes. Each one starts with a written scope and a price, before any work does." /><div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{services.map((service) => <Card key={service.id} className="rounded-3xl bg-card/60"><CardHeader className="gap-5 p-6"><span className="flex size-12 items-center justify-center rounded-2xl bg-brand-soft text-brand"><Icon name={service.icon} className="size-5" /></span><div className="flex flex-col gap-2"><CardTitle>{service.name}</CardTitle><CardDescription className="leading-7">{service.description}</CardDescription></div></CardHeader><CardContent className="flex flex-col gap-5 px-6 pb-6"><ul className="flex flex-col gap-3">{service.deliverables.map((item) => <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground"><Check className="size-4 text-brand" />{item}</li>)}</ul><div className="flex items-center border-t border-border pt-5">{service.startingPrice && <span className="text-sm font-medium">{service.startingPrice}</span>}<Link href={`/services?service=${service.id}#brief`}  className="ml-auto inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-brand">Start a brief <ChevronRight className="size-4" /></Link></div></CardContent></Card>)}</div></Container></section>
}

function Process() {
  return <section className="py-20 sm:py-28"><Container><SectionHeading eyebrow="How it works" title="From first message to running software." /><ol className="mt-12 grid gap-4 lg:grid-cols-4">{howItWorks.map((step, index) => <li key={step.title} className="glass relative flex flex-col gap-6 rounded-2xl p-6"><div className="flex items-center justify-between"><span className="flex size-11 items-center justify-center rounded-xl bg-brand text-brand-foreground"><Icon name={step.icon} className="size-5" /></span><span className="font-mono text-sm text-muted-foreground">0{index + 1}</span></div><div className="flex flex-col gap-2"><h3 className="font-semibold">{step.title}</h3><p className="text-sm leading-6 text-muted-foreground">{step.description}</p></div></li>)}</ol></Container></section>
}
