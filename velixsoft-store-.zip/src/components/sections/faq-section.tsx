import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import type { ProductFaq } from '@/src/data/types'
import { Container, JsonLd, SectionHeading } from '@/src/components/ui/primitives'

export function FaqSection({ faqs, title = 'Questions, answered.', description = 'The practical details before you choose a product.' , schema = false }: { faqs: ProductFaq[]; title?: string; description?: string; schema?: boolean }) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })),
  }
  return (
    <section className="py-20 sm:py-28">
      {schema && <JsonLd data={jsonLd} />}
      <Container>
        <div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr] lg:gap-20">
          <SectionHeading eyebrow="FAQ" title={title} description={description} />
          <Accordion className="flex flex-col gap-3.5">
            {faqs.map((faq, index) => (
              <AccordionItem key={faq.question} value={`faq-${index}`} className="glass rounded-2xl border border-border/80 px-6 py-1 transition-colors hover:border-brand/35">
                <AccordionTrigger className="py-5 text-left text-base font-semibold hover:no-underline flex items-center">{faq.question}</AccordionTrigger>
                {/* `keepMounted` puts the answer in the server-rendered HTML even
                    while the panel is collapsed. Without it Base UI unmounts the
                    panel, and the answers reached the page only after a human
                    clicked — so every answer block was absent from the markup a
                    crawler sees, present only inside the FAQPage JSON-LD. These
                    are the self-contained 40-80 word answers `docs/BRAND.md` §8
                    asks for, and §8 rule 1 requires them to be in the HTML
                    rather than behind a client-only interaction. Collapsed
                    behaviour and appearance are unchanged for readers. */}
                <AccordionContent keepMounted className="pb-6 pt-2 text-base leading-7 text-muted-foreground border-t border-border/40 mt-1">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </Container>
    </section>
  )
}
