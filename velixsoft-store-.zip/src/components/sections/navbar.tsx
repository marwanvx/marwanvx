'use client'

import * as React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ArrowUpRight, Menu } from 'lucide-react'
import { Logo } from '@/src/components/ui/logo'
import { ThemeToggle } from '@/src/components/ui/theme-toggle'
import { mainNav } from '@/src/data/site'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'

export function Navbar() {
  const pathname = usePathname()
  const [open, setOpen] = React.useState(false)

  return (
    <header className="sticky top-0 z-30 px-3 pt-3 sm:px-5 sm:pt-5">
      <nav aria-label="Main navigation" className="glass-elevated mx-auto flex h-16 max-w-6xl items-center justify-between rounded-2xl px-3 shadow-[0_12px_40px_-16px_rgba(0,0,0,.35)] sm:px-4">
        <Logo />

        <div className="hidden items-center gap-1 lg:flex">
          {mainNav.map((item) => {
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`)
            return (
              <Link key={item.href} href={item.href} className={cn('relative flex min-h-11 items-center rounded-full px-4 text-sm font-medium transition-colors', active ? 'bg-brand-soft text-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground')}>
                {active && <span className="absolute bottom-1 left-1/2 size-1 -translate-x-1/2 rounded-full bg-brand" aria-hidden="true" />}
                {item.label}
              </Link>
            )
          })}
        </div>

        <div className="flex items-center gap-1">
          <ThemeToggle />
          <Button className="hidden min-h-11 rounded-full bg-brand px-5 text-brand-foreground hover:bg-brand-600 sm:inline-flex" render={<Link href="/contact" />}>
            Talk to us <ArrowUpRight data-icon="inline-end" />
          </Button>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger render={<Button variant="ghost" size="icon-lg" aria-label="Open navigation" className="min-h-11 min-w-11 rounded-full lg:hidden" />}>
              <Menu />
            </SheetTrigger>
            {/* No `glass-elevated` here: it sets a 70%-alpha background that wins
                over the component's opaque `bg-popover`, and page text reads
                straight through a full-height drawer. Glass suits the floating
                navbar pill, not a panel covering the viewport. */}
            <SheetContent side="right" className="w-[min(88vw,24rem)] border-l border-border p-6">
              <SheetHeader>
                <SheetTitle><Logo /></SheetTitle>
                <SheetDescription>Browse VelixSoft products, services, and guides.</SheetDescription>
              </SheetHeader>
              <div className="mt-8 flex flex-col gap-2">
                {mainNav.map((item) => (
                  <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className={cn('flex min-h-12 items-center rounded-xl px-4 text-base font-medium', pathname.startsWith(item.href) ? 'bg-brand-soft text-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground')}>
                    {item.label}
                  </Link>
                ))}
                <Button className="mt-3 min-h-12 rounded-xl bg-brand text-brand-foreground hover:bg-brand-600" render={<Link href="/contact" onClick={() => setOpen(false)} />}>
                  Talk to us <ArrowUpRight data-icon="inline-end" />
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  )
}
