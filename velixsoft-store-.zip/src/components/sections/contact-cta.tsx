import { Button } from '@/components/ui/button'
import { Container } from '@/src/components/ui/primitives'
import { WhatsAppIcon, TelegramIcon } from '@/src/components/ui/brand-icons'
import { telegramLink, whatsappLink } from '@/src/data/site'

export function ContactCta({ title = 'Find the product that fits.', description = 'Ask about licensing, compatibility, or a project. You talk to the people who build the software, not a sales team.' }: { title?: string; description?: string }) {
  return (
    <section className="pb-20 pt-8 sm:pb-28">
      <Container>
        <div className="brand-glow relative overflow-hidden rounded-3xl border border-brand/25 bg-brand-soft px-6 py-14 text-center sm:px-12 sm:py-20">
          <div className="relative mx-auto flex max-w-3xl flex-col items-center gap-6">
            <h2 className="text-balance text-3xl font-semibold tracking-[-0.045em] sm:text-5xl">{title}</h2>
            <p className="max-w-xl text-pretty text-base leading-7 text-muted-foreground sm:text-lg">{description}</p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button className="min-h-12 rounded-full bg-brand px-6 text-brand-foreground hover:bg-brand-600 gap-2 font-medium" render={<a href={whatsappLink("Hi, I'm interested in VelixSoft products.")} target="_blank" rel="noreferrer" />}>
                <WhatsAppIcon className="size-4 shrink-0" />
                <span>WhatsApp</span>
              </Button>
              <Button variant="outline" className="min-h-12 rounded-full bg-background/60 px-6 gap-2 font-medium" render={<a href={telegramLink("Hi, I'm interested in VelixSoft products.")} target="_blank" rel="noreferrer" />}>
                <TelegramIcon className="size-4 shrink-0" />
                <span>Telegram</span>
              </Button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  )
}
