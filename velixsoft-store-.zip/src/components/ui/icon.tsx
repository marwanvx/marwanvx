import {
  BookOpen, FileCode, Layers, LayoutDashboard, MessageCircle, MessageSquare,
  MousePointerClick, PackageCheck, Palette, RefreshCw, Rocket, ShieldCheck, Sliders,
  Smartphone, Sparkles, SunMoon, Terminal, Wrench, Zap, type LucideIcon,
} from 'lucide-react'

const map: Record<string, LucideIcon> = {
  palette: Palette, wrench: Wrench, sliders: Sliders, 'layout-dashboard': LayoutDashboard,
  sparkles: Sparkles, 'sun-moon': SunMoon, zap: Zap, 'message-circle': MessageCircle,
  'refresh-cw': RefreshCw, layers: Layers, smartphone: Smartphone, 'file-code': FileCode,
  'book-open': BookOpen, 'mouse-pointer-click': MousePointerClick, 'message-square': MessageSquare,
  'package-check': PackageCheck, rocket: Rocket, 'shield-check': ShieldCheck, terminal: Terminal,
}

export function Icon({ name, className }: { name: string; className?: string }) {
  const Component = map[name] ?? Sparkles
  return <Component className={className} />
}
