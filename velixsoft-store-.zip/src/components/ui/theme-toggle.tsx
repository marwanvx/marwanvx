'use client'

import * as React from 'react'
import { Moon, Sun } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { syncCurrentEdition } from '@/src/components/product/edition-provider'

export function ThemeToggle() {
  const [mounted, setMounted] = React.useState(false)
  const [isDark, setIsDark] = React.useState(true)

  React.useEffect(() => {
    setMounted(true)
    setIsDark(document.documentElement.classList.contains('dark'))
  }, [])

  function toggleTheme() {
    const nextDark = !document.documentElement.classList.contains('dark')
    document.documentElement.classList.toggle('dark', nextDark)
    document.documentElement.classList.toggle('light', !nextDark)
    localStorage.setItem('velix-theme', nextDark ? 'dark' : 'light')
    setIsDark(nextDark)
    syncCurrentEdition()
  }

  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-lg"
      aria-label={mounted ? `Switch to ${isDark ? 'light' : 'dark'} mode` : 'Toggle theme'}
      onClick={toggleTheme}
      className="min-h-11 min-w-11 rounded-full"
    >
      {mounted && isDark ? <Sun /> : <Moon />}
    </Button>
  )
}
