import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export function Container({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cn('mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-10', className)}>{children}</div>
}

export function SectionHeading({ eyebrow, title, description, align = 'left' }: { eyebrow?: string; title: string; description?: string; align?: 'left' | 'center' }) {
  return (
    <div className={cn('flex max-w-3xl flex-col gap-4', align === 'center' && 'mx-auto items-center text-center')}>
      {eyebrow && <Badge variant="outline" className="w-fit rounded-full border-brand/30 bg-brand-soft px-3 py-1 text-brand">{eyebrow}</Badge>}
      <h2 className="text-balance text-3xl font-semibold tracking-[-0.035em] sm:text-4xl lg:text-5xl">{title}</h2>
      {description && <p className="text-pretty text-base leading-7 text-muted-foreground sm:text-lg">{description}</p>}
    </div>
  )
}

export function PageHero({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children?: React.ReactNode }) {
  return (
    <section className="pb-16 pt-20 sm:pb-20 sm:pt-28">
      <Container>
        <div className="mx-auto flex max-w-4xl flex-col items-center gap-6 text-center">
          <Badge variant="outline" className="rounded-full border-brand/30 bg-brand-soft px-3 py-1 text-brand">{eyebrow}</Badge>
          <h1 className="text-balance text-4xl font-semibold tracking-[-0.05em] sm:text-6xl lg:text-7xl">{title}</h1>
          <p className="max-w-2xl text-pretty text-lg leading-8 text-muted-foreground">{description}</p>
          {children}
        </div>
      </Container>
    </section>
  )
}

export function EmptyCategory({ title, body }: { title: string; body: string }) {
  return (
    <div className="glass mx-auto flex max-w-2xl flex-col items-center gap-5 rounded-3xl p-8 text-center sm:p-12">
      <span className="flex size-14 items-center justify-center rounded-2xl bg-brand-soft text-2xl font-bold text-brand" aria-hidden="true">+</span>
      <div className="flex flex-col gap-2"><h2 className="text-2xl font-semibold">{title}</h2><p className="leading-7 text-muted-foreground">{body}</p></div>
      <Button variant="outline" className="min-h-11 rounded-full" render={<Link href="/contact" />}>Suggest a product <ArrowRight data-icon="inline-end" /></Button>
    </div>
  )
}

export function JsonLd({ data }: { data: Record<string, unknown> | Record<string, unknown>[] }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, '\\u003c') }} />
}
