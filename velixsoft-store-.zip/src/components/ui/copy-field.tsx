'use client'

import * as React from 'react'
import { Check, Copy } from 'lucide-react'
import { Button } from '@/components/ui/button'

/**
 * Shows a value and copies it to the clipboard — for handles that have no
 * link target, such as a Discord username.
 */
export function CopyField({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = React.useState(false)
  const timeout = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  React.useEffect(() => () => clearTimeout(timeout.current), [])

  async function copy() {
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      clearTimeout(timeout.current)
      timeout.current = setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <Button
        onClick={copy}
        aria-label={`Copy ${label}: ${value}`}
        className="min-h-11 w-full justify-between rounded-full bg-brand px-5 font-mono text-brand-foreground hover:bg-brand-600"
      >
        {value}
        {copied ? <Check data-icon="inline-end" /> : <Copy data-icon="inline-end" />}
      </Button>
      <p aria-live="polite" className="min-h-4 text-center text-xs text-muted-foreground">
        {copied ? 'Copied to clipboard' : ''}
      </p>
    </div>
  )
}
