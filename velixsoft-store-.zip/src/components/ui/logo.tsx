import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'

export function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn('inline-flex min-h-11 items-center gap-2.5 rounded-lg font-bold tracking-[0.14em]', className)} aria-label="VelixSoft home">
      <div className="relative flex size-9 items-center justify-center overflow-hidden rounded-xl shadow-sm" aria-hidden="true">
        <Image
          src="/icon.png"
          alt="VelixSoft"
          width={36}
          height={36}
          className="size-full object-cover"
          priority
        />
      </div>
      <span className="text-sm font-bold tracking-widest text-foreground">VELIXSOFT</span>
    </Link>
  )
}

