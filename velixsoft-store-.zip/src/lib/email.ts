import 'server-only'

import { Resend } from 'resend'
import { MAIL_FROM, SUPPORT_EMAIL, absoluteUrl, requireEnv } from './config'

/**
 * Transactional email.
 *
 * Email is a **notification, never the channel**. Every state these messages
 * describe is fully visible in the dashboard, so a message landing in spam delays
 * someone by a login — it never loses them anything. Nothing in the product may
 * depend on an email being delivered.
 *
 * That is also why `send()` never throws: a Resend outage must not roll back a
 * build that was successfully uploaded. Failures are logged and reported to the
 * caller, which surfaces them in admin rather than failing the action.
 */

let client: Resend | null = null
const resend = () => (client ??= new Resend(requireEnv('RESEND_API_KEY')))

interface SendResult {
  ok: boolean
  error?: string
}

async function send(to: string, subject: string, body: string): Promise<SendResult> {
  try {
    const { error } = await resend().emails.send({
      from: MAIL_FROM,
      to,
      subject,
      text: body,
      replyTo: SUPPORT_EMAIL,
    })
    if (error) {
      console.error('[email] send failed', { to, subject, error })
      return { ok: false, error: error.message }
    }
    return { ok: true }
  } catch (cause) {
    console.error('[email] send threw', { to, subject, cause })
    return { ok: false, error: cause instanceof Error ? cause.message : 'unknown' }
  }
}

const signOff = `\n\n— VelixSoft\n${SUPPORT_EMAIL}`

/** Sent by the payment webhook once an order is paid. */
export function sendPurchaseReady(input: {
  to: string
  productName: string
  needsDomain: boolean
}) {
  const next = input.needsDomain
    ? `Your next step is to tell us the domain your panel runs on. We build your theme locked to that domain, so we cannot start until we have it:\n\n${absoluteUrl('/dashboard')}`
    : `Your download is ready in your dashboard:\n\n${absoluteUrl('/dashboard')}`

  return send(
    input.to,
    `Your ${input.productName} purchase is ready`,
    `Thanks for buying ${input.productName}.\n\n${next}\n\nIf you have not set a password yet, use the sign-in link on that page and choose "forgot password" to set one.${signOff}`,
  )
}

/** Sent the moment an admin marks a build ready. Never sent separately. */
export function sendBuildReady(input: {
  to: string
  productName: string
  domain: string
  purchaseUrl: string
}) {
  return send(
    input.to,
    `Your ${input.productName} build is ready`,
    `Your build is ready to download.\n\nLocked to: ${input.domain}\n\nDownload it here:\n${absoluteUrl(input.purchaseUrl)}\n\nThe installation guide is on the same page. If you would like us to install it for you, that is free — there is a button for it next to the download.${signOff}`,
  )
}

/** Sent when a build cannot be produced. Never consumes the domain change. */
export function sendBuildFailed(input: {
  to: string
  productName: string
  domain: string
  reason: string
  purchaseUrl: string
}) {
  return send(
    input.to,
    `We could not create your ${input.productName} build`,
    `We hit a problem building your theme for ${input.domain}:\n\n${input.reason}\n\nThis has not used up your domain change — you can submit a domain again at no cost:\n${absoluteUrl(input.purchaseUrl)}\n\nReply to this email if you are not sure what to do next.${signOff}`,
  )
}

/** Sent when we reply to a support ticket. */
export function sendTicketReply(input: {
  to: string
  subject: string
  ticketUrl: string
}) {
  return send(
    input.to,
    `Re: ${input.subject}`,
    `We have replied to your support request.\n\nRead it and reply here:\n${absoluteUrl(input.ticketUrl)}${signOff}`,
  )
}

/** Sent when an installation is finished, asking the customer to revoke access. */
export function sendInstallComplete(input: { to: string; purchaseUrl: string }) {
  return send(
    input.to,
    'Your installation is complete',
    `Your theme is installed and live.\n\nOne last thing, and it matters: please delete the VelixSoft admin account on your panel, or change its password. We no longer need it, and an unused admin account is a risk to you.\n\nWhen you have done it, confirm here:\n${absoluteUrl(input.purchaseUrl)}${signOff}`,
  )
}
