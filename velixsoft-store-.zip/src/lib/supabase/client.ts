'use client'

import { createBrowserClient } from '@supabase/ssr'

/**
 * Supabase client for Client Components — sign-in forms, the Google OAuth button,
 * sign-out. Uses the anon key and is fully subject to row level security.
 */
export function createSupabaseBrowserClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  )
}
