import 'server-only'

import { createClient } from '@supabase/supabase-js'
import { requireEnv } from '../config'

/**
 * Service-role Supabase client. **Bypasses row level security entirely.**
 *
 * Only three legitimate uses:
 *   1. minting signed URLs for private storage objects, after an ownership check
 *   2. creating users from a payment webhook, where there is no session
 *   3. reading `install_requests.vx_password`, which is revoked from every
 *      client-facing role — and which must always write a `credential_reads` row
 *
 * `server-only` makes importing this from a client component a build error rather
 * than a leaked key. Do not remove that import.
 */
export function createSupabaseAdminClient() {
  return createClient(
    requireEnv('NEXT_PUBLIC_SUPABASE_URL'),
    requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
    { auth: { autoRefreshToken: false, persistSession: false } },
  )
}
