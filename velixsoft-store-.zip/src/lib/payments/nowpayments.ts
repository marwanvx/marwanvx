import 'server-only'

import { createHmac, timingSafeEqual } from 'node:crypto'
import { absoluteUrl, requireEnv } from '../config'

/**
 * NOWPayments — the only automated payment method in v1.
 *
 * Every provider call lives in this file so adding a card provider later is a
 * sibling module rather than surgery. Resist building further abstraction than
 * that: a plugin architecture for one provider is speculative work.
 *
 * Crypto brings failure modes cards do not have, and two of them are handled here
 * because getting them wrong leaks product:
 *   · IPN callbacks arrive out of order and repeatedly
 *   · a customer can pay less than the invoice
 */

const API = 'https://api.nowpayments.io/v1'

/** Statuses that mean the money has actually arrived. */
const PAID_STATUSES = ['finished', 'confirmed'] as const
/** Statuses that mean it is on the way but not yet spendable. */
const PENDING_STATUSES = ['waiting', 'confirming', 'sending', 'partially_paid'] as const

export type PaymentStatus =
  | (typeof PAID_STATUSES)[number]
  | (typeof PENDING_STATUSES)[number]
  | 'failed'
  | 'refunded'
  | 'expired'

export interface OrderMetadata {
  productId: string
  editionId?: string
  email: string
  kind: 'purchase' | 'additional_domain'
  parentOrderId?: string
}

export interface IpnPayload {
  payment_id: number | string
  payment_status: PaymentStatus
  order_id: string
  order_description?: string
  price_amount: number
  price_currency: string
  actually_paid?: number
  pay_amount?: number
  pay_currency?: string
}

/**
 * Create a hosted invoice and return its URL.
 *
 * `orderId` is our own reference, echoed back on every IPN — it is how a callback
 * is matched to an order without trusting anything else in the payload.
 */
export async function createInvoice(input: {
  orderId: string
  amount: number
  currency?: string
  description: string
  metadata: OrderMetadata
}): Promise<{ invoiceUrl: string; invoiceId: string }> {
  const response = await fetch(`${API}/invoice`, {
    method: 'POST',
    headers: {
      'x-api-key': requireEnv('NOWPAYMENTS_API_KEY'),
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      price_amount: input.amount,
      price_currency: input.currency ?? 'usd',
      order_id: input.orderId,
      order_description: input.description,
      ipn_callback_url: absoluteUrl('/api/webhooks/nowpayments'),
      success_url: absoluteUrl('/dashboard?paid=1'),
      cancel_url: absoluteUrl('/products'),
    }),
  })

  if (!response.ok) {
    throw new Error(
      `NOWPayments invoice failed (${response.status}): ${await response.text()}`,
    )
  }

  const data = (await response.json()) as { id: string; invoice_url: string }
  return { invoiceUrl: data.invoice_url, invoiceId: String(data.id) }
}

/**
 * Verify an IPN signature.
 *
 * NOWPayments signs the JSON body with HMAC-SHA512 over the payload **sorted by
 * key**. Re-serialising in a different order produces a different digest, which is
 * the usual reason a correct-looking implementation rejects every callback.
 *
 * Compared in constant time — a fast string compare leaks the signature a byte at
 * a time to anyone willing to measure.
 */
export function verifyIpnSignature(rawBody: string, signature: string | null): boolean {
  if (!signature) return false

  let sorted: string
  try {
    sorted = JSON.stringify(sortDeep(JSON.parse(rawBody)))
  } catch {
    return false
  }

  const expected = createHmac('sha512', requireEnv('NOWPAYMENTS_IPN_SECRET'))
    .update(sorted)
    .digest('hex')

  const a = Buffer.from(expected, 'utf8')
  const b = Buffer.from(signature, 'utf8')
  return a.length === b.length && timingSafeEqual(a, b)
}

function sortDeep(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortDeep)
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.keys(value as Record<string, unknown>)
        .sort()
        .map((key) => [key, sortDeep((value as Record<string, unknown>)[key])]),
    )
  }
  return value
}

export const isPaid = (status: PaymentStatus) =>
  (PAID_STATUSES as readonly string[]).includes(status)

export const isPending = (status: PaymentStatus) =>
  (PENDING_STATUSES as readonly string[]).includes(status)

/**
 * True when less arrived than was owed.
 *
 * An underpaid order must stay `pending` and be surfaced in admin. Auto-fulfilling
 * a partial payment is the most common way a crypto checkout gives product away.
 * The 1% tolerance absorbs network fees and rounding, not genuine shortfalls.
 */
export function isUnderpaid(payload: IpnPayload): boolean {
  const paid = payload.actually_paid
  const due = payload.pay_amount
  if (paid == null || due == null) return false
  return paid < due * 0.99
}
