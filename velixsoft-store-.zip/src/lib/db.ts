import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import * as schema from '@/src/db/schema'
import { requireEnv } from './config'

/**
 * Drizzle client, server-only.
 *
 * This connects as the database owner and therefore **bypasses row level
 * security**. That is intentional — it is the server-side path, where
 * `requireUser()` / `requireAdmin()` and explicit `where` clauses are the access
 * control. RLS exists to protect the Supabase client path, which browsers can
 * reach. Never import this module from a client component.
 *
 * The connection is memoised on `globalThis` because Next.js dev recreates modules
 * on every hot reload, and a fresh pool per reload exhausts Postgres connections
 * within a few minutes.
 */

declare global {
  // eslint-disable-next-line no-var
  var __velixsoftDb: ReturnType<typeof createClient> | undefined
}

function createClient() {
  const client = postgres(requireEnv('DATABASE_URL'), {
    // Supabase's pooler does not support prepared statements.
    prepare: false,
    max: 10,
  })
  return drizzle(client, { schema })
}

export const db = globalThis.__velixsoftDb ?? createClient()

if (process.env.NODE_ENV !== 'production') globalThis.__velixsoftDb = db

export { schema }
