/**
 * Values the dashboard needs that are not product data.
 *
 * These are imported, never inlined, so changing one is a single edit rather than
 * a search across the codebase.
 */

/**
 * Mailbox that receives 2FA codes for customer panel accounts during a free
 * installation.
 *
 * Deliberately not the public business address: once we have installed for a few
 * dozen customers, whoever controls this inbox controls a few dozen SMM panels
 * holding real customer balances. It needs its own hardware-key 2FA.
 */
export const OPS_EMAIL = 'install@velixsoft.net'

/** Public support address, shown to customers. */
export const SUPPORT_EMAIL = 'velixsoft@gmail.com'

/** Address transactional mail is sent from. Must be a verified Resend domain. */
export const MAIL_FROM = 'VelixSoft <noreply@velixsoft.net>'

/**
 * An additional domain costs this fraction of list price.
 *
 * A customer gets one paid domain change and then the domain is fixed (design doc
 * decision 12). Admin can always override — the rule governs the customer flow,
 * not the business.
 */
export const DOMAIN_CHANGE_RATE = 0.5

/** How long a build download link stays valid, in seconds. */
export const SIGNED_URL_TTL = 60

/** Private storage buckets. None of these may ever be made public. */
export const BUCKETS = {
  builds: 'builds',
  releases: 'releases',
  ticketAttachments: 'ticket-attachments',
} as const

export const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL ?? 'https://www.velixsoft.net'

/** Absolute URL for links inside emails, which cannot use relative paths. */
export const absoluteUrl = (path: string) =>
  `${siteUrl}${path.startsWith('/') ? path : `/${path}`}`

/**
 * Reads an environment variable or throws.
 *
 * Failing at startup with a named variable beats failing at runtime with
 * "undefined is not a string" three layers into a webhook.
 */
export function requireEnv(name: string): string {
  const value = process.env[name]
  if (!value) throw new Error(`Missing required environment variable: ${name}`)
  return value
}
