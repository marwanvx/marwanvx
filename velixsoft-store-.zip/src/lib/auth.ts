import 'server-only'

import { eq } from 'drizzle-orm'
import { notFound, redirect } from 'next/navigation'
import { profiles, type Profile } from '@/src/db/schema'
import { db } from './db'
import { createSupabaseServerClient } from './supabase/server'

/**
 * The real authorization gate.
 *
 * Middleware redirects; it does not authorize. Next.js middleware can be bypassed
 * and does not run on every path you would expect, so every page and every server
 * action calls one of these helpers. Row level security is the third layer,
 * catching the query someone forgot to scope.
 */

export interface Session {
  userId: string
  email: string
  profile: Profile
}

/**
 * Current session, or null.
 *
 * Uses `getUser()` rather than `getSession()` deliberately: `getSession()` reads
 * the cookie without verifying it, so it can be forged. `getUser()` validates
 * against the auth server.
 */
export async function getSession(): Promise<Session | null> {
  const supabase = await createSupabaseServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user?.email) return null

  const profile = await db.query.profiles.findFirst({
    where: eq(profiles.id, user.id),
  })

  // The signup trigger creates the profile. If it is missing, the account is in a
  // broken state and must not be treated as signed in.
  if (!profile) return null

  return { userId: user.id, email: user.email, profile }
}

/** Session, or redirect to login. Use in every authenticated page and action. */
export async function requireUser(): Promise<Session> {
  const session = await getSession()
  if (!session) redirect('/login')
  return session
}

/**
 * Session with the admin role, or 404.
 *
 * 404 rather than 403 on purpose: a signed-in customer probing /admin learns
 * nothing about whether those routes exist.
 */
export async function requireAdmin(): Promise<Session> {
  const session = await requireUser()
  if (session.profile.role !== 'admin') notFound()
  return session
}

export async function isAdmin(): Promise<boolean> {
  const session = await getSession()
  return session?.profile.role === 'admin'
}
