'use server'

import { revalidatePath } from 'next/cache'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import { createSupabaseServerClient } from '../supabase/server'

/**
 * Auth server actions.
 *
 * Every one revalidates `/` at layout scope before redirecting. Without that the
 * cached layout keeps rendering the signed-out header after a successful login,
 * which reads as "it didn't work" and produces a second login attempt.
 *
 * Errors are returned, never thrown, so the form can render them inline. Note
 * that `redirect()` throws by design — it must sit outside any try/catch or the
 * navigation gets swallowed as an error.
 */

export interface AuthResult {
  error?: string
}

/** Only ever redirect to a path on this site. See app/(app)/auth/callback. */
function safeNext(value: FormDataEntryValue | null): string {
  const next = typeof value === 'string' ? value : ''
  if (!next.startsWith('/') || next.startsWith('//')) return '/dashboard'
  return next
}

/** Request origin, so OAuth and email links work on previews and localhost. */
async function requestOrigin(): Promise<string> {
  const headerList = await headers()
  const host = headerList.get('x-forwarded-host') ?? headerList.get('host')
  const proto = headerList.get('x-forwarded-proto') ?? 'https'
  return host ? `${proto}://${host}` : (process.env.NEXT_PUBLIC_SITE_URL ?? '')
}

export async function signIn(formData: FormData): Promise<AuthResult> {
  const email = String(formData.get('email') ?? '').trim()
  const password = String(formData.get('password') ?? '')
  const next = safeNext(formData.get('next'))

  if (!email || !password) return { error: 'Enter your email and password.' }

  const supabase = await createSupabaseServerClient()
  const { error } = await supabase.auth.signInWithPassword({ email, password })

  // Deliberately vague: distinguishing "no such account" from "wrong password"
  // turns the login form into an account-enumeration oracle.
  if (error) return { error: 'That email and password do not match an account.' }

  revalidatePath('/', 'layout')
  redirect(next)
}

export async function signUp(formData: FormData): Promise<AuthResult> {
  const email = String(formData.get('email') ?? '').trim()
  const password = String(formData.get('password') ?? '')
  const name = String(formData.get('name') ?? '').trim()

  if (!email || !password) return { error: 'Enter your email and password.' }
  if (password.length < 8) {
    return { error: 'Use at least 8 characters for your password.' }
  }

  const supabase = await createSupabaseServerClient()
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: name || null },
      emailRedirectTo: `${await requestOrigin()}/auth/callback`,
    },
  })

  if (error) return { error: error.message }

  revalidatePath('/', 'layout')
  redirect('/dashboard')
}

/**
 * Google OAuth. Returns the provider URL for the client to navigate to —
 * a server action cannot redirect cross-origin.
 *
 * The account-linking rule (a Google identity may attach to an existing profile
 * only when the email matches AND was already verified) is enforced by Supabase's
 * own identity linking settings, not here. Confirm "Confirm email" is on and
 * automatic linking is restricted to verified emails in the Supabase dashboard.
 */
export async function signInWithGoogle(
  formData: FormData,
): Promise<AuthResult & { url?: string }> {
  const next = safeNext(formData.get('next'))
  const supabase = await createSupabaseServerClient()

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${await requestOrigin()}/auth/callback?next=${encodeURIComponent(next)}`,
    },
  })

  if (error || !data.url) {
    return { error: error?.message ?? 'Could not start Google sign-in.' }
  }

  return { url: data.url }
}

export async function signOut(): Promise<void> {
  const supabase = await createSupabaseServerClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  redirect('/')
}

/**
 * Send a password reset email.
 *
 * Always reports success, even for an address with no account — the response
 * must not reveal who has one.
 */
export async function requestPasswordReset(formData: FormData): Promise<AuthResult> {
  const email = String(formData.get('email') ?? '').trim()
  if (!email) return { error: 'Enter your email address.' }

  const supabase = await createSupabaseServerClient()
  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${await requestOrigin()}/auth/callback?next=/dashboard/settings`,
  })

  return {}
}

/** Set a new password. Requires an active session from the reset link. */
export async function updatePassword(formData: FormData): Promise<AuthResult> {
  const password = String(formData.get('password') ?? '')
  if (password.length < 8) {
    return { error: 'Use at least 8 characters for your password.' }
  }

  const supabase = await createSupabaseServerClient()
  const { error } = await supabase.auth.updateUser({ password })

  if (error) return { error: error.message }

  revalidatePath('/', 'layout')
  return {}
}
