/**
 * Domain normalisation for theme builds.
 *
 * This is small and unusually load-bearing. The lock is compiled into the customer's
 * zip and cannot be revoked, and by business rule a customer gets exactly one paid
 * domain change and then it is fixed. So a domain accepted with a typo costs the
 * customer $74.50 or costs us a rebuild — normalisation and an explicit confirm
 * screen are the only defences that exist.
 */

/** A build locked to `example.com` also serves `www.example.com`, and nothing else. */
export function lockedHostnames(domain: string): string[] {
  return [domain, `www.${domain}`]
}

export type NormalizeResult =
  | { ok: true; domain: string }
  | { ok: false; error: string }

const HOSTNAME = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/

/**
 * Reduce whatever the customer pasted to a bare apex hostname.
 *
 * Accepts `https://www.Example.com/admin?x=1` and returns `example.com`. Rejects
 * anything that is not a plausible public hostname — an IP address, `localhost`,
 * a port, or a bare label with no dot.
 */
export function normalizeDomain(input: string): NormalizeResult {
  let value = input.trim().toLowerCase()

  if (!value) return { ok: false, error: 'Enter your domain.' }

  value = value.replace(/^[a-z][a-z0-9+.-]*:\/\//, '')
  value = value.replace(/^[^/@]*@/, '') // strip any user:pass@
  value = value.split(/[/?#]/)[0] // strip path, query, fragment
  value = value.replace(/\.$/, '') // strip the FQDN root dot

  if (value.includes(':')) {
    return { ok: false, error: 'Remove the port number — just the domain.' }
  }

  // www is a variant of the apex, not a domain of its own. Stripping it here is
  // what makes `lockedHostnames` correct.
  value = value.replace(/^www\./, '')

  if (!value) return { ok: false, error: 'Enter your domain.' }

  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value)) {
    return { ok: false, error: 'Enter a domain name, not an IP address.' }
  }

  if (!value.includes('.')) {
    return { ok: false, error: 'That does not look like a full domain.' }
  }

  if (!HOSTNAME.test(value)) {
    return { ok: false, error: 'That does not look like a valid domain.' }
  }

  return { ok: true, domain: value }
}

/**
 * True when the input names a subdomain other than `www`.
 *
 * Not an error — plenty of panels legitimately run at `panel.example.com` — but
 * the confirm screen should say so out loud, because a customer who meant the apex
 * has one chance to notice before the lock is permanent.
 */
export function isSubdomain(domain: string): boolean {
  return domain.split('.').length > 2
}
