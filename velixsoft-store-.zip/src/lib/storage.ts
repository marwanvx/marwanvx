import 'server-only'

import { createHash, randomUUID } from 'node:crypto'
import { BUCKETS, SIGNED_URL_TTL } from './config'
import { createSupabaseAdminClient } from './supabase/admin'

/**
 * Private file storage for build artifacts and installers.
 *
 * Every bucket here is private. A paid, domain-locked zip must never sit behind a
 * guessable public URL — files are handed out only as short-lived signed URLs,
 * minted after the caller has verified ownership. `signedUrl()` does not check
 * anything itself; that is the caller's job, and it is the one rule in this file
 * that matters.
 */

export interface StoredFile {
  fileKey: string
  fileSize: number
  checksum: string
}

type Bucket = (typeof BUCKETS)[keyof typeof BUCKETS]

/**
 * Store a build zip and return what the `builds` row needs.
 *
 * The checksum is shown to the customer next to the download so they can verify
 * the file arrived intact — worth having when the artifact is unique to them and
 * cannot simply be re-downloaded from a shared source.
 */
export async function putBuild(
  file: File | Blob,
  meta: { orderId: string; domain: string },
): Promise<StoredFile> {
  const bytes = Buffer.from(await file.arrayBuffer())
  const checksum = createHash('sha256').update(bytes).digest('hex')

  // Path includes a random segment so the key cannot be guessed from the order id
  // alone, and the domain so an admin can identify a file at a glance.
  const fileKey = `${meta.orderId}/${randomUUID()}/${meta.domain}.zip`

  const supabase = createSupabaseAdminClient()
  const { error } = await supabase.storage.from(BUCKETS.builds).upload(fileKey, bytes, {
    contentType: 'application/zip',
    upsert: false,
  })

  if (error) throw new Error(`Build upload failed: ${error.message}`)

  return { fileKey, fileSize: bytes.byteLength, checksum }
}

/** Store an installer for a shared-download product. */
export async function putRelease(
  file: File | Blob,
  meta: { productSlug: string; version: string; platform: string },
): Promise<StoredFile> {
  const bytes = Buffer.from(await file.arrayBuffer())
  const checksum = createHash('sha256').update(bytes).digest('hex')
  const extension = 'name' in file ? (file.name.split('.').pop() ?? 'bin') : 'bin'
  const fileKey = `${meta.productSlug}/${meta.version}/${meta.platform}.${extension}`

  const supabase = createSupabaseAdminClient()
  const { error } = await supabase.storage
    .from(BUCKETS.releases)
    .upload(fileKey, bytes, { upsert: true })

  if (error) throw new Error(`Release upload failed: ${error.message}`)

  return { fileKey, fileSize: bytes.byteLength, checksum }
}

/**
 * Mint a short-lived download URL.
 *
 * ⚠️ This performs NO authorization. Callers must have already confirmed that the
 * signed-in user owns the order behind this file, and must record the download.
 */
export async function signedUrl(
  fileKey: string,
  options: { bucket?: Bucket; ttl?: number; downloadAs?: string } = {},
): Promise<string> {
  const { bucket = BUCKETS.builds, ttl = SIGNED_URL_TTL, downloadAs } = options

  const supabase = createSupabaseAdminClient()
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(fileKey, ttl, downloadAs ? { download: downloadAs } : undefined)

  if (error || !data) {
    throw new Error(`Could not create download link: ${error?.message ?? 'unknown'}`)
  }

  return data.signedUrl
}

export async function removeFile(fileKey: string, bucket: Bucket = BUCKETS.builds) {
  const supabase = createSupabaseAdminClient()
  await supabase.storage.from(bucket).remove([fileKey])
}
