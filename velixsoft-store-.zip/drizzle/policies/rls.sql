-- VelixSoft dashboard — row level security, triggers and grants.
--
-- Run this AFTER `drizzle-kit push` has created the tables.
--   psql "$DATABASE_URL" -f drizzle/policies/rls.sql
-- It is idempotent; re-running it is safe.
--
-- Layering (design doc §10): middleware only redirects, server code is the real
-- gate via requireUser()/requireAdmin(), and these policies are the backstop that
-- catches a query someone forgot to scope.
--
-- Note on the two connection paths:
--   · Drizzle over DATABASE_URL connects as the database owner and BYPASSES RLS.
--     That is the server-side path, already protected by requireUser/requireAdmin.
--   · The Supabase client (anon / authenticated) is subject to everything below.
-- Both matter. Never expose the service role key to a client component.

begin;

-- ---------------------------------------------------------------------------
-- Identity: tie profiles to auth.users and create one automatically on signup
-- ---------------------------------------------------------------------------

alter table public.profiles
  drop constraint if exists profiles_id_fkey;
alter table public.profiles
  add constraint profiles_id_fkey
  foreign key (id) references auth.users (id) on delete cascade;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name')
  )
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Helper
-- ---------------------------------------------------------------------------

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- ---------------------------------------------------------------------------
-- Enable RLS everywhere. A table with RLS on and no policy denies everything,
-- which is the correct default for anything we forget below.
-- ---------------------------------------------------------------------------

alter table public.profiles          enable row level security;
alter table public.products          enable row level security;
alter table public.editions          enable row level security;
alter table public.orders            enable row level security;
alter table public.builds            enable row level security;
alter table public.licenses          enable row level security;
alter table public.releases          enable row level security;
alter table public.install_requests  enable row level security;
alter table public.tickets           enable row level security;
alter table public.ticket_messages   enable row level security;
alter table public.build_downloads   enable row level security;
alter table public.credential_reads  enable row level security;

-- ---------------------------------------------------------------------------
-- Catalogue: world-readable. These render the public marketing pages.
-- ---------------------------------------------------------------------------

drop policy if exists products_public_read on public.products;
create policy products_public_read on public.products
  for select using (status <> 'archived' or public.is_admin());

drop policy if exists products_admin_write on public.products;
create policy products_admin_write on public.products
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists editions_public_read on public.editions;
create policy editions_public_read on public.editions for select using (true);

drop policy if exists editions_admin_write on public.editions;
create policy editions_admin_write on public.editions
  for all using (public.is_admin()) with check (public.is_admin());

-- Releases list versions of shared-download products. Metadata is public; the
-- files themselves live in a private bucket and are only ever handed out as
-- signed URLs after an ownership check.
drop policy if exists releases_public_read on public.releases;
create policy releases_public_read on public.releases for select using (true);

drop policy if exists releases_admin_write on public.releases;
create policy releases_admin_write on public.releases
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------

drop policy if exists profiles_read_own on public.profiles;
create policy profiles_read_own on public.profiles
  for select using (id = auth.uid() or public.is_admin());

-- Name only. Role and email are not self-serve — a customer must never be able to
-- promote themselves to admin.
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid() and role = 'customer');

drop policy if exists profiles_admin_all on public.profiles;
create policy profiles_admin_all on public.profiles
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Commerce: customers read their own rows and write nothing. Orders, builds and
-- licences are created by webhooks and admin, both of which run server-side with
-- elevated credentials.
-- ---------------------------------------------------------------------------

drop policy if exists orders_read_own on public.orders;
create policy orders_read_own on public.orders
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists orders_admin_write on public.orders;
create policy orders_admin_write on public.orders
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists builds_read_own on public.builds;
create policy builds_read_own on public.builds
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.orders o
      where o.id = builds.order_id and o.user_id = auth.uid()
    )
  );

-- The one customer write in the whole commerce set: naming the domain on a build
-- that is still a draft and belongs to them. Once it leaves 'draft' it is frozen.
drop policy if exists builds_set_own_domain on public.builds;
create policy builds_set_own_domain on public.builds
  for update using (
    status = 'draft'
    and exists (
      select 1 from public.orders o
      where o.id = builds.order_id and o.user_id = auth.uid()
    )
  ) with check (
    status in ('draft', 'pending')
    and exists (
      select 1 from public.orders o
      where o.id = builds.order_id and o.user_id = auth.uid()
    )
  );

drop policy if exists builds_admin_write on public.builds;
create policy builds_admin_write on public.builds
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists licenses_read_own on public.licenses;
create policy licenses_read_own on public.licenses
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists licenses_admin_write on public.licenses;
create policy licenses_admin_write on public.licenses
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Installation requests
-- ---------------------------------------------------------------------------

drop policy if exists installs_read_own on public.install_requests;
create policy installs_read_own on public.install_requests
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists installs_insert_own on public.install_requests;
create policy installs_insert_own on public.install_requests
  for insert with check (
    user_id = auth.uid()
    and exists (
      select 1 from public.orders o
      where o.id = install_requests.order_id and o.user_id = auth.uid()
    )
  );

drop policy if exists installs_update_own on public.install_requests;
create policy installs_update_own on public.install_requests
  for update using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists installs_admin_all on public.install_requests;
create policy installs_admin_all on public.install_requests
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- ⚠️ Panel credentials.
--
-- RLS is ROW level, so a policy cannot hide a single column. Column privileges
-- can. `vx_password` is revoked from every client-facing role: an authenticated
-- customer selecting from install_requests simply cannot name that column, and
-- `select *` will error rather than leak.
--
-- Admin reads therefore happen server-side over the service role, and MUST write
-- a credential_reads row each time — see src/lib/installs.ts.
--
-- This is a mitigation, not a fix. The password is still stored in readable form
-- by explicit decision (design doc §3, decision 13); a database dump exposes it.
-- ---------------------------------------------------------------------------

revoke select (vx_password) on public.install_requests from anon, authenticated;
revoke update (vx_password) on public.install_requests from anon;

drop policy if exists credential_reads_admin on public.credential_reads;
create policy credential_reads_admin on public.credential_reads
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Support
-- ---------------------------------------------------------------------------

drop policy if exists tickets_read_own on public.tickets;
create policy tickets_read_own on public.tickets
  for select using (user_id = auth.uid() or public.is_admin());

drop policy if exists tickets_insert_own on public.tickets;
create policy tickets_insert_own on public.tickets
  for insert with check (user_id = auth.uid());

drop policy if exists tickets_admin_all on public.tickets;
create policy tickets_admin_all on public.tickets
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists messages_read_own on public.ticket_messages;
create policy messages_read_own on public.ticket_messages
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.tickets t
      where t.id = ticket_messages.ticket_id and t.user_id = auth.uid()
    )
  );

-- No update or delete policy anywhere: a support thread is a record, not a draft.
drop policy if exists messages_insert_own on public.ticket_messages;
create policy messages_insert_own on public.ticket_messages
  for insert with check (
    author_id = auth.uid()
    and exists (
      select 1 from public.tickets t
      where t.id = ticket_messages.ticket_id
        and (t.user_id = auth.uid() or public.is_admin())
    )
  );

drop policy if exists messages_admin_all on public.ticket_messages;
create policy messages_admin_all on public.ticket_messages
  for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- Audit: written server-side, read by admin only. Deliberately no customer
-- read policy — download history is ours, not theirs.
-- ---------------------------------------------------------------------------

drop policy if exists downloads_admin_read on public.build_downloads;
create policy downloads_admin_read on public.build_downloads
  for select using (public.is_admin());

-- ---------------------------------------------------------------------------
-- Storage: the `builds` bucket is private and has no client policies at all.
-- Every object is reached through a short-lived signed URL minted server-side
-- after an ownership check (src/lib/storage.ts). Do not add a public policy.
-- ---------------------------------------------------------------------------

insert into storage.buckets (id, name, public)
values ('builds', 'builds', false)
on conflict (id) do update set public = false;

insert into storage.buckets (id, name, public)
values ('releases', 'releases', false)
on conflict (id) do update set public = false;

insert into storage.buckets (id, name, public)
values ('ticket-attachments', 'ticket-attachments', false)
on conflict (id) do update set public = false;

commit;

-- ---------------------------------------------------------------------------
-- Promote yourself to admin. There is no bootstrap UI, by design.
-- Run this once, after signing up:
--
--   update public.profiles set role = 'admin' where email = 'velixsoft@gmail.com';
-- ---------------------------------------------------------------------------
