# VelixSoft

Website for VelixSoft, a software company building desktop applications for Windows and macOS, automation tools, and digital products. Next.js 16, TypeScript, Tailwind CSS 4, shadcn/ui, and Lucide.

**Before writing any customer-facing copy, read [`docs/BRAND.md`](docs/BRAND.md).** It defines the messaging hierarchy, voice, banned vocabulary, and terminology that keep the site reading as a software company rather than a theme shop.

## Run locally

```bash
pnpm install
pnpm dev
```

Production validation: `pnpm build`. Deploy to Vercel without additional configuration.

## Architecture

- `app/` — App Router routes, metadata, OG image, sitemap, and robots
- `src/data/` — typed products, guides, services, testimonials, legal content, and site configuration
- `src/components/ui/` — shared design-system primitives
- `src/components/product/` — gallery, edition switcher, reveal slider, cards, and detail composition
- `src/components/sections/` — page-level compositions
- `public/products/[slug]/` — product screenshot assets

## Add a product

Add a typed entry in `src/data/products.ts`. The discriminated union in `src/data/types.ts` requires shared commerce/content/SEO fields, then narrows by `type`:

- `theme`: platform, compatibility, styled pages, install steps, changelog, and optional editions
- `app`: platforms, version, requirements, download size, and changelog
- `tool`: runtime, integrations, and usage limits
- `data`: record count, formats, sample rows, update frequency, and delivery method

Add the product slug to any guide's `relatedProducts` array to create internal links. Product and sitemap routes are generated automatically.

## Optional editions

`editions` belongs only to theme products that need it. Every edition control checks `product.editions?.length`; products without editions render normally with no empty selector. Each edition defines `color`, `brand600`, and `brand400`. The provider updates `--brand`, `--brand-600`, and `--brand-400`, persists the chosen edition under `velix-edition`, and keeps the selection across light/dark theme changes.

## Screenshot assets

Place real files in `public/products/perfect-panel-theme/` using:

```
{edition}-{mode}-{device}-{page}.avif
```

Assets ship as `.avif`, resolved by `galleryImagePath()` in `src/data/products.ts`. Required combinations are six editions × two modes × five device/page combinations: desktop `home-hero`, `home-full`, `dashboard`; mobile `mobile-home-full`, `mobile-dashboard-full`. YTLeads Pro uses the flat `{mode}-desktop-{page}.avif` pattern with no edition segment.

## Replace before launch

- Product prices: `src/data/products.ts`
- WhatsApp number, Telegram handle, email, and social links: `src/data/site.ts`
- Testimonials in `src/data/content.ts` — none are currently marked `isPlaceholder`, so they publish as real customer quotes. Replace them with verified quotes or set `isPlaceholder: true` and remove them from the render.
- Canonical domain is `https://www.velixsoft.net` (the apex redirects to `www`): `src/data/site.ts`. Every canonical, sitemap entry, schema `@id`, and OG URL derives from `siteConfig.url` — change it in that one place.
- Review legal copy for your jurisdiction before publishing

## Themes and SEO

Theme and edition preferences are restored by an inline pre-hydration script in `app/layout.tsx` to prevent a flash. Route metadata is hand-written; product metadata and OG cards are dynamic. `app/opengraph-image.tsx` provides the default social card for every route without its own. Structured data includes Organization (the `@id` anchor at `/#organization`), WebSite, Product/Offer, SoftwareApplication for desktop apps, breadcrumbs, FAQPage, and Article.

## IndexNow

`pnpm indexnow` pushes every URL in the live sitemap to IndexNow, so participating engines are told what changed instead of waiting to rediscover it.

**Run it after a deploy is live**, not during the build. The script reads the deployed `sitemap.xml`, so running it pre-deploy submits the previous build's URLs. Use `pnpm indexnow --dry-run` to see the list without sending anything.

Two guards fail the run rather than submitting silently-rejected data: every URL must be on `www.velixsoft.net`, and `public/<key>.txt` must be publicly readable and contain exactly the key. The key is defined once in `scripts/indexnow.mjs` and the filename in `public/` must match it. Rotating the key means changing both.

**Bing, Yandex, Seznam, Naver, and Yep participate. Google does not.** This complements Google Search Console, it does not replace it. Bing coverage does carry into Copilot and some AI search surfaces, so it is worth running.

`app/robots.ts` explicitly allows the major AI search crawlers — this is the file AI vendors actually document that they read. `public/llms.txt` and `public/llms-full.txt` are also published, but vendor adoption of that convention is minimal (see `docs/BRAND.md` §8); keep them in sync with the site so they never contradict it, and never move content out of rendered HTML into them.
