import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

/**
 * Session refresh and redirect for authenticated routes.
 *
 * ⚠️ This middleware does NOT authorize anything. It refreshes the Supabase
 * session cookie and bounces signed-out visitors to /login. Real authorization is
 * `requireUser()` / `requireAdmin()` inside every page and server action, with row
 * level security as the backstop. Middleware can be bypassed; treating it as the
 * gate would be a security bug.
 *
 * ⚠️ The matcher is an ALLOWLIST and must stay one.
 *
 * The marketing site is 29 statically prerendered pages carrying structured data,
 * an image sitemap and a Google Merchant Center feed. A matcher that catches them
 * makes every one dynamic — losing static delivery, TTFB, and quite possibly
 * rankings. Never widen this to `/:path*` with exclusions; add explicit prefixes.
 */
export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*', '/login', '/signup'],
}

const PUBLIC_PATHS = ['/login', '/signup']

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (cookiesToSet) => {
          for (const { name, value } of cookiesToSet) {
            request.cookies.set(name, value)
          }
          response = NextResponse.next({ request })
          for (const { name, value, options } of cookiesToSet) {
            response.cookies.set(name, value, options)
          }
        },
      },
    },
  )

  // Must be getUser(), not getSession(): getSession reads the cookie without
  // verifying it. This call is also what refreshes an expiring token.
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const { pathname, search } = request.nextUrl
  const isPublic = PUBLIC_PATHS.includes(pathname)

  if (!user && !isPublic) {
    const login = request.nextUrl.clone()
    login.pathname = '/login'
    login.search = ''
    // Preserve where they were headed so login can return them there.
    login.searchParams.set('next', `${pathname}${search}`)
    return NextResponse.redirect(login)
  }

  if (user && isPublic) {
    const dashboard = request.nextUrl.clone()
    dashboard.pathname = '/dashboard'
    dashboard.search = ''
    return NextResponse.redirect(dashboard)
  }

  return response
}
