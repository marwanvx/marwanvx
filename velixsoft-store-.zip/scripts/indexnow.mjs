#!/usr/bin/env node
/**
 * Submit every sitemap URL to IndexNow.
 *
 * IndexNow is a push protocol: instead of waiting for a crawler to rediscover
 * the site, we tell participating engines which URLs changed. Supported by
 * Bing, Yandex, Seznam, Naver and Yep. Google does NOT participate, so this
 * complements Search Console rather than replacing it.
 *
 * Run after a deploy is live, because it reads the deployed sitemap:
 *
 *   pnpm indexnow            submit every URL in the live sitemap
 *   pnpm indexnow --dry-run  print what would be submitted, send nothing
 *
 * The key below must match the filename of the verification file in `public/`.
 * Engines fetch `https://<host>/<key>.txt` and expect it to contain the key.
 */

const KEY = '59d9b0fd4a0adfbc55c4f6db9b564274'
const HOST = 'www.velixsoft.net'
const ORIGIN = `https://${HOST}`
const ENDPOINT = 'https://api.indexnow.org/indexnow'

const dryRun = process.argv.includes('--dry-run')

/** IndexNow rejects the whole batch if any URL is off-host, so filter first. */
function ownUrlsFrom(xml) {
  const locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => m[1].trim())
  return [...new Set(locs)].filter((url) => {
    try {
      return new URL(url).host === HOST
    } catch {
      return false
    }
  })
}

async function main() {
  const sitemapUrl = `${ORIGIN}/sitemap.xml`
  process.stdout.write(`Reading ${sitemapUrl}\n`)

  const res = await fetch(sitemapUrl, { headers: { 'user-agent': 'velixsoft-indexnow' } })
  if (!res.ok) {
    throw new Error(`Sitemap returned ${res.status}. Is the deploy live?`)
  }

  const urlList = ownUrlsFrom(await res.text())
  if (urlList.length === 0) {
    throw new Error(`No ${HOST} URLs found in the sitemap. Check siteConfig.url.`)
  }

  process.stdout.write(`Found ${urlList.length} URLs\n`)
  for (const url of urlList) process.stdout.write(`  ${url}\n`)

  // Verify the key file is reachable before submitting; engines will fetch it,
  // and a 404 here means every submission is silently rejected.
  const keyFileUrl = `${ORIGIN}/${KEY}.txt`
  const keyRes = await fetch(keyFileUrl)
  const keyBody = keyRes.ok ? (await keyRes.text()).trim() : ''
  if (keyBody !== KEY) {
    throw new Error(
      `Key file check failed at ${keyFileUrl} (status ${keyRes.status}).\n` +
        `It must be publicly readable and contain exactly: ${KEY}`,
    )
  }
  process.stdout.write(`Key file verified at ${keyFileUrl}\n`)

  if (dryRun) {
    process.stdout.write('\nDry run: nothing submitted.\n')
    return
  }

  const submit = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'content-type': 'application/json; charset=utf-8' },
    body: JSON.stringify({ host: HOST, key: KEY, keyLocation: keyFileUrl, urlList }),
  })

  // 200 = accepted, 202 = accepted but key still being validated.
  if (submit.status === 200 || submit.status === 202) {
    process.stdout.write(`\nSubmitted ${urlList.length} URLs (HTTP ${submit.status}).\n`)
    return
  }

  const detail = await submit.text().catch(() => '')
  throw new Error(`IndexNow returned ${submit.status}. ${detail}`.trim())
}

main().catch((error) => {
  process.stderr.write(`\nIndexNow submission failed: ${error.message}\n`)
  process.exit(1)
})
