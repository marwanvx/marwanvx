import type { Metadata } from 'next'
import { ServicesPage } from '@/src/components/sections/content-pages'
export const metadata: Metadata = { title: 'Design, Deployment & Customization Services', description: 'Interface design, deployment and installation, and product customization from VelixSoft. Written scope and price before any work begins.', alternates: { canonical: '/services' }, openGraph: { url: '/services' } }
export default function Page() { return <ServicesPage /> }
