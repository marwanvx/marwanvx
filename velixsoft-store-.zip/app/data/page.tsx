import type { Metadata } from 'next'
import { CategoryPage } from '@/src/components/sections/category-page'
import { categoryContent } from '@/src/data/content'
const seo = categoryContent.data.seo
export const metadata: Metadata = { title: seo.title, description: seo.description, keywords: seo.keywords, alternates: { canonical: '/data' }, openGraph: { url: '/data' } }
export default function Page() { return <CategoryPage type="data" /> }
