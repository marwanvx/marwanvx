import { feedItems, type FeedItem } from '@/src/data/merchant-feed'
import { siteConfig } from '@/src/data/site'

/**
 * Google Merchant Center product feed, served at `/product-feed.xml`.
 *
 * Merchant Center can take products as a one-time file upload or by fetching a
 * URL on a schedule. This is the URL: it is generated from `products.ts` on
 * every build, so a price change or a new product reaches Merchant Center on
 * the next scheduled fetch without anyone remembering to re-export a
 * spreadsheet. A hand-maintained .tsv would drift from the site the first time
 * it was forgotten, and a feed that disagrees with the landing page is a
 * disapproval ("price mismatch"), not a cosmetic error.
 *
 * The format is RSS 2.0 with Google's `g:` namespace. Attribute names and value
 * formats follow the product data specification exactly — Merchant Center
 * ignores attributes it does not recognise and rejects ones it does recognise
 * but cannot parse, so spelling matters more than completeness here.
 */

export const dynamic = 'force-static'

const XML_ESCAPES: Record<string, string> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&apos;',
}

const escapeXml = (value: string) => value.replace(/[&<>"']/g, (char) => XML_ESCAPES[char])

const tag = (name: string, value: string) => `<${name}>${escapeXml(value)}</${name}>`

function renderItem(item: FeedItem): string {
  const lines = [
    tag('g:id', item.id),
    tag('g:title', item.title),
    tag('g:description', item.description),
    tag('g:link', item.link),
    tag('g:image_link', item.imageLink),
    ...item.additionalImageLinks.map((link) => tag('g:additional_image_link', link)),
    tag('g:availability', item.availability),
    tag('g:price', item.price),
    tag('g:brand', item.brand),
    tag('g:mpn', item.mpn),
    tag('g:condition', item.condition),
    tag('g:google_product_category', item.googleCategory),
    tag('g:product_type', item.productType),
    tag('g:custom_label_0', item.customLabel0),
    ...item.highlights.map((highlight) => tag('g:product_highlight', highlight)),
    ...item.details.map(
      (detail) =>
        '<g:product_detail>' +
        tag('g:section_name', detail.section) +
        tag('g:attribute_name', detail.name) +
        tag('g:attribute_value', detail.value) +
        '</g:product_detail>',
    ),
    // Downloads have no carriage cost, but the attribute is not optional: an
    // item with no shipping value for its target country is disapproved.
    ...item.shippingCountries.map(
      (country) =>
        '<g:shipping>' +
        tag('g:country', country) +
        tag('g:service', 'Digital delivery') +
        tag('g:price', '0.00 USD') +
        '</g:shipping>',
    ),
  ]

  return `    <item>\n${lines.map((line) => `      ${line}`).join('\n')}\n    </item>`
}

export function buildProductFeed(): string {
  const items = feedItems().map(renderItem).join('\n')

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss xmlns:g="http://base.google.com/ns/1.0" version="2.0">
  <channel>
    ${tag('title', `${siteConfig.name} products`)}
    ${tag('link', siteConfig.url)}
    ${tag('description', siteConfig.description)}
${items}
  </channel>
</rss>
`
}

export function GET() {
  return new Response(buildProductFeed(), {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=0, s-maxage=3600, stale-while-revalidate=86400',
    },
  })
}
