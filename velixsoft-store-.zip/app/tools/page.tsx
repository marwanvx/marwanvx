import type { Metadata } from 'next'
import { CategoryPage } from '@/src/components/sections/category-page'
import { categoryContent } from '@/src/data/content'
const seo = categoryContent.tool.seo
export const metadata: Metadata = { title: seo.title, description: seo.description, keywords: seo.keywords, alternates: { canonical: '/tools' }, openGraph: { url: '/tools' } }
export default function Page() { return <CategoryPage type="tool" /> }
