import type { Metadata } from 'next'
import { CategoryPage } from '@/src/components/sections/category-page'
import { categoryContent } from '@/src/data/content'
const seo = categoryContent.theme.seo
export const metadata: Metadata = { title: seo.title, description: seo.description, keywords: seo.keywords, alternates: { canonical: '/themes' }, openGraph: { url: '/themes' } }
export default function Page() { return <CategoryPage type="theme" /> }
