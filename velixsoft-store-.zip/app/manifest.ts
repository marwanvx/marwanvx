import type { MetadataRoute } from 'next'
import { siteConfig } from '@/src/data/site'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: siteConfig.name,
    short_name: 'VelixSoft',
    description: siteConfig.description,
    start_url: '/',
    display: 'standalone',
    background_color: '#090d16',
    theme_color: '#2563eb',
    /**
     * `purpose: 'any'` throughout, not `maskable`. A maskable icon must keep its
     * content inside a centred circle of 80% diameter; the mark is 56% wide but
     * its diagonal reach is 226px against a 205px safe radius at 512, so Android
     * would clip its corners. A maskable set needs the mark scaled to ~90% first.
     */
    icons: [
      { src: '/web-app-manifest-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/web-app-manifest-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/apple-icon.png', sizes: '180x180', type: 'image/png' },
    ],
  }
}
