import { NextResponse } from 'next/server'
import { createSupabaseServerClient } from '@/src/lib/supabase/server'

/**
 * OAuth return path. Exchanges the `?code` Supabase appends for a session cookie.
 *
 * Deliberately NOT in the middleware matcher: it has to run before a session
 * exists, and matching it would redirect the visitor to /login forever.
 *
 * `origin` comes from the request rather than a configured site URL so this works
 * unchanged on localhost, Vercel previews and production.
 */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const next = safeNext(searchParams.get('next'))

  if (!code) {
    return NextResponse.redirect(`${origin}/login?error=missing_code`)
  }

  const supabase = await createSupabaseServerClient()
  const { error } = await supabase.auth.exchangeCodeForSession(code)

  if (error) {
    return NextResponse.redirect(
      `${origin}/login?error=${encodeURIComponent(error.message)}`,
    )
  }

  return NextResponse.redirect(`${origin}${next}`)
}

/**
 * Only ever redirect to a path on this site.
 *
 * `next` arrives from the query string, so without this an attacker could send
 * someone a real, working VelixSoft sign-in link that lands them on a site they
 * control — with the trust of having just authenticated. Protocol-relative URLs
 * (`//evil.com`) are the case people usually miss.
 */
function safeNext(value: string | null): string {
  if (!value) return '/dashboard'
  if (!value.startsWith('/')) return '/dashboard'
  if (value.startsWith('//')) return '/dashboard'
  return value
}
