import type { Metadata } from 'next'
import { LegalPage } from '@/src/components/sections/content-pages'
import { legalContent } from '@/src/data/legal'
export const metadata: Metadata = { title: 'Terms of Service', description: legalContent.terms.description, alternates: { canonical: '/terms' } }
export default function Page() { return <LegalPage {...legalContent.terms} updated="July 26, 2026" /> }
