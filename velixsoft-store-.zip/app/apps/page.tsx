import type { Metadata } from 'next'
import { CategoryPage } from '@/src/components/sections/category-page'
import { categoryContent } from '@/src/data/content'
const seo = categoryContent.app.seo
export const metadata: Metadata = { title: seo.title, description: seo.description, keywords: seo.keywords, alternates: { canonical: '/apps' }, openGraph: { url: '/apps' } }
export default function Page() { return <CategoryPage type="app" /> }
