import type { Metadata } from 'next'
import { FaqPage } from '@/src/components/sections/content-pages'
export const metadata: Metadata = { title: 'Frequently Asked Questions', description: 'Answers about VelixSoft: what we build, how one-time licensing works, where your data is stored, plus product details for YTLeads Pro and the Perfect Panel Theme.', alternates: { canonical: '/faq' }, openGraph: { url: '/faq' } }
export default function Page() { return <FaqPage /> }
