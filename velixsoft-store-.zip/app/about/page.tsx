import type { Metadata } from 'next'
import { AboutPage } from '@/src/components/sections/content-pages'
export const metadata: Metadata = { title: 'About', description: 'VelixSoft is a software company building desktop applications for Windows and macOS, automation tools, and digital products. How we work, where we started, and what we are building next.', alternates: { canonical: '/about' }, openGraph: { url: '/about' } }
export default function Page() { return <AboutPage /> }
