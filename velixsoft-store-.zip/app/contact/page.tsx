import type { Metadata } from 'next'
import { ContactPage } from '@/src/components/sections/content-pages'
export const metadata: Metadata = { title: 'Contact', description: 'Contact VelixSoft about a product, licensing, compatibility, installation, or a project you want built. Reach us on WhatsApp, Telegram, or Discord.', alternates: { canonical: '/contact' }, openGraph: { url: '/contact' } }
export default function Page() { return <ContactPage /> }
