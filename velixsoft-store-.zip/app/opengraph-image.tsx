import { ImageResponse } from 'next/og'
import { siteConfig } from '@/src/data/site'

export const alt = 'VelixSoft | Software, Desktop Apps & Automation Tools'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

/** Default social card for every route that does not define its own. */
export default function Image() {
  return new ImageResponse(
    (
      <div style={{ width: '1200px', height: '630px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: '72px', color: 'white', background: '#040a18', fontFamily: 'sans-serif' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 52, height: 52, borderRadius: 16, background: '#2563eb', fontWeight: 800 }}>V</div>
          <div style={{ fontSize: 24, fontWeight: 700, letterSpacing: 4 }}>VELIXSOFT</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{ fontSize: 84, lineHeight: 1.02, fontWeight: 750, letterSpacing: -4 }}>Software, built to order</div>
          <div style={{ maxWidth: 940, fontSize: 30, lineHeight: 1.35, color: '#aeb9ca' }}>
            Custom software to order. Web, desktop, mobile, automation, and interface systems.
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 22, color: '#aeb9ca' }}>
          <div style={{ display: 'flex', gap: 28 }}>
            <span>Desktop Apps</span>
            <span>Automation</span>
            <span>Data Products</span>
          </div>
          <div>{siteConfig.domain}</div>
        </div>
      </div>
    ),
    size,
  )
}
