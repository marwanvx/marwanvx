import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { GuidePage } from '@/src/components/sections/guide-pages'
import { getGuide, guides } from '@/src/data/guides'
import { siteConfig } from '@/src/data/site'
import { JsonLd } from '@/src/components/ui/primitives'

export function generateStaticParams() { return guides.map(({ slug }) => ({ slug })) }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> { const { slug } = await params; const guide = getGuide(slug); if (!guide) return {}; return { title: guide.seo.title, description: guide.seo.description, keywords: guide.seo.keywords, alternates: { canonical: `/guides/${slug}` }, openGraph: { type: 'article', url: `/guides/${slug}`, title: guide.seo.title, description: guide.seo.description, publishedTime: guide.publishedAt, modifiedTime: guide.updatedAt } } }
export default async function Page({ params }: { params: Promise<{ slug: string }> }) { const { slug } = await params; const guide = getGuide(slug); if (!guide) notFound(); const articleSchema = { '@context': 'https://schema.org', '@type': 'Article', headline: guide.title, description: guide.excerpt, datePublished: guide.publishedAt, dateModified: guide.updatedAt, author: { '@type': 'Organization', name: 'VelixSoft', url: siteConfig.url }, publisher: { '@id': `${siteConfig.url}/#organization` }, mainEntityOfPage: `${siteConfig.url}/guides/${slug}` }; const breadcrumbSchema = { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Guides', item: `${siteConfig.url}/guides` }, { '@type': 'ListItem', position: 2, name: guide.title, item: `${siteConfig.url}/guides/${slug}` }] }; return <><JsonLd data={[articleSchema, breadcrumbSchema]} /><GuidePage guide={guide} /></> }
