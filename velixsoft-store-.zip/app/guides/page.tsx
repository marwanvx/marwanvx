import type { Metadata } from 'next'
import { GuidesPage } from '@/src/components/sections/guide-pages'
export const metadata: Metadata = { title: 'Guides & Documentation', description: 'Installation walkthroughs and design documentation from VelixSoft, covering Perfect Panel theme setup, color systems, and interface decisions that earn trust.', alternates: { canonical: '/guides' }, openGraph: { url: '/guides' } }
export default function Page() { return <GuidesPage /> }
