import type { Metadata } from 'next'
import { PageHero } from '@/src/components/ui/primitives'
import { ProductCatalog } from '@/src/components/product/product-catalog'
import { products } from '@/src/data/products'
import { ContactCta } from '@/src/components/sections/contact-cta'

export const metadata: Metadata = { title: 'Desktop Software & Automation Tools', description: 'The full VelixSoft catalogue: desktop applications, automation and developer tools, data products, and interface themes. Two products available now.', alternates: { canonical: '/products' }, openGraph: { url: '/products' } }

export default function ProductsPage() {
  return (
    <>
      <PageHero eyebrow="Product catalogue" title="Every product we ship." description="Desktop applications, automation and developer tools, data products, and interface systems. Filter by category to see what is available now and what is in development." />
      <ProductCatalog products={products} />
      <ContactCta />
    </>
  )
}
