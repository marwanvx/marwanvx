import { ImageResponse } from 'next/og'
import { getProduct } from '@/src/data/products'

export const runtime = 'edge'

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) return new Response('Not found', { status: 404 })
  const editions = ('editions' in product && Array.isArray(product.editions)) ? product.editions : []
  return new ImageResponse(
    <div style={{ width: '1200px', height: '630px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: '72px', color: 'white', background: '#040a18', fontFamily: 'sans-serif' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 52, height: 52, borderRadius: 16, background: '#2563eb', fontWeight: 800 }}>V</div><div style={{ fontSize: 24, fontWeight: 700, letterSpacing: 4 }}>VELIXSOFT</div></div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}><div style={{ fontSize: 72, lineHeight: 1.02, fontWeight: 750, letterSpacing: -3 }}>{product.name}</div><div style={{ maxWidth: 900, fontSize: 30, lineHeight: 1.35, color: '#aeb9ca' }}>{product.tagline}</div></div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><div style={{ display: 'flex', gap: 12 }}>{editions.map((edition) => <div key={edition.id} style={{ width: 30, height: 30, borderRadius: 999, background: edition.swatch, border: '2px solid rgba(255,255,255,.25)' }} />)}</div><div style={{ fontSize: 22, color: '#aeb9ca' }}>velixsoft.net</div></div>
    </div>,
    { width: 1200, height: 630 },
  )
}
