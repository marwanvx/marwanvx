import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { ProductDetail } from '@/src/components/product/product-detail'
import { getProduct, products } from '@/src/data/products'
export function generateStaticParams() {
  return products.map((product) => ({ slug: product.slug }))
}
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) return {}
  return {
    title: product.seo.title,
    description: product.seo.description,
    keywords: product.seo.keywords,
    alternates: { canonical: `/products/${product.slug}` },
    openGraph: { title: product.seo.title, description: product.seo.description, url: `/products/${product.slug}`, images: [`/products/${product.slug}/opengraph-image`] },
    twitter: { card: 'summary_large_image', title: product.seo.title, description: product.seo.description, images: [`/products/${product.slug}/opengraph-image`] },
  }
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const product = getProduct(slug)
  if (!product) notFound()
  return <ProductDetail product={product} />
}
