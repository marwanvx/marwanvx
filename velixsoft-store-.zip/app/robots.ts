import type { MetadataRoute } from 'next'
import { siteConfig } from '@/src/data/site'

/**
 * AI answer engines are allowed explicitly rather than relying on the wildcard,
 * so a future restriction on `*` cannot silently remove us from AI search.
 */
const aiSearchCrawlers = [
  'GPTBot',
  'OAI-SearchBot',
  'ChatGPT-User',
  'ClaudeBot',
  'Claude-User',
  'PerplexityBot',
  'Perplexity-User',
  'Google-Extended',
  'Applebot-Extended',
]

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: '*', allow: '/' },
      ...aiSearchCrawlers.map((userAgent) => ({ userAgent, allow: '/' })),
    ],
    sitemap: `${siteConfig.url}/sitemap.xml`,
    host: siteConfig.url,
  }
}
