import type { Metadata } from 'next'
import { LegalPage } from '@/src/components/sections/content-pages'
import { legalContent } from '@/src/data/legal'
export const metadata: Metadata = { title: 'Refund Policy', description: legalContent.refund.description, alternates: { canonical: '/refund-policy' } }
export default function Page() { return <LegalPage {...legalContent.refund} updated="July 26, 2026" /> }
