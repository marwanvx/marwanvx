import { Analytics } from '@vercel/analytics/next'
import { Inter, Geist_Mono } from 'next/font/google'
import type { Metadata, Viewport } from 'next'
import { TooltipProvider } from '@/components/ui/tooltip'
import { EditionProvider } from '@/src/components/product/edition-provider'
import { Navbar } from '@/src/components/sections/navbar'
import { Footer } from '@/src/components/sections/footer'
import { JsonLd } from '@/src/components/ui/primitives'
import { DEFAULT_EDITION_ID } from '@/src/data/products'
import { siteConfig } from '@/src/data/site'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' })
const mono = Geist_Mono({ subsets: ['latin'], variable: '--font-mono-family', display: 'swap' })

const defaultTitle = 'VelixSoft | Software, Desktop Apps & Automation Tools'

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: { default: defaultTitle, template: '%s | VelixSoft' },
  description: siteConfig.description,
  applicationName: 'VelixSoft',
  openGraph: { type: 'website', siteName: 'VelixSoft', url: '/', title: defaultTitle, description: siteConfig.description },
  twitter: { card: 'summary_large_image', title: defaultTitle, description: siteConfig.description },
  /**
   * Site ownership verification. Bing only requires this on the home page, but
   * Next renders root metadata on every route, which is harmless and removes any
   * chance of losing verification if the home page is restructured.
   *
   * Do not remove these after verification succeeds. Both services re-check
   * periodically and drop the property when the tag disappears, which silently
   * ends access to the index coverage and query data.
   *
   * Bing matters more here than its search share suggests: ChatGPT search runs
   * on Bing's index, and `app/robots.ts` explicitly admits OAI-SearchBot and
   * ChatGPT-User. See `docs/BRAND.md` §8.
   */
  verification: {
    other: { 'msvalidate.01': '94E33C60D62559B52F35EFCB39968FDA' },
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon.png', type: 'image/png' },
    ],
    apple: [{ url: '/apple-icon.png' }],
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark light',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f8f9fa' },
    { media: '(prefers-color-scheme: dark)', color: '#040a18' },
  ],
  width: 'device-width',
  initialScale: 1,
  userScalable: true,
}

const preHydrationScript = `
(function(){
  try {
    var theme = localStorage.getItem('velix-theme');
    var dark = theme ? theme === 'dark' : true;
    document.documentElement.classList.add(dark ? 'dark' : 'light');
    var editions = {
      ember:{dark:['#e11d1d','#d10000','#f05252'],light:['#d10000','#ad0000','#e63232']},
      ocean:{dark:['#3b82f6','#2563eb','#60a5fa'],light:['#2563eb','#1d4ed8','#3b82f6']},
      aurora:{dark:['#8b5cf6','#7c3aed','#a78bfa'],light:['#7c3aed','#6d28d9','#8b5cf6']},
      cyan:{dark:['#22d3ee','#06b6d4','#67e8f9'],light:['#0891b2','#0e7490','#06b6d4']},
      emerald:{dark:['#34d399','#10b981','#6ee7b7'],light:['#059669','#047857','#10b981']},
      midnight:{dark:['#6366f1','#4f46e5','#818cf8'],light:['#4f46e5','#4338ca','#6366f1']}
    };
    var id = localStorage.getItem('velix-edition') || '${DEFAULT_EDITION_ID}';
    if (!editions[id]) id = '${DEFAULT_EDITION_ID}';
    var t = editions[id][dark ? 'dark' : 'light'];
    var s = document.documentElement.style;
    s.setProperty('--brand',t[0]);s.setProperty('--brand-600',t[1]);s.setProperty('--brand-400',t[2]);s.setProperty('--brand-soft',t[0]+'22');
    document.documentElement.dataset.edition=id;
  } catch(e) { document.documentElement.classList.add('dark'); }
})();`

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const organization = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': `${siteConfig.url}/#organization`,
    name: siteConfig.name,
    alternateName: 'Velix Software',
    url: siteConfig.url,
    logo: `${siteConfig.url}/icon.png`,
    image: `${siteConfig.url}/opengraph-image`,
    description: siteConfig.description,
    slogan: siteConfig.tagline,
    foundingDate: siteConfig.founded,
    knowsAbout: [
      'Desktop application development',
      'Workflow automation software',
      'Developer tools',
      'Interface design systems',
      'Lead generation software',
      'Perfect Panel themes',
    ],
    contactPoint: [
      {
        '@type': 'ContactPoint',
        contactType: 'sales and technical support',
        url: siteConfig.social.whatsapp,
        availableLanguage: ['English'],
      },
    ],
    sameAs: Object.values(siteConfig.social),
  }
  const website = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': `${siteConfig.url}/#website`,
    name: siteConfig.name,
    url: siteConfig.url,
    description: siteConfig.description,
    publisher: { '@id': `${siteConfig.url}/#organization` },
  }
  return (
    <html lang="en" className={`${inter.variable} ${mono.variable} bg-background`} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: preHydrationScript }} /></head>
      <body className="min-h-screen bg-background text-foreground" suppressHydrationWarning>
        <JsonLd data={[organization, website]} />
        <EditionProvider>
          <TooltipProvider>
            <Navbar />
            <main>{children}</main>
            <Footer />
          </TooltipProvider>
        </EditionProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
