import type { Metadata } from 'next'
import { HomePage } from '@/src/components/sections/home-page'

/**
 * Title, description, and Open Graph are inherited from the root layout, which
 * already defines exactly this page: the layout's `title.default` and
 * `siteConfig.description` ARE the company-level strings.
 *
 * They used to be copied here as well, and the copies drifted — the duplicate
 * description had picked up both product names and a platform pair, so the
 * homepage advertised the catalogue while every other surface described the
 * company (`docs/BRAND.md` §1). Do not restate inherited metadata here; change
 * it at the source in `src/data/site.ts` or `app/layout.tsx`.
 */
export const metadata: Metadata = {
  alternates: { canonical: '/' },
}

export default function Page() { return <HomePage /> }
