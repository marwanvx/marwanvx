import type { MetadataRoute } from 'next'
import { galleryImagePaths, products } from '@/src/data/products'
import { guides } from '@/src/data/guides'
import { siteConfig } from '@/src/data/site'

/**
 * Static route metadata. `lastModified` is a real date per route, maintained by
 * hand, and it must stay that way.
 *
 * It previously read `new Date()`, which told every crawl that all fourteen
 * static pages had changed that second. Google drops `lastmod` entirely for a
 * site once it observes the value is unreliable, and it makes that judgement per
 * site — so an always-now value here was also discrediting the accurate dates
 * derived from `updatedAt` on products and guides below. A wrong signal is worse
 * than no signal.
 *
 * When you change what a page renders, bump its date here in the same commit.
 * Seed values were taken from the last commit touching each route's page file
 * and the data module it renders from.
 */
const STATIC_ROUTES: { path: string; lastModified: string; changeFrequency: 'weekly' | 'monthly'; priority: number }[] = [
  { path: '', lastModified: '2026-08-01', changeFrequency: 'weekly', priority: 1 },
  { path: '/products', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.9 },
  { path: '/themes', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/apps', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/tools', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/data', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/services', lastModified: '2026-07-31', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/about', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/faq', lastModified: '2026-08-01', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/contact', lastModified: '2026-07-31', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/guides', lastModified: '2026-07-31', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/terms', lastModified: '2026-07-27', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/privacy', lastModified: '2026-07-27', changeFrequency: 'monthly', priority: 0.7 },
  { path: '/refund-policy', lastModified: '2026-07-27', changeFrequency: 'monthly', priority: 0.7 },
]

export default function sitemap(): MetadataRoute.Sitemap {
  const staticEntries = STATIC_ROUTES.map(({ path, lastModified, changeFrequency, priority }) => ({
    url: `${siteConfig.url}${path}`,
    lastModified: new Date(lastModified),
    changeFrequency,
    priority,
  }))

  const productEntries = products.map((product) => ({
    url: `${siteConfig.url}/products/${product.slug}`,
    lastModified: new Date(product.updatedAt),
    changeFrequency: 'monthly' as const,
    priority: product.status === 'available' ? 0.9 : 0.6,
    images: galleryImagePaths(product).map((path) => `${siteConfig.url}${path}`),
  }))

  const guideEntries = guides.map((guide) => ({
    url: `${siteConfig.url}/guides/${guide.slug}`,
    lastModified: new Date(guide.updatedAt),
    changeFrequency: 'monthly' as const,
    priority: 0.75,
  }))

  return [...staticEntries, ...productEntries, ...guideEntries]
}
