import type { Metadata } from 'next'
import { LegalPage } from '@/src/components/sections/content-pages'
import { legalContent } from '@/src/data/legal'
export const metadata: Metadata = { title: 'Privacy Policy', description: legalContent.privacy.description, alternates: { canonical: '/privacy' } }
export default function Page() { return <LegalPage {...legalContent.privacy} updated="July 26, 2026" /> }
