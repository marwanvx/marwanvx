import type { Config } from 'drizzle-kit'

/**
 * Drizzle Kit config.
 *
 *   pnpm db:push      apply the schema to the database
 *   pnpm db:policies   then apply drizzle/policies/rls.sql — push does NOT do this
 *   pnpm db:studio    browse the data
 *
 * The policies step is separate and easy to forget. Skipping it leaves every table
 * without row level security.
 */
export default {
  schema: './src/db/schema.ts',
  out: './drizzle/migrations',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL! },
  strict: true,
  verbose: true,
} satisfies Config
